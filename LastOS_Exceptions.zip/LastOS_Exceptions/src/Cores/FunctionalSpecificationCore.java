package Cores;

import ScannerTools.*;

import java.io.BufferedReader;
import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.logging.Handler;

public class FunctionalSpecificationCore{
    public static void FunctionalSpecification(BufferedReader br){
        MoiseScanner_tag.simpleCloseTag(br);
        boolean hasProperties = MoiseScanner_tag.Tag_peek(br,"properties");
        boolean hasScheme;
        boolean hasGoal;
        boolean hasArgument=false;
        boolean hasDependsOn;
        boolean hasPlan;
        boolean hasNotificationPolicy=false;
        boolean hasAccountabilityAgreement=false;
        boolean hasAccountArgument;
        boolean hasTarget;
        boolean hasRequestingCondition = false;
        boolean hasAccountTemplate;
        boolean hasConditionArgument;
        boolean hasExceptionSpecification;
        boolean hasExceptionArgument=false;
        boolean hasRaisingGoal;
        boolean hasHandlingGoal=false;
        boolean hasMission=false;
        boolean hasMissionGoal;
        boolean hasPreferred;

        if(hasProperties){
            PropertiesCore.Properties(br,"functional-specification");
            hasScheme = MoiseScanner_tag.Tag_peek(br,"scheme");
        }else{
            hasScheme = MoiseScanner_tag.Tag_check(MoiseScanner_variables.temp_peek,"scheme");
        }
        if(hasScheme){
            String id = "";
            MoiseScanner_variables.cycle = true;
            while (MoiseScanner_variables.cycle){
                id = MoiseScanner_identifier.return_identifier(br, "id", "scheme");
                MoiseScanner_tag.simpleCloseTag(br);
                MoiseScanner_HashMap.fs_scheme.put(variables_for_HashMap.index_fs_scheme, new ArrayList<>(Arrays.asList("functional-specification","yes",id)));
                variables_for_HashMap.index_fs_scheme++;
                hasProperties = MoiseScanner_tag.Tag_peek(br, "properties");
                if(hasProperties){
                    PropertiesCore.Properties(br,"scheme");
                    hasGoal = MoiseScanner_tag.Tag_peek(br, "goal");
                }else{
                    hasGoal = MoiseScanner_tag.Tag_check(MoiseScanner_variables.temp_peek, "goal");
                }
                if(hasGoal){
                    goal_plan(br,"scheme");
                }else{
                    MoiseScanner_methods.MoiseScanner_error("ERROR: missing goal", 1);
                }
                if(MoiseScanner_variables.os_type){
                    hasNotificationPolicy = MoiseScanner_tag.ComposedTag_dash_peek(br, MoiseScanner_variables.temp_peek, "notification", "policy");
                }else if(!MoiseScanner_variables.os_type){
                    hasAccountabilityAgreement = MoiseScanner_tag.ComposedTag_dash_peek(br, MoiseScanner_variables.temp_peek, "accountability", "agreement");
                }
                if(hasNotificationPolicy){
                    MoiseScanner_variables.cycle = true;
                    while(MoiseScanner_variables.cycle){
                        MoiseScanner_identifier_recognition.identifier_recognition(br,"notification-policy","scheme");
                        hasProperties = MoiseScanner_tag.Tag_peek(br, "properties");
                        if(hasProperties){
                            PropertiesCore.Properties(br,"notification-policy");
                            hasExceptionSpecification = MoiseScanner_tag.ComposeTag_peek(br, "exception", "specification");
                        }else{
                            hasExceptionSpecification = MoiseScanner_tag.ComposedTag_dash_peek(br, MoiseScanner_variables.temp_peek, "exception", "specification");
                        }
                        if(hasExceptionSpecification) {
                            String id_ExceptionSpecification = "";
                            id_ExceptionSpecification = MoiseScanner_identifier.return_identifier(br, "id", "exception-specification");
                            MoiseScanner_tag.simpleCloseTag(br);
                            String index_father = MoiseScanner_methods.to_String(variables_for_HashMap.index_fs_notification_policy - 1);
                            MoiseScanner_HashMap.fs_exception_specification.put(variables_for_HashMap.index_fs_exception_specification, new ArrayList<>(Arrays.asList("notification-policy", "yes", id_ExceptionSpecification, index_father)));
                            variables_for_HashMap.index_fs_exception_specification++;
                            hasExceptionArgument = MoiseScanner_tag.ComposeTag_peek(br, "exception", "argument");
                            if (hasExceptionArgument) {
                                MoiseScanner_identifier_recognition.identifier_recognition(br, "exception-argument", "exception-specification");
                            }
                            hasRaisingGoal = MoiseScanner_tag.ComposedTag_dash_peek(br, MoiseScanner_variables.temp_peek, "raising", "goal");
                            if (hasRaisingGoal){
                                MoiseScanner_variables.cycle = true;
                                while (MoiseScanner_variables.cycle) {
                                    raising_goal(br, "exception-specification");
                                    if (MoiseScanner_variables.peek == '<') {
                                        MoiseScanner_methods.readch(br);
                                        if (Character.isLetter(MoiseScanner_variables.peek)) {
                                            String s3 = MoiseScanner_methods.attach_character(br);
                                            MoiseScanner_variables.temp_peek = s3;
                                        }
                                    }
                                    MoiseScanner_variables.cycle = MoiseScanner_tag.ComposedTag_dash_peek(br, MoiseScanner_variables.temp_peek, "raising", "goal");
                                }
                                hasHandlingGoal = MoiseScanner_tag.ComposedTag_dash_peek(br, MoiseScanner_variables.temp_peek, "handling", "goal");
                            } else {
                                MoiseScanner_methods.MoiseScanner_error("ERROR: missing raising-goal", 1);
                            }
                            if(hasHandlingGoal){
                                MoiseScanner_variables.cycle = true;
                                while (MoiseScanner_variables.cycle) {
                                    handling_goal(br, "exception-specification");
                                    if (MoiseScanner_variables.peek == '<') {
                                        MoiseScanner_methods.readch(br);
                                        if (Character.isLetter(MoiseScanner_variables.peek)) {
                                            String s3 = MoiseScanner_methods.attach_character(br);
                                            MoiseScanner_variables.temp_peek = s3;
                                        }
                                    }
                                    MoiseScanner_variables.cycle = MoiseScanner_tag.ComposedTag_dash_peek(br, MoiseScanner_variables.temp_peek, "handling", "goal");
                                }
                            }else{
                                MoiseScanner_methods.MoiseScanner_error("ERROR: missing handling-goal", 1);
                            }
                            if(MoiseScanner_variables.peek=='/'){
                                if(MoiseScanner_variables.exit_case){
                                    MoiseScanner_tag.ComposeTagFC(br, "notification", "policy");
                                }else{
                                    MoiseScanner_tag.ComposeTagFC(br, "exception", "specification");
                                }
                            }
                        }else{
                            MoiseScanner_methods.MoiseScanner_error("ERROR: missing exception-specification", 1);
                        }
                        if(MoiseScanner_variables.peek=='<'){
                            if(!MoiseScanner_variables.exit_case){
                                MoiseScanner_tag.closeComposedTag(br, "notification", "policy");
                            }
                        }else{
                            MoiseScanner_tag.ComposeTagFC(br, "notification", "policy");
                        }
                        MoiseScanner_variables.cycle = MoiseScanner_tag.ComposeTag_peek(br, "notification", "policy");
                    }
                    hasMission = MoiseScanner_tag.Tag_check(MoiseScanner_variables.temp_peek, "mission");
                }
                if(hasAccountabilityAgreement){
                    MoiseScanner_variables.cycle = true;
                    while(MoiseScanner_variables.cycle){
                        MoiseScanner_identifier_recognition.identifier_recognition(br,"accountability-agreement","scheme");
                        hasTarget = MoiseScanner_tag.Tag_peek(br, "target");
                        if(hasTarget){
                            String index_father =  MoiseScanner_methods.to_String(variables_for_HashMap.index_fs_accountability_agreement-1);
                            String target_id = "";
                            target_id = MoiseScanner_identifier.return_identifier(br, "id", "target");
                            MoiseScanner_tag.simpleCloseTag2(br);
                            MoiseScanner_HashMap.fs_target.put(variables_for_HashMap.index_fs_target, new ArrayList<>(Arrays.asList("accountability-agreement","no",target_id,index_father)));
                            variables_for_HashMap.index_fs_target++;
                            hasRequestingCondition = MoiseScanner_tag.ComposeTag_peek(br, "requesting", "condition");
                        }else{
                            MoiseScanner_methods.MoiseScanner_error("REQUEST ONE TARGET",1);
                        }
                        if(hasRequestingCondition){
                            String value_RequestingCondition = "";
                            value_RequestingCondition = MoiseScanner_identifier.return_identifier(br, "value","requesting-condition");
                            if(MoiseScanner_variables.peek=='/'){
                                MoiseScanner_tag.simpleCloseTag2(br);
                                String index_father = MoiseScanner_methods.to_String(variables_for_HashMap.index_fs_accountability_agreement - 1);
                                MoiseScanner_HashMap.fs_requesting_condition.put(variables_for_HashMap.index_fs_requesting_condition, new ArrayList<>(Arrays.asList("accountability_agreement", "no", value_RequestingCondition, index_father)));
                                variables_for_HashMap.index_fs_requesting_condition++;
                            }else if(MoiseScanner_variables.peek=='>'){
                                MoiseScanner_tag.simpleCloseTag(br);
                                hasConditionArgument = MoiseScanner_tag.ComposeTag_peek(br, "condition", "argument");
                                if(hasConditionArgument){
                                    MoiseScanner_identifier_recognition.identifier_recognition(br, "condition-argument", "requesting-condition");
                                }
                                String index_father = MoiseScanner_methods.to_String(variables_for_HashMap.index_fs_accountability_agreement - 1);
                                MoiseScanner_HashMap.fs_requesting_condition.put(variables_for_HashMap.index_fs_requesting_condition, new ArrayList<>(Arrays.asList("accountability_agreement", "yes", value_RequestingCondition, index_father)));
                                variables_for_HashMap.index_fs_requesting_condition++;
                                MoiseScanner_tag.ComposeTagFC(br,"requesting", "condition");
                            }
                            hasProperties = MoiseScanner_tag.Tag_peek(br, "properties");
                            }else{
                            MoiseScanner_methods.MoiseScanner_error("ERROR: missing requesting-condition", 1);
                        }
                        if(hasProperties){
                            PropertiesCore.Properties(br,"accountability-agreement");
                            hasAccountTemplate = MoiseScanner_tag.ComposeTag_peek(br, "account", "template");
                        }else{
                            hasAccountTemplate = MoiseScanner_tag.ComposedTag_dash_peek(br, MoiseScanner_variables.temp_peek, "account", "template");
                        }
                        if(hasAccountTemplate){
                            if(MoiseScanner_variables.peek=='>'){
                                MoiseScanner_tag.simpleCloseTag(br);
                                hasAccountArgument = MoiseScanner_tag.ComposeTag_peek(br, "account", "argument");
                                if(hasAccountArgument){
                                    MoiseScanner_identifier_recognition.identifier_recognition(br, "account-argument", "accountability-agreement");
                                }
                                hasGoal = MoiseScanner_tag.Tag_check(MoiseScanner_variables.temp_peek, "goal");
                                if(hasGoal){
                                    goal_plan(br,"account-template");
                                }
                            }else if(MoiseScanner_variables.peek=='/'){
                                MoiseScanner_tag.simpleCloseTag2(br);
                            }
                        }else{
                            MoiseScanner_methods.MoiseScanner_error("ERROR: missing account-template", 1);
                        }
                        if(MoiseScanner_variables.peek=='<'){
                            MoiseScanner_tag.closeComposedTag(br, "account", "template");
                        }else{
                            MoiseScanner_tag.ComposeTagFC(br, "account", "template");
                            MoiseScanner_tag.closeComposedTag(br,"accountability","agreement");
                        }
                        MoiseScanner_variables.cycle = MoiseScanner_tag.ComposeTag_peek(br, "accountability", "agreement");
                    }
                    hasMission = MoiseScanner_tag.Tag_check(MoiseScanner_variables.temp_peek, "mission");
                }
                if(hasMission){
                    MoiseScanner_variables.cycle = true;
                    while(MoiseScanner_variables.cycle){
                        MoiseScanner_identifier_recognition.identifier_recognition(br,"mission","scheme");
                        hasProperties = MoiseScanner_tag.Tag_peek(br, "properties");
                        if(hasProperties){
                            PropertiesCore.Properties(br,"mission");
                            hasMissionGoal = MoiseScanner_tag.Tag_peek(br, "goal");
                        }else{
                            hasMissionGoal = MoiseScanner_tag.Tag_check(MoiseScanner_variables.temp_peek, "goal");
                        }
                        if(hasMissionGoal){
                            String id_mission = "";
                            MoiseScanner_variables.cycle = true;
                            String index_father =  MoiseScanner_methods.to_String(variables_for_HashMap.index_fs_mission-1);
                            while (MoiseScanner_variables.cycle){
                                id_mission = MoiseScanner_identifier.return_identifier(br, "id", "mission-goal");
                                MoiseScanner_tag.simpleCloseTag2(br);
                                MoiseScanner_variables.cycle = MoiseScanner_tag.Tag_peek(br, "goal");
                                MoiseScanner_HashMap.fs_mission_goal.put(variables_for_HashMap.index_fs_mission_goal, new ArrayList<>(Arrays.asList("mission","no",id_mission,index_father)));
                                variables_for_HashMap.index_fs_mission_goal++;
                            }
                        }
                        hasPreferred = MoiseScanner_tag.Tag_check(MoiseScanner_variables.temp_peek, "preferred");
                        if(hasPreferred){
                            String mission = "";
                            MoiseScanner_variables.cycle = true;
                            String index_father =  MoiseScanner_methods.to_String(variables_for_HashMap.index_fs_mission-1);
                            while(MoiseScanner_variables.cycle){
                                mission = MoiseScanner_identifier.return_identifier(br, "mission", "preferred_mission");
                                MoiseScanner_tag.simpleCloseTag2(br);
                                MoiseScanner_variables.cycle = MoiseScanner_tag.Tag_peek(br, "preferred");
                                MoiseScanner_HashMap.fs_preferred.put(variables_for_HashMap.index_fs_preferred, new ArrayList<>(Arrays.asList("mission","no",mission,index_father)));
                                variables_for_HashMap.index_fs_preferred++;
                            }
                        }
                        MoiseScanner_tag.TagFC(br, "mission");
                        MoiseScanner_variables.cycle = MoiseScanner_tag.Tag_peek(br, "mission");
                    }
                }
                MoiseScanner_tag.TagFC(br, "scheme");
                MoiseScanner_variables.cycle = MoiseScanner_tag.Tag_peek(br, "scheme");
            }
        }
        MoiseScanner_tag.ComposeTagFC(br,"functional","specification");
    }

    public static void goal_plan(BufferedReader br,String from){
        MoiseScanner_variables.flag_noPlan = false;
        boolean hasArgument = false;
        boolean hasDependsOn = false;
        boolean hasPlan = false;
        boolean hasProperties = false;
        MoiseScanner_identifier_recognition.identifier_recognition(br,"goal",from);
        if(!MoiseScanner_variables.from_scheme){
            hasArgument = MoiseScanner_tag.Tag_check(MoiseScanner_variables.temp_peek, "argument");
        }else{
            hasArgument = MoiseScanner_tag.Tag_peek(br,"argument");
        }
        if(hasArgument){
            MoiseScanner_identifier_recognition.identifier_recognition(br,"argument","goal");
        }
        hasDependsOn = MoiseScanner_tag.ComposedTag_dash_peek(br,MoiseScanner_variables.temp_peek,"depends","on");
        if(hasDependsOn){
            String index_father =  MoiseScanner_methods.to_String(variables_for_HashMap.index_fs_goal-1);
            String goal = "";
            MoiseScanner_variables.cycle = true ;
            while(MoiseScanner_variables.cycle){
                goal = MoiseScanner_identifier.return_identifier(br, "goal", "depends-on");
                MoiseScanner_tag.simpleCloseTag2(br);
                MoiseScanner_variables.cycle = MoiseScanner_tag.ComposeTag_peek(br,"depends","on");
                MoiseScanner_HashMap.fs_depends_on.put(variables_for_HashMap.index_fs_depends_on, new ArrayList<>(Arrays.asList("goal","no",goal,index_father)));
                variables_for_HashMap.index_fs_depends_on++;
            }
        }
        hasPlan = MoiseScanner_tag.Tag_check(MoiseScanner_variables.temp_peek,"plan");
        if(hasPlan){
            MoiseScanner_identifier_recognition.identifier_recognition(br,"plan","goal");
            hasProperties = MoiseScanner_tag.Tag_peek(br, "properties");
            if(hasProperties){
                PropertiesCore.Properties(br,"plan");
                if((MoiseScanner_tag.Tag_peek(br, "goal"))){
                    MoiseScanner_variables.from_scheme = false;
                    goal_plan(br,"plan");
                }else{
                    MoiseScanner_methods.MoiseScanner_error("ERRORE: richiesto almeno un goal!", 1);
                }
            }else{
                if((MoiseScanner_tag.Tag_check(MoiseScanner_variables.temp_peek, "goal"))){
                    MoiseScanner_variables.from_scheme = false;
                    goal_plan(br,"plan");
                }else{
                    MoiseScanner_methods.MoiseScanner_error("ERRORE: richiesto almeno un goal!", 1);
                }
            }
            if(MoiseScanner_variables.peek == '<'){
                MoiseScanner_methods.readch(br);
                MoiseScanner_tag.TagFC(br, "plan");
                MoiseScanner_variables.iPlan.remove(MoiseScanner_variables.iPlan.size()-1);
            }else{
                MoiseScanner_variables.iPlan.remove(MoiseScanner_variables.iPlan.size()-1);
                MoiseScanner_tag.TagFC(br, "plan");
            }
            if(MoiseScanner_variables.peek == '<'){
                MoiseScanner_methods.readch(br);
                MoiseScanner_tag.TagFC(br, "goal");
                if((MoiseScanner_tag.Tag_peek(br, "goal"))){
                    goal_plan(br,"plan");
                }
            }else{
                MoiseScanner_methods.MoiseScanner_error("ERROR: chiusura",1);
            }
        }else{
            if(MoiseScanner_variables.flag_noPlan){
                MoiseScanner_tag.TagFC(br, "goal");
                if((MoiseScanner_tag.Tag_peek(br, "goal"))){
                    goal_plan(br,"plan");// was null
                }
            }
        }
    }

    public static void raising_goal(BufferedReader br,String from){
        boolean hasArgument = false;
        boolean hasDependsOn = false;
        boolean hasPlan = false;
        boolean hasProperties = false;
        MoiseScanner_identifier_recognition.identifier_recognition(br,"raising_goal",from);
        if(!MoiseScanner_variables.from_scheme){
            hasArgument = MoiseScanner_tag.Tag_check(MoiseScanner_variables.temp_peek, "argument");
        }else{
            hasArgument = MoiseScanner_tag.Tag_peek(br,"argument");
        }
        if(hasArgument){
            MoiseScanner_identifier_recognition.identifier_recognition(br,"argument","raising-goal");
        }
        hasDependsOn = MoiseScanner_tag.ComposedTag_dash_peek(br,MoiseScanner_variables.temp_peek,"depends","on");
        if(hasDependsOn){
            String index_father = MoiseScanner_methods.to_String(variables_for_HashMap.index_fs_raising_goal-1);
            String goal = "";
            MoiseScanner_variables.cycle = true ;
            while(MoiseScanner_variables.cycle){
                goal = MoiseScanner_identifier.return_identifier(br, "goal", "depends-on");
                MoiseScanner_tag.simpleCloseTag2(br);
                MoiseScanner_variables.cycle = MoiseScanner_tag.ComposeTag_peek(br,"depends","on");
                MoiseScanner_HashMap.fs_depends_on.put(variables_for_HashMap.index_fs_depends_on, new ArrayList<>(Arrays.asList("raising-goal","no",goal,index_father)));
                variables_for_HashMap.index_fs_depends_on++;
            }
        }
        hasPlan = MoiseScanner_tag.Tag_check(MoiseScanner_variables.temp_peek,"plan");
        if(hasPlan){
            MoiseScanner_identifier_recognition.identifier_recognition(br,"plan","raising-goal");
            hasProperties = MoiseScanner_tag.Tag_peek(br, "properties");
            if(hasProperties){
                PropertiesCore.Properties(br,"plan");
                if((MoiseScanner_tag.Tag_peek(br, "goal"))){
                    MoiseScanner_variables.from_scheme = false;
                    goal_plan(br,"plan");
                }else{
                    MoiseScanner_methods.MoiseScanner_error("ERRORE: richiesto almeno un goal!", 1);
                }
            }else{
                if((MoiseScanner_tag.Tag_check(MoiseScanner_variables.temp_peek, "goal"))){
                    MoiseScanner_variables.from_scheme = false;
                    goal_plan(br,"plan");
                }else{
                    MoiseScanner_methods.MoiseScanner_error("ERRORE: richiesto almeno un goal!",1);
                }
            }
            if(MoiseScanner_variables.peek == '<'){
                MoiseScanner_methods.readch(br);
                MoiseScanner_tag.TagFC(br, "plan");
                MoiseScanner_variables.iPlan.remove(MoiseScanner_variables.iPlan.size()-1);
            }else{
                MoiseScanner_variables.iPlan.remove(MoiseScanner_variables.iPlan.size()-1);
                MoiseScanner_tag.TagFC(br, "plan");
            }
            if(MoiseScanner_variables.peek=='<'){
                MoiseScanner_methods.readch(br);
                if(MoiseScanner_variables.peek=='/'){
                    MoiseScanner_tag.ComposeTagFC(br,"raising","goal");
                }
            }
        }else{
            if(MoiseScanner_variables.peek=='/'){
                MoiseScanner_tag.ComposeTagFC(br,"raising","goal");
            }
        }
    }

    public static void handling_goal(BufferedReader br,String from){
        boolean hasArgument = false;
        boolean hasDependsOn = false;
        boolean hasPlan = false;
        boolean hasProperties = false;
        MoiseScanner_identifier_recognition.identifier_recognition(br,"handling-goal",from);
        if(!MoiseScanner_variables.from_scheme){
            hasArgument = MoiseScanner_tag.Tag_check(MoiseScanner_variables.temp_peek, "argument");
        }else{
            hasArgument = MoiseScanner_tag.Tag_peek(br,"argument");
        }
        if(hasArgument){
            MoiseScanner_identifier_recognition.identifier_recognition(br,"argument","handling-goal");
        }
        hasDependsOn = MoiseScanner_tag.ComposedTag_dash_peek(br,MoiseScanner_variables.temp_peek,"depends","on");
        if(hasDependsOn){
            String index_father = MoiseScanner_methods.to_String(variables_for_HashMap.index_fs_raising_goal-1);
            String goal = "";
            MoiseScanner_variables.cycle = true ;
            while(MoiseScanner_variables.cycle){
                goal = MoiseScanner_identifier.return_identifier(br, "goal", "depends-on");
                MoiseScanner_tag.simpleCloseTag2(br);
                MoiseScanner_variables.cycle = MoiseScanner_tag.ComposeTag_peek(br,"depends","on");
                MoiseScanner_HashMap.fs_depends_on.put(variables_for_HashMap.index_fs_depends_on, new ArrayList<>(Arrays.asList("handling-goal","no",goal,index_father)));
                variables_for_HashMap.index_fs_depends_on++;
            }
        }
        hasPlan = MoiseScanner_tag.Tag_check(MoiseScanner_variables.temp_peek,"plan");
        if(hasPlan){
            MoiseScanner_identifier_recognition.identifier_recognition(br,"plan","handling-goal");
            hasProperties = MoiseScanner_tag.Tag_peek(br, "properties");
            if(hasProperties){
                PropertiesCore.Properties(br,"plan");
                if((MoiseScanner_tag.Tag_peek(br, "goal"))){
                    MoiseScanner_variables.from_scheme = false;
                    goal_plan(br,"plan");
                }else{
                    MoiseScanner_methods.MoiseScanner_error("ERRORE: richiesto almeno un goal!", 1);
                }
            }else{
                if((MoiseScanner_tag.Tag_check(MoiseScanner_variables.temp_peek, "goal"))){
                    MoiseScanner_variables.from_scheme = false;
                    goal_plan(br,"plan");
                }else{
                    MoiseScanner_methods.MoiseScanner_error("ERRORE: richiesto almeno un goal!",1);
                }
            }
            if(MoiseScanner_variables.peek == '<'){
                MoiseScanner_methods.readch(br);
                MoiseScanner_tag.TagFC(br, "plan");
                MoiseScanner_variables.iPlan.remove(MoiseScanner_variables.iPlan.size()-1);
            }else{
                MoiseScanner_variables.iPlan.remove(MoiseScanner_variables.iPlan.size()-1);
                MoiseScanner_tag.TagFC(br, "plan");
            }
            if(MoiseScanner_variables.peek=='<'){
                MoiseScanner_methods.readch(br);
                if(MoiseScanner_variables.peek=='/'){
                    MoiseScanner_tag.ComposeTagFC(br,"handling","goal");
                    MoiseScanner_variables.exit_case=false;
                }
            }
        }else{
            if(MoiseScanner_variables.peek=='/'){
                MoiseScanner_tag.ComposeTagFC(br,"exception","specification");
                MoiseScanner_variables.exit_case=true;
            }
        }
    }

}