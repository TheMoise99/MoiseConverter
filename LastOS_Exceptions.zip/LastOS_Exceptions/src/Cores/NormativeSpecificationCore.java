package Cores;

import ScannerTools.MoiseScanner_identifier_recognition;
import ScannerTools.MoiseScanner_tag;
import ScannerTools.MoiseScanner_variables;

import java.io.BufferedReader;

public class NormativeSpecificationCore{
    public static void NormativeSpecification(BufferedReader br){
        MoiseScanner_tag.simpleCloseTag(br);
        boolean hasProperties = MoiseScanner_tag.Tag_peek(br,"properties");
        boolean hasNorm;
        if(hasProperties){
            PropertiesCore.Properties(br,"normative-specification");
            hasNorm = MoiseScanner_tag.Tag_peek(br,"norm");
        }else{
            hasNorm = MoiseScanner_tag.Tag_check(MoiseScanner_variables.temp_peek,"norm");
        }
        if(hasNorm){
            MoiseScanner_identifier_recognition.identifier_recognition(br,"norm",null);
            MoiseScanner_tag.ComposeTagFC(br,"normative","specification");
        }
    }
}
