package Cores;

import ScannerTools.MoiseScanner_identifier_recognition;
import ScannerTools.MoiseScanner_tag;
import java.io.BufferedReader;

public class PropertiesCore {

    public static void Properties(BufferedReader br,String for_property){
        MoiseScanner_tag.simpleCloseTag(br);
        MoiseScanner_tag.TagNC(br,"property");
        MoiseScanner_identifier_recognition.identifier_recognition(br,"property",for_property);
        MoiseScanner_tag.TagFC(br,"properties");
    }

}

