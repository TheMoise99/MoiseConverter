package Cores;

import ScannerTools.*;
import java.io.BufferedReader;
import java.util.ArrayList;
import java.util.Arrays;

public class StructuralSpecificationCore{

    public static void StructuralSpecification(BufferedReader br){
        MoiseScanner_tag.simpleCloseTag(br);
        boolean hasProperties = MoiseScanner_tag.Tag_peek(br,"properties");
        boolean hasRoleDefinitions;
        boolean hasLinkTypes;
        boolean hasGroupSpecification;
        if(hasProperties){
            PropertiesCore.Properties(br,"structural-specification");
            hasRoleDefinitions = MoiseScanner_tag.ComposeTag_peek(br,"role","definitions");
        }else{
            hasRoleDefinitions = MoiseScanner_tag.ComposedTag_dash_peek(br, MoiseScanner_variables.temp_peek,"role","definitions");
        }
        if(hasRoleDefinitions){
            String id = "";
            MoiseScanner_tag.simpleCloseTag(br);
            MoiseScanner_tag.TagNC(br,"role");
            MoiseScanner_variables.cycle = true ;
            while(MoiseScanner_variables.cycle){
                id = MoiseScanner_identifier.return_identifier(br, "id", "role-definitions");
                if(MoiseScanner_variables.peek=='/'){
                    MoiseScanner_tag.simpleCloseTag2(br);
                    MoiseScanner_HashMap.role.put(variables_for_HashMap.index_role, new ArrayList<>(Arrays.asList("role-definitions", "no",id)));
                    variables_for_HashMap.index_role++;
                }else{
                    MoiseScanner_tag.simpleCloseTag(br);
                    MoiseScanner_HashMap.role.put(variables_for_HashMap.index_role, new ArrayList<>(Arrays.asList("role-definitions", "yes",id)));
                    variables_for_HashMap.index_role++;
                    hasProperties = MoiseScanner_tag.Tag_peek(br,"properties");
                    boolean hasExtends;
                    if(hasProperties){
                        PropertiesCore.Properties(br,"inside_role");
                        hasExtends = MoiseScanner_tag.Tag_peek(br,"extends");
                    }else{
                        hasExtends = MoiseScanner_tag.Tag_check(MoiseScanner_variables.temp_peek,"extends");
                    }
                    if(hasExtends){
                        String extends_value = "";
                        String index_father =  MoiseScanner_methods.to_String(variables_for_HashMap.index_role-1);
                        MoiseScanner_variables.cycle = true;
                        while (MoiseScanner_variables.cycle){
                            extends_value = MoiseScanner_identifier.return_identifier(br, "role", "role-definitions_extends");
                            MoiseScanner_tag.simpleCloseTag2(br);
                            MoiseScanner_variables.cycle = MoiseScanner_tag.Tag_peek(br, "extends");
                            MoiseScanner_HashMap.role_extends.put(variables_for_HashMap.index_role_extends, new ArrayList<>(Arrays.asList("role", "no",extends_value,index_father)));
                            variables_for_HashMap.index_role_extends++;
                        }
                    }
                    MoiseScanner_tag.TagFC(br, "role");
                }
                MoiseScanner_variables.cycle = MoiseScanner_tag.Tag_peek(br, "role");
            }
            MoiseScanner_tag.ComposeTagFC(br,"role","definitions");
            hasLinkTypes = MoiseScanner_tag.ComposeTag_peek(br,"link","types");
        }else{
            hasLinkTypes = MoiseScanner_tag.ComposedTag_dash_peek(br, MoiseScanner_variables.temp_peek,"link","types");
        }
        if(hasLinkTypes){
            String id = "";
            MoiseScanner_tag.simpleCloseTag(br);
            MoiseScanner_variables.cycle = true ;
            MoiseScanner_tag.composedTagNC(br, "link", "type");
            while(MoiseScanner_variables.cycle){
                id = MoiseScanner_identifier.return_identifier(br, "id", "link-type");
                MoiseScanner_tag.simpleCloseTag2(br);
                MoiseScanner_variables.cycle = MoiseScanner_tag.ComposeTag_peek(br, "link","type");
                MoiseScanner_HashMap.link_type.put(variables_for_HashMap.index_link_type, new ArrayList<>(Arrays.asList("link-types","no",id)));
                variables_for_HashMap.index_link_type++;
            }
            MoiseScanner_tag.ComposeTagFC(br,"link","types");
            hasGroupSpecification = MoiseScanner_tag.ComposeTag_peek(br,"group","specification");
        }else{
            hasGroupSpecification = MoiseScanner_tag.ComposedTag_dash_peek(br, MoiseScanner_variables.temp_peek,"group","specification");
        }
        if(hasGroupSpecification){
            groupSpecification(br,"structural-specification");
        }
        MoiseScanner_tag.closeComposedTag(br,"structural","specification");
    }

    public static void groupSpecification(BufferedReader br,String from){
        boolean hasProperties = false;
        boolean hasLinks = false;
        boolean hasSubgroups = false;
        boolean hasGroupSpecification = false;
        boolean hasFormationConstraints = false;
        boolean hasCardinality = false;
        boolean hasCompatibility = false;
        boolean hasRoles=false;
        MoiseScanner_identifier_recognition.identifier_recognition(br,"group-specification",from);
        hasProperties = MoiseScanner_tag.Tag_peek(br,"properties");
        if(hasProperties){
            PropertiesCore.Properties(br,"group-specification");
            hasRoles = MoiseScanner_tag.Tag_peek(br,"roles");
        }else{
            hasRoles = MoiseScanner_tag.Tag_check(MoiseScanner_variables.temp_peek,"roles");
        }
        if(hasRoles){
            MoiseScanner_tag.simpleCloseTag(br);
            MoiseScanner_tag.TagNC(br,"role");
            MoiseScanner_identifier_recognition.identifier_recognition(br,"group-specification_role",null);
            MoiseScanner_tag.TagFC(br,"roles");
            hasLinks = MoiseScanner_tag.Tag_peek(br,"links");
        }else{
            hasLinks = MoiseScanner_tag.Tag_check(MoiseScanner_variables.temp_peek,"links");
        }
        if(hasLinks){
            MoiseScanner_tag.simpleCloseTag(br);
            MoiseScanner_tag.TagNC(br,"link");
            MoiseScanner_identifier_recognition.identifier_recognition(br,"link",null);
            MoiseScanner_tag.TagFC(br,"links");
            hasSubgroups = MoiseScanner_tag.Tag_peek(br,"subgroups");
        }else{
            hasSubgroups = MoiseScanner_tag.Tag_check(MoiseScanner_variables.temp_peek,"subgroups");
        }
        if(hasSubgroups){
            MoiseScanner_variables.iSubgroups.add(MoiseScanner_variables.counter_subgroups);
            String father =  MoiseScanner_methods.to_String(MoiseScanner_variables.iSubgroups.get(MoiseScanner_variables.iSubgroups.size()-1));
            MoiseScanner_tag.simpleCloseTag(br);
            boolean hasIncludeGroupSpecification = MoiseScanner_tag.composedTagNC2(br,"include","group","specification");
            if(hasIncludeGroupSpecification){
                String uri = "";
                MoiseScanner_variables.cycle = true ;
                String count_sub = MoiseScanner_methods.to_String(MoiseScanner_variables.counter_subgroups);
                while(MoiseScanner_variables.cycle){
                    uri = MoiseScanner_identifier.return_identifier(br, "uri", "include-group-specification");
                    MoiseScanner_tag.simpleCloseTag2(br);
                    MoiseScanner_variables.cycle = MoiseScanner_tag.composedTagNC2(br, "include", "group", "specification");
                    MoiseScanner_HashMap.include_group_specification.put(variables_for_HashMap.index_include_group_specification, new ArrayList<>(Arrays.asList("subgroups","no",uri,father,count_sub)));
                    variables_for_HashMap.index_include_group_specification++;
                }
            }
            hasGroupSpecification = MoiseScanner_tag.ComposedTag_dash_peek(br, MoiseScanner_variables.temp_peek,"group","specification");
            if(hasGroupSpecification){
                MoiseScanner_variables.cycle = true ;
                while(MoiseScanner_variables.cycle) {
                    groupSpecification(br,"subgroups");
                    MoiseScanner_variables.cycle = MoiseScanner_tag.ComposeTag_peek(br, "group", "specification");
                }
            }
            if(MoiseScanner_variables.peek == '<'){
                MoiseScanner_methods.readch(br);
                MoiseScanner_tag.TagFC(br,"subgroups");
            }else if(MoiseScanner_variables.peek == '/'){
                MoiseScanner_tag.TagFC(br,"subgroups");
            }
            MoiseScanner_variables.iSubgroups.remove(MoiseScanner_variables.iSubgroups.size()-1);
            hasFormationConstraints = MoiseScanner_tag.ComposeTag_peek(br,"formation","constraints");
            MoiseScanner_variables.counter_subgroups++;
        }else{
            hasFormationConstraints = MoiseScanner_tag.ComposedTag_dash_peek(br,MoiseScanner_variables.temp_peek,"formation","constraints");
        }
        if(hasFormationConstraints){
            MoiseScanner_tag.simpleCloseTag(br);
            hasCardinality = MoiseScanner_tag.Tag_peek(br,"cardinality");
            if(hasCardinality){
                MoiseScanner_identifier_recognition.identifier_recognition(br,"cardinality",null);
            }
            hasCompatibility = MoiseScanner_tag.Tag_check(MoiseScanner_variables.temp_peek,"compatibility");
            if(hasCompatibility){
                MoiseScanner_identifier_recognition.identifier_recognition(br,"compatibility",null);
            }
            MoiseScanner_tag.ComposeTagFC(br,"formation","constraints");
        }
        if(MoiseScanner_variables.peek == '<'){
            MoiseScanner_tag.closeComposedTag(br,"group", "specification");
        }else if(MoiseScanner_variables.peek == '/'){
            MoiseScanner_tag.ComposeTagFC(br,"group", "specification");
        }
        MoiseScanner_variables.iGSType.remove(MoiseScanner_variables.iGSType.size()-1);
    }

}