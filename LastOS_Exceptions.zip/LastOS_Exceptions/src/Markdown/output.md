---
>#Title : Markdown file
>###About : File generated with pandoc automation
---

>## Properties

### Property:

| id | value |
|---|---|
| tony | stark | 
| tony | stark | 
| heart | proof | 

---
>## Structural-specification


## Properties

### Property:

| id | value |
|---|---|
| day | other | 
| think | about | 
| about | moments | 



## Role-definitions

### Role:

* painter
    * ###Properties
      #### Property:

      | id | value |
      |---|---|
      |data|inside|
    * __Extends:__ building_company
* baker
* apprentice
* customer
* supplier
* electrician
    * __Extends:__ building_company
* painter
    * __Extends:__ building_company
