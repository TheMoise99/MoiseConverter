package Markdown_manager;

import ScannerTools.MoiseScanner_HashMap;
import ScannerTools.MoiseScanner_methods;
import ScannerTools.MoiseScanner_variables;
import ScannerTools.variables_for_HashMap;
import Sorting_Data.SortingData;
import main.java.Pandoc.Native.Operations;
import main.java.Pandoc.Types.Format;

import java.io.File;
import java.io.IOException;
import java.io.FileWriter;
import java.util.ArrayList;

public class CreateMarkdown{
    public static void creator(){
        ArrayList<Integer> elements = new ArrayList<>();
        try{
            File myObj = new File("C:\\Markdown\\markdown.md");
            FileWriter myWriter = new FileWriter("C:\\Markdown\\markdown.md");
            if(Operations.getOutputFormat()==Format.PDF) {
                myWriter.write("Title: PDF file  \n");
                myWriter.write("About: File generated with Pandoc automation\n");
            }else if(Operations.getOutputFormat()==Format.HTML){
                myWriter.write("---\n");
                myWriter.write("Title: HTML file\n");
                myWriter.write("---\n");
                myWriter.write("\n");
            }else if(Operations.getOutputFormat()==Format.TEX){
                myWriter.write("Title: TEX file  \n");
                myWriter.write("About: File generated with Pandoc automation\n");
            }else{
                myWriter.write("---\n");
                myWriter.write("># Title : Markdown file  \n");
                myWriter.write(">### About : File generated with Pandoc automation\n");
                myWriter.write("---\n");
                myWriter.write("\n");
            }

            if(MoiseScanner_HashMap.property.size()>0) {
                elements = SortingData.SortData("property", "none", null);
                if (elements.size() >= 1){
                    if(Operations.getOutputFormat()==Format.PDF||Operations.getOutputFormat()==Format.HTML||Operations.getOutputFormat()==Format.TEX){
                        myWriter.write("## Properties\n");
                    }else{
                        myWriter.write(">## Properties\n");
                    }
                    myWriter.write("\n");
                    myWriter.write("### Property: \n");
                    myWriter.write("\n");
                    myWriter.write("| id | value |\n");
                    myWriter.write("|---|---|\n");
                    for (int i = 0; i < elements.size(); i++) {
                        myWriter.write("| " + MoiseScanner_HashMap.property.get(elements.get(i)).get(2)
                                + " | " + MoiseScanner_HashMap.property.get(elements.get(i)).get(3) + " | \n");
                    }
                }
            }
            if(Operations.getOutputFormat()==Format.PDF||Operations.getOutputFormat()==Format.HTML||Operations.getOutputFormat()==Format.TEX){
                myWriter.write("\n");
            }else{
                myWriter.write("\n");
                myWriter.write("---\n");
            }
            if(MoiseScanner_variables.SSType){
                if(Operations.getOutputFormat()==Format.PDF||Operations.getOutputFormat()==Format.HTML||Operations.getOutputFormat()==Format.TEX){
                    myWriter.write("## Structural-specification\n");
                }else{
                    myWriter.write(">## Structural-specification\n");
                }
            }
            if(elements.size()>0){
                elements.clear();
            }
            elements = SortingData.SortData("property","structural-specification",null);
            if(elements.size()>=1){
                myWriter.write("\n");
                myWriter.write("\n");
                myWriter.write("## Properties\n");
                myWriter.write("\n");
                myWriter.write("### Property: \n");
                myWriter.write("\n");
                myWriter.write("| id | value |\n");
                myWriter.write("|---|---|\n");
                for(int i=0;i<elements.size();i++){
                    myWriter.write("| " + MoiseScanner_HashMap.property.get(elements.get(i)).get(2)
                            + " | " + MoiseScanner_HashMap.property.get(elements.get(i)).get(3) + " | \n");
                }
            }
            if(elements.size()>0){
                elements.clear();
            }
            if(MoiseScanner_HashMap.role.size()>0){
                elements = SortingData.SortData("role","all",null);
                if(elements.size()>=1){
                    myWriter.write("\n");
                    myWriter.write("\n");
                    myWriter.write("## Role-definitions\n");
                    myWriter.write("\n");
                    myWriter.write("### Role: \n");
                    myWriter.write("\n");
                    for(int i=0;i<elements.size();i++){
                        myWriter.write("* " + MoiseScanner_HashMap.role.get(i).get(2) + "\n");
                        if(MoiseScanner_HashMap.role.get(i).get(1).equals("yes")){
                            ArrayList<Integer> property = new ArrayList<>();
                            property = SortingData.SortData("role","inside_role",i);
                            if(property.size()>1){
                                myWriter.write("    * ### Properties\n");
                                myWriter.write("      #### Property: \n");
                                myWriter.write("\n");
                                myWriter.write("        | id | value |\n");
                                myWriter.write("        |---|---|\n");
                                for(int j=0; j<property.size();j++){
                                    myWriter.write("        | " + MoiseScanner_HashMap.property.get(property.get(j)).get(2)
                                            + " | " + MoiseScanner_HashMap.property.get(property.get(j)).get(3) + " | \n");
                                }
                            }
                            ArrayList<Integer> extend = new ArrayList<>();
                            extend = SortingData.SortData("role","extends",i);
                            for(int k=0;k<extend.size();k++){
                                myWriter.write("    * __Extends:__ " + MoiseScanner_HashMap.role_extends.get(extend.get(k)).get(2) + "\n");
                            }
                        }
                    }
                }
            }
            if(elements.size()>0){
                elements.clear();
            }
            if(MoiseScanner_HashMap.link_type.size()>0){
                myWriter.write("\n");
                myWriter.write("### Link-types\n");
                myWriter.write("#### Link-types:\n");
                myWriter.write("\n");
                elements = SortingData.SortData("link-type","all",null);
                for(int i=0;i<elements.size();i++){
                    myWriter.write("* " + MoiseScanner_HashMap.link_type.get(i).get(2)  + "\n");
                }
            }
            if(elements.size()>0){
                elements.clear();
            }
            int counter_group_specification = 0;
            boolean condition = false;
            boolean print_Subgroups = false;
            boolean print_form_constraints = false;
            do{
                print_form_constraints = false;
                if(MoiseScanner_HashMap.group_specification.size()>0){
                    myWriter.write("\n");
                    myWriter.write("## Group-specification\n");
                    String gs_min = "";
                    String gs_max = "";
                    String ref_to = "";
                    if(!MoiseScanner_HashMap.group_specification.get(counter_group_specification).get(3).equals("")){
                        gs_min = MoiseScanner_HashMap.group_specification.get(counter_group_specification).get(3);
                    }
                    if(!MoiseScanner_HashMap.group_specification.get(counter_group_specification).get(4).equals("")){
                        gs_max = MoiseScanner_HashMap.group_specification.get(counter_group_specification).get(4);
                    }
                    ref_to = MoiseScanner_HashMap.group_specification.get(counter_group_specification).get(5);
                    myWriter.write("\n");
                    myWriter.write("* __Id:__ " + MoiseScanner_HashMap.group_specification.get(counter_group_specification).get(2) + "\n");
                    myWriter.write("* __Min:__ " + gs_min + "\n");
                    myWriter.write("* __Max:__ " + gs_max + "\n");
                    myWriter.write("* __Referred to subgroups:__ " + ref_to + "\n");
                    myWriter.write("\n");
                    ArrayList<Integer> property = new ArrayList<>();
                    property = SortingData.SortData("property", "group-specification",counter_group_specification);
                    if(property.size() > 1){
                        myWriter.write("### Properties\n");
                        myWriter.write("#### Property: \n");
                        myWriter.write("\n");
                        myWriter.write("| id | value |\n");
                        myWriter.write("|---|---|\n");
                        for (int j = 0; j < property.size(); j++) {
                            myWriter.write("| " + MoiseScanner_HashMap.property.get(property.get(j)).get(2)
                                    + " | " + MoiseScanner_HashMap.property.get(property.get(j)).get(3) + " | \n");
                        }
                    }
                    if(elements.size()>0){
                        elements.clear();
                    }
                    if(MoiseScanner_HashMap.roles_role.size()>0){
                        elements = SortingData.SortData("roles_role", "by_index", counter_group_specification);
                        if(elements.size() > 0){
                            myWriter.write("\n");
                            myWriter.write("### Roles\n");
                            myWriter.write("#### Role: \n");
                            myWriter.write("\n");
                            myWriter.write("| id | min | max |\n");
                            myWriter.write("|---|---|---|\n");
                        }
                        for(int i = 0; i < elements.size(); i++){
                            String min = "";
                            String max = "";
                            if(!MoiseScanner_HashMap.roles_role.get(elements.get(i)).get(3).equals("")) {
                                min = MoiseScanner_HashMap.roles_role.get(elements.get(i)).get(3);
                            }
                            if(!MoiseScanner_HashMap.roles_role.get(elements.get(i)).get(4).equals("")) {
                                max = MoiseScanner_HashMap.roles_role.get(elements.get(i)).get(4);
                            }
                            myWriter.write("| " + MoiseScanner_HashMap.roles_role.get(elements.get(i)).get(2) + " | " + min + " | " + max + " | \n");
                        }
                    }
                    if(elements.size()>0){
                        elements.clear();
                    }
                    if(MoiseScanner_HashMap.link.size()>0){
                        elements = SortingData.SortData("link", "by_index", counter_group_specification);
                        if(elements.size()>0){
                            myWriter.write("\n");
                            myWriter.write("### Links\n");
                            myWriter.write("#### Link: \n");
                            myWriter.write("\n");
                            myWriter.write("| from | to | type | scope | extends-subgroups | bi-dir |\n");
                            myWriter.write("|---|---|---|---|---|---|\n");
                            for (int i=0;i<elements.size();i++){
                                String from = "";
                                String to = "";
                                String type = "";
                                String scope = "";
                                String extends_subgroups = "";
                                String bi_dir = "";
                                if(!MoiseScanner_HashMap.link.get(elements.get(i)).get(2).equals("")){
                                    from = MoiseScanner_HashMap.link.get(elements.get(i)).get(2);
                                }
                                if(!MoiseScanner_HashMap.link.get(elements.get(i)).get(3).equals("")){
                                    to = MoiseScanner_HashMap.link.get(elements.get(i)).get(3);
                                }
                                if(!MoiseScanner_HashMap.link.get(elements.get(i)).get(4).equals("")){
                                    type = MoiseScanner_HashMap.link.get(elements.get(i)).get(4);
                                }
                                if(!MoiseScanner_HashMap.link.get(elements.get(i)).get(5).equals("")){
                                    scope = MoiseScanner_HashMap.link.get(elements.get(i)).get(5);
                                }
                                if(!MoiseScanner_HashMap.link.get(elements.get(i)).get(6).equals("")){
                                    extends_subgroups = MoiseScanner_HashMap.link.get(elements.get(i)).get(6);
                                }
                                if(!MoiseScanner_HashMap.link.get(elements.get(i)).get(7).equals("")){
                                    bi_dir = MoiseScanner_HashMap.link.get(elements.get(i)).get(7);
                                }
                                myWriter.write("| " + from + " | " + to + " | " + type + "| " + scope + " | " + extends_subgroups + " | " + bi_dir + " | \n");
                            }
                        }
                    }
                    if(elements.size()>0){
                        elements.clear();
                    }
                    if(MoiseScanner_HashMap.include_group_specification.size()>0){
                        elements = SortingData.SortData("subgroups", "include_group_specification", counter_group_specification);
                        if(elements.size()>0){
                            print_Subgroups = true;
                            myWriter.write("\n");
                            myWriter.write("### Subgroups " + MoiseScanner_HashMap.group_specification.get(counter_group_specification).get(6) +"\n");
                            myWriter.write("#### Include-group-specification: \n");
                            myWriter.write("\n");
                        }
                        for(int i = 0; i < elements.size(); i++){
                            myWriter.write("* " + MoiseScanner_HashMap.include_group_specification.get(elements.get(i)).get(2) + "\n");
                        }
                    }
                    if(elements.size()>0){
                        elements.clear();
                    }
                    MoiseScanner_variables.iGS.add(counter_group_specification);
                    counter_group_specification++;
                    if(counter_group_specification<MoiseScanner_HashMap.group_specification.size()&&MoiseScanner_HashMap.group_specification.size()>1){
                        if(!print_Subgroups&&!MoiseScanner_HashMap.group_specification.get(counter_group_specification).get(5).equals(MoiseScanner_HashMap.group_specification.get(counter_group_specification-1).get(5))){
                            myWriter.write("\n");
                            myWriter.write("### Subgroups " + MoiseScanner_HashMap.group_specification.get(counter_group_specification).get(6) +"\n");
                        }
                        print_Subgroups = false;
                        condition = true;
                    }else{
                        condition = false;
                    }
                    if(elements.size()>0){
                        elements.clear();
                    }
                    if(MoiseScanner_HashMap.cardinality.size()>0){
                        int index = MoiseScanner_variables.iGS.get(MoiseScanner_variables.iGS.size()-1);
                        elements = SortingData.SortData("cardinality", "by_index",index);
                        if(elements.size()>0){
                            print_form_constraints = true;
                            myWriter.write("\n");
                            myWriter.write("### Formation-constraints\n");
                            myWriter.write("#### Cardinality: \n");
                            myWriter.write("\n");
                            myWriter.write("| id | object | min | max |\n");
                            myWriter.write("|---|---|---|---|\n");
                            for(int i=0;i<elements.size();i++){
                                String min = "";
                                String max = "";
                                if(!MoiseScanner_HashMap.cardinality.get(elements.get(i)).get(2).equals("")){
                                    min = MoiseScanner_HashMap.cardinality.get(elements.get(i)).get(2);
                                }
                                if(!MoiseScanner_HashMap.cardinality.get(elements.get(i)).get(3).equals("")){
                                    max = MoiseScanner_HashMap.cardinality.get(elements.get(i)).get(3);
                                }
                                myWriter.write("| " + MoiseScanner_HashMap.cardinality.get(elements.get(i)).get(5) + " | " +
                                        MoiseScanner_HashMap.cardinality.get(elements.get(i)).get(4) + " | " + min + "| " + max + " | \n");
                            }
                        }
                    }
                    if(elements.size()>0){
                        elements.clear();
                    }
                    if(MoiseScanner_HashMap.compatibility.size()>0){
                        int index = MoiseScanner_variables.iGS.get(MoiseScanner_variables.iGS.size()-1);
                        elements = SortingData.SortData("compatibility", "by_index",index);
                        if(elements.size()>0){
                            if(!print_form_constraints){
                                myWriter.write("\n");
                                myWriter.write("### Formation-constraints\n");
                            }
                            myWriter.write("\n");
                            myWriter.write("#### Compatibility: \n");
                            myWriter.write("\n");
                            myWriter.write("| from | to | type | scope | extends-subgroups | bi-dir |\n");
                            myWriter.write("|---|---|---|---|---|---|\n");
                            for(int i=0;i<elements.size();i++){
                                String type = "";
                                String scope = "";
                                String extends_subgroups = "";
                                String bi_dir = "";
                                if(!MoiseScanner_HashMap.compatibility.get(elements.get(i)).get(4).equals("")){
                                    type = MoiseScanner_HashMap.compatibility.get(elements.get(i)).get(4);
                                }
                                if(!MoiseScanner_HashMap.compatibility.get(elements.get(i)).get(5).equals("")){
                                    scope = MoiseScanner_HashMap.compatibility.get(elements.get(i)).get(5);
                                }
                                if(!MoiseScanner_HashMap.compatibility.get(elements.get(i)).get(6).equals("")){
                                    extends_subgroups = MoiseScanner_HashMap.compatibility.get(elements.get(i)).get(6);
                                }
                                if(!MoiseScanner_HashMap.compatibility.get(elements.get(i)).get(7).equals("")){
                                    bi_dir = MoiseScanner_HashMap.compatibility.get(elements.get(i)).get(7);
                                }
                                myWriter.write("| " + MoiseScanner_HashMap.compatibility.get(elements.get(i)).get(2) + " | "
                                        + MoiseScanner_HashMap.compatibility.get(elements.get(i)).get(3) + " | " + type + "| " + scope + " | " + extends_subgroups + " | " + bi_dir + " | \n");
                            }
                        }
                    }
                    MoiseScanner_variables.iGS.remove(MoiseScanner_variables.iGS.size()-1);
                }
            }while(condition);

            if(MoiseScanner_variables.FSType){
                myWriter.write("\n");
                if(Operations.getOutputFormat()==Format.PDF||Operations.getOutputFormat()==Format.HTML||Operations.getOutputFormat()==Format.TEX){
                    myWriter.write("## Functional-specification\n");
                }else{
                    myWriter.write("---\n");
                    myWriter.write(">## Functional-specification\n");
                }
                if(elements.size()>0){
                    elements.clear();
                }
                elements = SortingData.SortData("property","functional-specification",null);
                if(elements.size()>=1){
                    myWriter.write("\n");
                    myWriter.write("\n");
                    myWriter.write("## Properties\n");
                    myWriter.write("\n");
                    myWriter.write("### Property: \n");
                    myWriter.write("\n");
                    myWriter.write("| id | value |\n");
                    myWriter.write("|---|---|\n");
                    for(int i=0;i<elements.size();i++){
                        myWriter.write("| " + MoiseScanner_HashMap.property.get(elements.get(i)).get(2)
                                + " | " + MoiseScanner_HashMap.property.get(elements.get(i)).get(3) + " | \n");
                    }
                }
                if(elements.size()>0){
                    elements.clear();
                }
                if(MoiseScanner_HashMap.fs_scheme.size()>0){
                    for(int i=0;i<MoiseScanner_HashMap.fs_scheme.size();i++){
                        myWriter.write("\n");
                        myWriter.write("## Scheme " + i + " id: " + MoiseScanner_HashMap.fs_scheme.get(i).get(2) + "\n");
                        elements = SortingData.SortData("property","scheme",i);
                        if(elements.size()>1){
                            myWriter.write("### Properties\n");
                            myWriter.write("#### Property: \n");
                            myWriter.write("\n");
                            myWriter.write("| id | value |\n");
                            myWriter.write("|---|---|\n");
                            for(int j=0;j<elements.size();j++){
                                myWriter.write("| " + MoiseScanner_HashMap.property.get(elements.get(j)).get(2)
                                        + " | " + MoiseScanner_HashMap.property.get(elements.get(j)).get(3) + " | \n");
                            }
                        }
                        if(elements.size()>0){
                            elements.clear();
                        }
                        if(MoiseScanner_HashMap.fs_goal.size()>0){
                            elements = SortingData.SortData("goal","scheme",i);
                            if(elements.size()>0){
                                String min = "";
                                String ds = "";
                                String type = "";
                                String ttf = "";
                                String location = "";
                                if(!MoiseScanner_HashMap.fs_goal.get(elements.get(0)).get(3).equals("")){
                                    min = MoiseScanner_HashMap.fs_goal.get(elements.get(0)).get(3);
                                }
                                if(!MoiseScanner_HashMap.fs_goal.get(elements.get(0)).get(4).equals("")){
                                    ds = MoiseScanner_HashMap.fs_goal.get(elements.get(0)).get(4);
                                }
                                if(!MoiseScanner_HashMap.fs_goal.get(elements.get(0)).get(5).equals("")){
                                    type = MoiseScanner_HashMap.fs_goal.get(elements.get(0)).get(5);
                                }
                                if(!MoiseScanner_HashMap.fs_goal.get(elements.get(0)).get(6).equals("")){
                                    ttf = MoiseScanner_HashMap.fs_goal.get(elements.get(0)).get(6);
                                }
                                if(!MoiseScanner_HashMap.fs_goal.get(elements.get(0)).get(7).equals("")){
                                    location = MoiseScanner_HashMap.fs_goal.get(elements.get(0)).get(7);
                                }
                                myWriter.write("\n");
                                myWriter.write("### Goal referred to scheme: " + i + "\n");
                                myWriter.write("\n");
                                myWriter.write("| id | min | ds | type | ttf | location |\n");
                                myWriter.write("|---|---|---|---|---|---|\n");
                                myWriter.write("| " + MoiseScanner_HashMap.fs_goal.get(elements.get(0)).get(2)
                                        + " | " + min + " | " + ds  + " | " + type + " | " + ttf + " | " + location + " | \n");
                                min = "";
                                ds = "";
                                type = "";
                                ttf = "";
                                location = "";
                                if(MoiseScanner_HashMap.fs_goal.get(elements.get(0)).get(1).equals("yes")){
                                    int index = elements.get(0);
                                    boolean main_goal=true;
                                    do{
                                        if(main_goal==false){
                                            index = MoiseScanner_variables.goal_list.get(0);
                                            MoiseScanner_variables.goal_list.remove(0);
                                        }
                                        elements.clear();
                                        elements = SortingData.SortData("argument", "goal", index);
                                        if (elements.size() > 0) {
                                            myWriter.write("\n");
                                            myWriter.write("#### Argument referred to goal: " + MoiseScanner_HashMap.fs_goal.get(index).get(2) + "\n");
                                            myWriter.write("\n");
                                            myWriter.write("| id | value |\n");
                                            myWriter.write("|---|---|\n");
                                            for (int j = 0; j < elements.size(); j++) {
                                                myWriter.write("| " + MoiseScanner_HashMap.fs_argument.get(elements.get(j)).get(2)
                                                        + " | " + MoiseScanner_HashMap.fs_argument.get(elements.get(j)).get(3) + " | \n");
                                            }
                                        }
                                        if (elements.size() > 0) {
                                            elements.clear();
                                        }
                                        elements = SortingData.SortData("depends-on", "goal", index);
                                        if (elements.size() > 0) {
                                            myWriter.write("\n");
                                            myWriter.write("#### Depends-on referred to goal: " + MoiseScanner_HashMap.fs_goal.get(index).get(2) + "\n");
                                            myWriter.write("\n");
                                            for (int j = 0; j < elements.size(); j++) {
                                                myWriter.write("* __Id__: " + MoiseScanner_HashMap.fs_depends_on.get(elements.get(j)).get(2) + "\n");
                                            }
                                        }
                                        if(elements.size()>0){
                                            elements.clear();
                                        }
                                        elements = SortingData.SortData("plan", "goal", index);
                                        if (elements.size() > 0) {
                                            myWriter.write("\n");
                                            myWriter.write("#### Plan " + index + " referred to goal: " + MoiseScanner_HashMap.fs_goal.get(index).get(2) + "\n");
                                            myWriter.write("\n");
                                            myWriter.write("| operator | success-rate |\n");
                                            myWriter.write("|---|---|\n");
                                            for (int j = 0; j < elements.size(); j++) {
                                                myWriter.write("| " + MoiseScanner_HashMap.fs_plan.get(elements.get(j)).get(2)
                                                        + " | " + MoiseScanner_HashMap.fs_plan.get(elements.get(j)).get(3) + " | \n");
                                                if (MoiseScanner_HashMap.fs_plan.get(elements.get(j)).get(1).equals("yes")) {
                                                    ArrayList<Integer> property = new ArrayList<>();
                                                    property = SortingData.SortData("property", "plan", elements.get(0));
                                                    if (property.size() > 1) {
                                                        myWriter.write("\n");
                                                        myWriter.write("*   ### Properties\n");
                                                        myWriter.write("    *   #### Property: \n");
                                                        myWriter.write("\n");
                                                        myWriter.write("        | id | value |\n");
                                                        myWriter.write("        |---|---|\n");
                                                        for (int k = 0; k < property.size(); k++) {
                                                            myWriter.write("        | " + MoiseScanner_HashMap.property.get(property.get(k)).get(2)
                                                                    + " | " + MoiseScanner_HashMap.property.get(property.get(k)).get(3) + " | \n");
                                                        }
                                                    }
                                                    property.clear();
                                                    ArrayList<Integer> goal = new ArrayList<>();
                                                    goal = SortingData.SortData("goal", "plan", elements.get(j));
                                                    if(goal.size()>0){
                                                        myWriter.write("\n");
                                                        myWriter.write("#### Goal referred to plan: " + index + "\n");
                                                        myWriter.write("\n");
                                                        myWriter.write("| id | min | ds | type | ttf | location |\n");
                                                        myWriter.write("|---|---|---|---|---|---|\n");
                                                    }
                                                    for (int p = 0; p < goal.size(); p++) {
                                                        if (!MoiseScanner_HashMap.fs_goal.get(goal.get(p)).get(3).equals("")) {
                                                            min = MoiseScanner_HashMap.fs_goal.get(goal.get(p)).get(3);
                                                        }
                                                        if (!MoiseScanner_HashMap.fs_goal.get(goal.get(p)).get(4).equals("")) {
                                                            ds = MoiseScanner_HashMap.fs_goal.get(goal.get(p)).get(4);
                                                        }
                                                        if (!MoiseScanner_HashMap.fs_goal.get(goal.get(p)).get(5).equals("")) {
                                                            type = MoiseScanner_HashMap.fs_goal.get(goal.get(p)).get(5);
                                                        }
                                                        if (!MoiseScanner_HashMap.fs_goal.get(goal.get(p)).get(6).equals("")) {
                                                            ttf = MoiseScanner_HashMap.fs_goal.get(goal.get(p)).get(6);
                                                        }
                                                        if (!MoiseScanner_HashMap.fs_goal.get(goal.get(p)).get(7).equals("")) {
                                                            location = MoiseScanner_HashMap.fs_goal.get(goal.get(p)).get(7);
                                                        }
                                                        if (MoiseScanner_HashMap.fs_goal.get(goal.get(p)).get(1).equals("yes")) {
                                                            MoiseScanner_variables.goal_list.add(goal.get(p));
                                                        }
                                                        myWriter.write("| " + MoiseScanner_HashMap.fs_goal.get(goal.get(p)).get(2)
                                                                + " | " + min + " | " + ds + " | " + type + " | " + ttf + " | " + location + " | \n");
                                                        min = "";
                                                        ds = "";
                                                        type = "";
                                                        ttf = "";
                                                        location = "";
                                                    }
                                                }
                                            }
                                        }
                                        main_goal = false;
                                    }
                                    while(MoiseScanner_variables.goal_list.size()>0);
                                }
                            }
                        }
                        if(elements.size()>0){
                            elements.clear();
                        }
                        elements = SortingData.SortData("notification-policy","by_index",i);
                        for(int w=0;w<elements.size();w++){
                            myWriter.write("\n");
                            myWriter.write("## Notification-policy referred to scheme " + i + "\n");
                            myWriter.write("* __Id__: " + MoiseScanner_HashMap.fs_notification_policy.get(elements.get(w)).get(2) + "\n");
                            myWriter.write("* __Target__: " + MoiseScanner_HashMap.fs_notification_policy.get(elements.get(w)).get(3) + "\n");
                            myWriter.write("* __Condition__: " + MoiseScanner_HashMap.fs_notification_policy.get(elements.get(w)).get(4) + "\n");
                            ArrayList<Integer> property = new ArrayList<>();
                            property = SortingData.SortData("property","notification-policy",elements.get(w));
                            if(property.size()>0){
                                myWriter.write("\n");
                                myWriter.write("*   ### Properties\n");
                                myWriter.write("\n");
                                myWriter.write("    *   #### Property: \n");
                                myWriter.write("\n");
                                myWriter.write("        | id | value |\n");
                                myWriter.write("        |---|---|\n");
                                for(int y=0;y<property.size();y++){
                                    myWriter.write("        | " + MoiseScanner_HashMap.property.get(property.get(y)).get(2)
                                            + " | " + MoiseScanner_HashMap.property.get((property.get(y))).get(3) + " | \n");
                                }
                            }
                            if(property.size()>0){
                                property.clear();
                            }
                            myWriter.write("\n");
                            myWriter.write("* ### Exception-specification __Id__: " + MoiseScanner_HashMap.fs_exception_specification.get(elements.get(w)).get(2) + "\n");
                            myWriter.write("\n");
                            ArrayList<Integer> ex_argument = new ArrayList<>();
                            ex_argument = SortingData.SortData("exception-argument","by_index",elements.get(w));
                            if(ex_argument.size()>0){
                                myWriter.write("    * #### Exception-argument: \n");
                                myWriter.write("\n");
                                myWriter.write("        | id | arity |\n");
                                myWriter.write("        |---|---|\n");
                                for(int y=0;y<ex_argument.size();y++){
                                    myWriter.write("        | " + MoiseScanner_HashMap.fs_exception_argument.get(ex_argument.get(y)).get(2)
                                            + " | " + MoiseScanner_HashMap.fs_exception_argument.get((ex_argument.get(y))).get(3) + " | \n");
                                }
                            }
                            if(MoiseScanner_HashMap.fs_raising_goal.size()>0){
                                myWriter.write("    *   #### Raising-goal: \n");
                                myWriter.write("\n");
                                myWriter.write("        | id | min | ds | type | ttf | location | when |\n");
                                myWriter.write("        |---|---|---|---|---|---|---|\n");
                                ArrayList<Integer> raising_goal = new ArrayList<>();
                                raising_goal = SortingData.SortData("raising-goal","by_index",elements.get(w));
                                if(raising_goal.size()>0){
                                    String min;
                                    String ds;
                                    String type;
                                    String ttf;
                                    String location;
                                    String when;
                                    for(int g=0;g<raising_goal.size();g++) {

                                        min = MoiseScanner_HashMap.fs_raising_goal.get(raising_goal.get(g)).get(3);
                                        ds = MoiseScanner_HashMap.fs_raising_goal.get(raising_goal.get(g)).get(4);
                                        type = MoiseScanner_HashMap.fs_raising_goal.get(raising_goal.get(g)).get(5);
                                        ttf = MoiseScanner_HashMap.fs_raising_goal.get(raising_goal.get(g)).get(6);
                                        location = MoiseScanner_HashMap.fs_raising_goal.get(raising_goal.get(g)).get(7);
                                        when = MoiseScanner_HashMap.fs_raising_goal.get(raising_goal.get(g)).get(8);

                                        myWriter.write("        | " + MoiseScanner_HashMap.fs_raising_goal.get(raising_goal.get(g)).get(2)
                                                + " | " + min + " | " + ds + " | " + type + " | " + ttf + " | " + location + " | " + when + " | \n");
                                    }
                                    for(int g=0;g<raising_goal.size();g++) {
                                        if(MoiseScanner_HashMap.fs_raising_goal.get(raising_goal.get(g)).get(1).equals("yes")) {
                                            int index = raising_goal.get(g);
                                            boolean main_raisingGoal = true;
                                            do{
                                                if (!main_raisingGoal) {
                                                    index = MoiseScanner_variables.goal_list.get(0);
                                                    MoiseScanner_variables.goal_list.remove(0);
                                                }
                                                ArrayList<Integer> arg_raising = new ArrayList<>();
                                                arg_raising = SortingData.SortData("argument", "raising-goal", index);
                                                if (arg_raising.size() > 0) {
                                                    myWriter.write("\n");
                                                    myWriter.write("        * ####Argument referred to raising-goal: " + MoiseScanner_HashMap.fs_raising_goal.get(index).get(2) + "\n");
                                                    myWriter.write("\n");
                                                    myWriter.write("            | id | value |\n");
                                                    myWriter.write("            |---|---|\n");
                                                    for (int j = 0; j < arg_raising.size(); j++) {
                                                        myWriter.write("            | " + MoiseScanner_HashMap.fs_argument.get(arg_raising.get(j)).get(2)
                                                                + " | " + MoiseScanner_HashMap.fs_argument.get(arg_raising.get(j)).get(3) + " | \n");
                                                    }
                                                }
                                                ArrayList<Integer> dep_raising = new ArrayList<>();
                                                dep_raising = SortingData.SortData("depends-on", "raising-goal",index);
                                                if(dep_raising.size()>0){
                                                    myWriter.write("\n");
                                                    myWriter.write("        * ####Depends-on referred to raising-goal: " + MoiseScanner_HashMap.fs_raising_goal.get(index).get(2) + "\n");
                                                    myWriter.write("\n");
                                                    myWriter.write("            | goal |\n");
                                                    myWriter.write("            |---|\n");
                                                    for(int j=0;j<dep_raising.size();j++){
                                                        myWriter.write("            | " + MoiseScanner_HashMap.fs_depends_on.get(dep_raising.get(j)).get(2) + " | \n");
                                                    }
                                                }
                                                ArrayList<Integer> rais_plan = new ArrayList<>();
                                                rais_plan = SortingData.SortData("plan", "raising-goal",index);
                                                if(rais_plan.size()>0){
                                                    myWriter.write("\n");
                                                    myWriter.write("        * ####Plan " + rais_plan.get(0) + " referred to raising-goal: " + MoiseScanner_HashMap.fs_raising_goal.get(index).get(2) + "\n");
                                                    myWriter.write("\n");
                                                    myWriter.write("            | operator | success-rate |\n");
                                                    myWriter.write("            |---|---|\n");
                                                    myWriter.write("            | " + MoiseScanner_HashMap.fs_plan.get(rais_plan.get(0)).get(2)
                                                            + " | " + MoiseScanner_HashMap.fs_plan.get(rais_plan.get(0)).get(3) + " | \n");
                                                    if(MoiseScanner_HashMap.fs_plan.get(rais_plan.get(0)).get(1).equals("yes")){
                                                        ArrayList<Integer> goal_rs = new ArrayList<>();
                                                        goal_rs = SortingData.SortData("goal", "plan", rais_plan.get(0));
                                                        if(goal_rs.size()>0){
                                                            myWriter.write("\n");
                                                            myWriter.write("            * #### Goal referred to plan: " + rais_plan.get(0) + "\n");
                                                            myWriter.write("\n");
                                                            myWriter.write("                | id | min | ds | type | ttf | location |\n");
                                                            myWriter.write("                |---|---|---|---|---|---|\n");
                                                        }
                                                        for(int q=0;q<goal_rs.size();q++){
                                                            min = MoiseScanner_HashMap.fs_goal.get(goal_rs.get(q)).get(3);
                                                            ds = MoiseScanner_HashMap.fs_goal.get(goal_rs.get(q)).get(4);
                                                            type = MoiseScanner_HashMap.fs_goal.get(goal_rs.get(q)).get(5);
                                                            ttf = MoiseScanner_HashMap.fs_goal.get(goal_rs.get(q)).get(6);
                                                            location = MoiseScanner_HashMap.fs_goal.get(goal_rs.get(q)).get(7);
                                                            if(MoiseScanner_HashMap.fs_goal.get(goal_rs.get(q)).get(1).equals("yes")) {
                                                                MoiseScanner_variables.goal_list.add(goal_rs.get(q));
                                                            }
                                                            myWriter.write("                | " + MoiseScanner_HashMap.fs_goal.get(goal_rs.get(q)).get(2)
                                                                    + " | " + min + " | " + ds + " | " + type + " | " + ttf + " | " + location + " | \n");
                                                            min = "";
                                                            ds = "";
                                                            type = "";
                                                            ttf = "";
                                                            location = "";
                                                        }
                                                        while(MoiseScanner_variables.goal_list.size()>0){
                                                            int indexing = MoiseScanner_variables.goal_list.get(0);
                                                            MoiseScanner_variables.goal_list.remove(0);
                                                            arg_raising.clear();
                                                            dep_raising.clear();
                                                            rais_plan.clear();
                                                            arg_raising = SortingData.SortData("argument", "goal", indexing);
                                                            if(arg_raising.size()>0){
                                                                myWriter.write("\n");
                                                                myWriter.write("                * ####Argument referred to goal: " + MoiseScanner_HashMap.fs_goal.get(indexing).get(2) + "\n");
                                                                myWriter.write("\n");
                                                                myWriter.write("                    | id | value |\n");
                                                                myWriter.write("                    |---|---|\n");
                                                                for (int j = 0; j < arg_raising.size(); j++) {
                                                                    myWriter.write("                    | " + MoiseScanner_HashMap.fs_argument.get(arg_raising.get(j)).get(2)
                                                                            + " | " + MoiseScanner_HashMap.fs_argument.get(arg_raising.get(j)).get(3) + " | \n");
                                                                }
                                                            }
                                                            dep_raising = SortingData.SortData("depends-on", "goal",indexing);
                                                            if(dep_raising.size()>0){
                                                                myWriter.write("\n");
                                                                myWriter.write("                * ####Depends-on referred to goal: " + MoiseScanner_HashMap.fs_goal.get(indexing).get(2) + "\n");
                                                                myWriter.write("\n");
                                                                myWriter.write("                    | goal |\n");
                                                                myWriter.write("                    |---|\n");
                                                                for(int j=0;j<dep_raising.size();j++){
                                                                    myWriter.write("                    | " + MoiseScanner_HashMap.fs_depends_on.get(dep_raising.get(j)).get(2) + " | \n");
                                                                }
                                                            }
                                                            rais_plan = SortingData.SortData("plan", "goal",indexing);
                                                            if(rais_plan.size()>0){
                                                                myWriter.write("\n");
                                                                myWriter.write("                * ####Plan " + rais_plan.get(0) + " referred to goal: " + MoiseScanner_HashMap.fs_goal.get(indexing).get(2) + "\n");
                                                                myWriter.write("\n");
                                                                myWriter.write("                    | operator | success-rate |\n");
                                                                myWriter.write("                    |---|---|\n");
                                                                myWriter.write("                    | " + MoiseScanner_HashMap.fs_plan.get(rais_plan.get(0)).get(2)
                                                                        + " | " + MoiseScanner_HashMap.fs_plan.get(rais_plan.get(0)).get(3) + " | \n");
                                                            }
                                                            ArrayList<Integer> goal_ch = new ArrayList<>();
                                                            goal_ch = SortingData.SortData("goal", "plan", rais_plan.get(0));
                                                            if(goal_ch.size()>0){
                                                                myWriter.write("\n");
                                                                myWriter.write("                * #### Goal referred to plan: " + rais_plan.get(0) + "\n");
                                                                myWriter.write("\n");
                                                                myWriter.write("                    | id | min | ds | type | ttf | location |\n");
                                                                myWriter.write("                    |---|---|---|---|---|---|\n");
                                                            }
                                                            for(int q=0;q<goal_ch.size();q++){
                                                                min = MoiseScanner_HashMap.fs_goal.get(goal_ch.get(q)).get(3);
                                                                ds = MoiseScanner_HashMap.fs_goal.get(goal_ch.get(q)).get(4);
                                                                type = MoiseScanner_HashMap.fs_goal.get(goal_ch.get(q)).get(5);
                                                                ttf = MoiseScanner_HashMap.fs_goal.get(goal_ch.get(q)).get(6);
                                                                location = MoiseScanner_HashMap.fs_goal.get(goal_ch.get(q)).get(7);
                                                                if(MoiseScanner_HashMap.fs_goal.get(goal_ch.get(q)).get(1).equals("yes")) {
                                                                    MoiseScanner_variables.goal_list.add(goal_ch.get(q));
                                                                }
                                                                myWriter.write("                    | " + MoiseScanner_HashMap.fs_goal.get(goal_ch.get(q)).get(2)
                                                                        + " | " + min + " | " + ds + " | " + type + " | " + ttf + " | " + location + " | \n");
                                                                min = "";
                                                                ds = "";
                                                                type = "";
                                                                ttf = "";
                                                                location = "";
                                                            }
                                                        }
                                                    }
                                                }
                                                main_raisingGoal = false;
                                            }
                                            while (false);
                                        }
                                    }
                                }
                            }
                            if(MoiseScanner_HashMap.fs_handling_goal.size()>0){
                                myWriter.write("\n");
                                myWriter.write("    *   #### Handling-goal: \n");
                                myWriter.write("\n");
                                myWriter.write("        | id | min | ds | type | ttf | location | when |\n");
                                myWriter.write("        |---|---|---|---|---|---|---|\n");
                                ArrayList<Integer> handling_goal = new ArrayList<>();
                                handling_goal = SortingData.SortData("handling-goal","by_index",elements.get(w));
                                if(handling_goal.size()>0){
                                    String min;
                                    String ds;
                                    String type;
                                    String ttf;
                                    String location;
                                    String when;
                                    for(int g=0;g<handling_goal.size();g++){

                                        min = MoiseScanner_HashMap.fs_handling_goal.get(handling_goal.get(g)).get(3);
                                        ds = MoiseScanner_HashMap.fs_handling_goal.get(handling_goal.get(g)).get(4);
                                        type = MoiseScanner_HashMap.fs_handling_goal.get(handling_goal.get(g)).get(5);
                                        ttf = MoiseScanner_HashMap.fs_handling_goal.get(handling_goal.get(g)).get(6);
                                        location = MoiseScanner_HashMap.fs_handling_goal.get(handling_goal.get(g)).get(7);
                                        when = MoiseScanner_HashMap.fs_handling_goal.get(handling_goal.get(g)).get(8);

                                        myWriter.write("        | " + MoiseScanner_HashMap.fs_handling_goal.get(handling_goal.get(g)).get(2)
                                                + " | " + min + " | " + ds + " | " + type + " | " + ttf + " | " + location + " | " + when + " | \n");
                                    }
                                    for(int g=0;g<handling_goal.size();g++){
                                        if (MoiseScanner_HashMap.fs_handling_goal.get(handling_goal.get(g)).get(1).equals("yes")){
                                            int index = handling_goal.get(g);
                                            boolean main_raisingGoal = true;
                                            do{
                                                if(!main_raisingGoal){
                                                    index = MoiseScanner_variables.goal_list.get(0);
                                                    MoiseScanner_variables.goal_list.remove(0);
                                                }
                                                ArrayList<Integer> arg_handling = new ArrayList<>();
                                                arg_handling = SortingData.SortData("argument", "handling-goal", index);
                                                if (arg_handling.size()>0){
                                                    myWriter.write("\n");
                                                    myWriter.write("        * #### Argument referred to handling-goal: " + MoiseScanner_HashMap.fs_handling_goal.get(index).get(2) + "\n");
                                                    myWriter.write("\n");
                                                    myWriter.write("            | id | value |\n");
                                                    myWriter.write("            |---|---|\n");
                                                    for (int j = 0; j < arg_handling.size(); j++) {
                                                        myWriter.write("            | " + MoiseScanner_HashMap.fs_argument.get(arg_handling.get(j)).get(2)
                                                                + " | " + MoiseScanner_HashMap.fs_argument.get(arg_handling.get(j)).get(3) + " | \n");
                                                    }
                                                }
                                                ArrayList<Integer> dep_handling = new ArrayList<>();
                                                dep_handling = SortingData.SortData("depends-on", "handling-goal",index);
                                                if(dep_handling.size()>0){
                                                    myWriter.write("\n");
                                                    myWriter.write("        * #### Depends-on referred to handling-goal: " + MoiseScanner_HashMap.fs_handling_goal.get(index).get(2) + "\n");
                                                    myWriter.write("\n");
                                                    myWriter.write("            | goal |\n");
                                                    myWriter.write("            |---|\n");
                                                    for(int j=0;j<dep_handling.size();j++){
                                                        myWriter.write("            | " + MoiseScanner_HashMap.fs_depends_on.get(dep_handling.get(j)).get(2) + " | \n");
                                                    }
                                                }
                                                ArrayList<Integer> handling_plan = new ArrayList<>();
                                                handling_plan = SortingData.SortData("plan", "handling-goal",index);
                                                if(handling_plan.size()>0){
                                                    myWriter.write("\n");
                                                    myWriter.write("        * #### Plan " + handling_plan.get(0) + " referred to handling-goal: " + MoiseScanner_HashMap.fs_handling_goal.get(index).get(2) + "\n");
                                                    myWriter.write("\n");
                                                    myWriter.write("            | operator | success-rate |\n");
                                                    myWriter.write("            |---|---|\n");
                                                    myWriter.write("            | " + MoiseScanner_HashMap.fs_plan.get(handling_plan.get(0)).get(2)
                                                            + " | " + MoiseScanner_HashMap.fs_plan.get(handling_plan.get(0)).get(3) + " | \n");
                                                    if(MoiseScanner_HashMap.fs_plan.get(handling_plan.get(0)).get(1).equals("yes")){
                                                        ArrayList<Integer> goal_rs = new ArrayList<>();
                                                        goal_rs = SortingData.SortData("goal", "plan", handling_plan.get(0));
                                                        if(goal_rs.size()>0){
                                                            myWriter.write("\n");
                                                            myWriter.write("            * #### Goal referred to plan: " + handling_plan.get(0) + "\n");
                                                            myWriter.write("\n");
                                                            myWriter.write("                | id | min | ds | type | ttf | location |\n");
                                                            myWriter.write("                |---|---|---|---|---|---|\n");
                                                        }
                                                        for(int q=0;q<goal_rs.size();q++){
                                                            min = MoiseScanner_HashMap.fs_goal.get(goal_rs.get(q)).get(3);
                                                            ds = MoiseScanner_HashMap.fs_goal.get(goal_rs.get(q)).get(4);
                                                            type = MoiseScanner_HashMap.fs_goal.get(goal_rs.get(q)).get(5);
                                                            ttf = MoiseScanner_HashMap.fs_goal.get(goal_rs.get(q)).get(6);
                                                            location = MoiseScanner_HashMap.fs_goal.get(goal_rs.get(q)).get(7);
                                                            if(MoiseScanner_HashMap.fs_goal.get(goal_rs.get(q)).get(1).equals("yes")) {
                                                                MoiseScanner_variables.goal_list.add(goal_rs.get(q));
                                                            }
                                                            myWriter.write("                | " + MoiseScanner_HashMap.fs_goal.get(goal_rs.get(q)).get(2)
                                                                    + " | " + min + " | " + ds + " | " + type + " | " + ttf + " | " + location + " | \n");
                                                            min = "";
                                                            ds = "";
                                                            type = "";
                                                            ttf = "";
                                                            location = "";
                                                        }
                                                        while(MoiseScanner_variables.goal_list.size()>0){
                                                            int indexing = MoiseScanner_variables.goal_list.get(0);
                                                            MoiseScanner_variables.goal_list.remove(0);
                                                            arg_handling.clear();
                                                            dep_handling.clear();
                                                            handling_plan.clear();
                                                            arg_handling = SortingData.SortData("argument", "goal", indexing);
                                                            if(arg_handling.size()>0){
                                                                myWriter.write("\n");
                                                                myWriter.write("                * ####Argument referred to goal: " + MoiseScanner_HashMap.fs_goal.get(indexing).get(2) + "\n");
                                                                myWriter.write("\n");
                                                                myWriter.write("                    | id | value |\n");
                                                                myWriter.write("                    |---|---|\n");
                                                                for (int j = 0; j < arg_handling.size(); j++) {
                                                                    myWriter.write("                    | " + MoiseScanner_HashMap.fs_argument.get(arg_handling.get(j)).get(2)
                                                                            + " | " + MoiseScanner_HashMap.fs_argument.get(arg_handling.get(j)).get(3) + " | \n");
                                                                }
                                                            }
                                                            dep_handling = SortingData.SortData("depends-on", "goal",indexing);
                                                            if(dep_handling.size()>0){
                                                                myWriter.write("\n");
                                                                myWriter.write("                * ####Depends-on referred to goal: " + MoiseScanner_HashMap.fs_goal.get(indexing).get(2) + "\n");
                                                                myWriter.write("\n");
                                                                myWriter.write("                    | goal |\n");
                                                                myWriter.write("                    |---|\n");
                                                                for(int j=0;j<dep_handling.size();j++){
                                                                    myWriter.write("                    | " + MoiseScanner_HashMap.fs_depends_on.get(dep_handling.get(j)).get(2) + " | \n");
                                                                }
                                                            }
                                                            handling_plan = SortingData.SortData("plan", "goal",indexing);
                                                            if(handling_plan.size()>0){
                                                                myWriter.write("\n");
                                                                myWriter.write("                * ####Plan " + handling_plan.get(0) + " referred to goal: " + MoiseScanner_HashMap.fs_goal.get(indexing).get(2) + "\n");
                                                                myWriter.write("\n");
                                                                myWriter.write("                    | operator | success-rate |\n");
                                                                myWriter.write("                    |---|---|\n");
                                                                myWriter.write("                    | " + MoiseScanner_HashMap.fs_plan.get(handling_plan.get(0)).get(2)
                                                                        + " | " + MoiseScanner_HashMap.fs_plan.get(handling_plan.get(0)).get(3) + " | \n");
                                                            }
                                                            ArrayList<Integer> goal_ch = new ArrayList<>();
                                                            goal_ch = SortingData.SortData("goal", "plan",handling_plan.get(0));
                                                            if(goal_ch.size()>0){
                                                                myWriter.write("\n");
                                                                myWriter.write("                * #### Goal referred to plan: " + handling_plan.get(0) + "\n");
                                                                myWriter.write("\n");
                                                                myWriter.write("                    | id | min | ds | type | ttf | location |\n");
                                                                myWriter.write("                    |---|---|---|---|---|---|\n");
                                                            }
                                                            for(int q=0;q<goal_ch.size();q++){
                                                                min = MoiseScanner_HashMap.fs_goal.get(goal_ch.get(q)).get(3);
                                                                ds = MoiseScanner_HashMap.fs_goal.get(goal_ch.get(q)).get(4);
                                                                type = MoiseScanner_HashMap.fs_goal.get(goal_ch.get(q)).get(5);
                                                                ttf = MoiseScanner_HashMap.fs_goal.get(goal_ch.get(q)).get(6);
                                                                location = MoiseScanner_HashMap.fs_goal.get(goal_ch.get(q)).get(7);
                                                                if(MoiseScanner_HashMap.fs_goal.get(goal_ch.get(q)).get(1).equals("yes")) {
                                                                    MoiseScanner_variables.goal_list.add(goal_ch.get(q));
                                                                }
                                                                myWriter.write("                    | " + MoiseScanner_HashMap.fs_goal.get(goal_ch.get(q)).get(2)
                                                                        + " | " + min + " | " + ds + " | " + type + " | " + ttf + " | " + location + " | \n");
                                                                min = "";
                                                                ds = "";
                                                                type = "";
                                                                ttf = "";
                                                                location = "";
                                                            }
                                                        }
                                                    }
                                                }
                                                main_raisingGoal = false;
                                            }
                                            while (false);
                                        }
                                    }
                                }
                            }
                        }
                        elements = SortingData.SortData("accountability-agreement","by_index",i);
                        for(int w=0;w<elements.size();w++){
                            myWriter.write("\n");
                            myWriter.write("## Accountability-agreement referred to scheme " + i + "\n");
                            myWriter.write("* __Id__: " + MoiseScanner_HashMap.fs_accountability_agreement.get(elements.get(w)).get(2) + "\n");
                            ArrayList<Integer> data = new ArrayList<>();
                            data = SortingData.SortData("target","by_index",elements.get(w));
                            if(data.size()>0){
                                myWriter.write("\n");
                                myWriter.write("*   ### Target id: " + MoiseScanner_HashMap.fs_target.get(data.get(0)).get(2) + "\n");
                                myWriter.write("\n");
                            }
                            if(data.size()>0){
                                data.clear();
                            }
                            data = SortingData.SortData("requesting-condition","by_index",elements.get(w));
                            if(data.size()>0){
                                myWriter.write("\n");
                                myWriter.write("*   ### Requesting-condition value: " + MoiseScanner_HashMap.fs_requesting_condition.get(data.get(0)).get(2) + "\n");
                                myWriter.write("\n");
                            }
                            if(data.size()>0){
                                data.clear();
                            }
                            data = SortingData.SortData("condition-argument","by_index",elements.get(w));
                            if(data.size()>0){
                                myWriter.write("    *   #### Condition-argument: \n");
                                myWriter.write("\n");
                                myWriter.write("        | id | value |\n");
                                myWriter.write("        |---|---|\n");
                                for(int l=0;l<data.size();l++){
                                    myWriter.write("        | " + MoiseScanner_HashMap.fs_condition_argument.get(data.get(l)).get(2)
                                            + " | " + MoiseScanner_HashMap.fs_condition_argument.get((data.get(l))).get(3) + " | \n");
                                }
                            }
                            ArrayList<Integer> property = new ArrayList<>();
                            property = SortingData.SortData("property", "accountability-agreement", elements.get(w));
                            if(property.size()>0){
                                myWriter.write("\n");
                                myWriter.write("*   ### Properties\n");
                                myWriter.write("\n");
                                myWriter.write("    *   #### Property: \n");
                                myWriter.write("\n");
                                myWriter.write("        | id | value |\n");
                                myWriter.write("        |---|---|\n");
                                for (int y=0;y<property.size();y++){
                                    myWriter.write("        | " + MoiseScanner_HashMap.property.get(property.get(y)).get(2)
                                            + " | " + MoiseScanner_HashMap.property.get((property.get(y))).get(3) + " | \n");
                                }
                            }
                            if(property.size()>0){
                                property.clear();
                            }
                            if(data.size()>0){
                                data.clear();
                            }
                            data = SortingData.SortData("account-argument","by_index",elements.get(w));
                            if(data.size()>0){
                                myWriter.write("\n");
                                myWriter.write("*   ### Account-template \n");
                                myWriter.write("    *   #### Account-argument: \n");
                                myWriter.write("\n");
                                myWriter.write("        | id | arity |\n");
                                myWriter.write("        |---|---|\n");
                                for(int l=0;l<data.size();l++){
                                    myWriter.write("        | " + MoiseScanner_HashMap.fs_account_argument.get(data.get(l)).get(2)
                                            + " | " + MoiseScanner_HashMap.fs_account_argument.get((data.get(l))).get(3) + " | \n");
                                }
                            }
                            if(data.size()>0){
                                data.clear();
                            }
                            data = SortingData.SortData("goal","account-template",elements.get(w));
                            if(data.size()>0){
                                myWriter.write("\n");
                                myWriter.write("    *   #### Goal: \n");
                                myWriter.write("\n");
                                myWriter.write("        | id | min | ds | type | ttf | location | atype | when |\n");
                                myWriter.write("        |---|---|---|---|---|---|---|---|\n");
                                String min;
                                String ds;
                                String type;
                                String ttf;
                                String location;
                                String atype;
                                String when;
                                for(int g=0;g<data.size();g++){
                                    min = MoiseScanner_HashMap.fs_goal.get(data.get(g)).get(3);
                                    ds = MoiseScanner_HashMap.fs_goal.get(data.get(g)).get(4);
                                    type = MoiseScanner_HashMap.fs_goal.get(data.get(g)).get(5);
                                    ttf = MoiseScanner_HashMap.fs_goal.get(data.get(g)).get(6);
                                    location = MoiseScanner_HashMap.fs_goal.get(data.get(g)).get(7);
                                    atype = MoiseScanner_HashMap.fs_goal.get(data.get(g)).get(9);
                                    when = MoiseScanner_HashMap.fs_goal.get(data.get(g)).get(10);

                                    myWriter.write("        | " + MoiseScanner_HashMap.fs_goal.get(data.get(g)).get(2)
                                                + " | " + min + " | " + ds + " | " + type + " | " + ttf + " | " + location + " | " + atype + "|" + when + " | \n");
                                    if(MoiseScanner_HashMap.fs_goal.get(data.get(g)).get(1).equals("yes")){
                                        ArrayList<Integer> elem = new ArrayList<>();
                                        int index = data.get(g);
                                        boolean main_goal=true;
                                        do{
                                            if(main_goal==false){
                                                index = MoiseScanner_variables.goal_list.get(0);
                                                MoiseScanner_variables.goal_list.remove(0);
                                            }
                                            elem.clear();
                                            elem = SortingData.SortData("argument", "goal", index);
                                            if (elem.size() > 0) {
                                                myWriter.write("\n");
                                                myWriter.write("        #### Argument referred to goal: " + MoiseScanner_HashMap.fs_goal.get(index).get(2) + "\n");
                                                myWriter.write("\n");
                                                myWriter.write("        | id | value |\n");
                                                myWriter.write("        |---|---|\n");
                                                for (int j = 0; j < elem.size(); j++) {
                                                    myWriter.write("        | " + MoiseScanner_HashMap.fs_argument.get(elem.get(j)).get(2)
                                                            + " | " + MoiseScanner_HashMap.fs_argument.get(elem.get(j)).get(3) + " | \n");
                                                }
                                            }
                                            if (elem.size() > 0) {
                                                elem.clear();
                                            }
                                            elem = SortingData.SortData("depends-on", "goal", index);
                                            if (elem.size() > 0) {
                                                myWriter.write("\n");
                                                myWriter.write("        #### Depends-on referred to goal: " + MoiseScanner_HashMap.fs_goal.get(index).get(2) + "\n");
                                                myWriter.write("\n");
                                                for (int j = 0; j < elem.size(); j++) {
                                                    myWriter.write("        * __Id__: " + MoiseScanner_HashMap.fs_depends_on.get(elem.get(j)).get(2) + "\n");
                                                }
                                            }
                                            if (elem.size() > 0) {
                                                elem.clear();
                                            }
                                            elem = SortingData.SortData("plan", "goal", index);
                                            if (elem.size() > 0) {
                                                myWriter.write("\n");
                                                myWriter.write("        #### Plan " + index + " referred to goal: " + MoiseScanner_HashMap.fs_goal.get(index).get(2) + "\n");
                                                myWriter.write("\n");
                                                myWriter.write("        | operator | success-rate |\n");
                                                myWriter.write("        |---|---|\n");
                                                for(int j = 0; j < elem.size(); j++){
                                                    myWriter.write("    | " + MoiseScanner_HashMap.fs_plan.get(elem.get(j)).get(2)
                                                            + " | " + MoiseScanner_HashMap.fs_plan.get(elem.get(j)).get(3) + " | \n");
                                                    if (MoiseScanner_HashMap.fs_plan.get(elem.get(j)).get(1).equals("yes")) {
                                                        ArrayList<Integer> property_g = new ArrayList<>();
                                                        property = SortingData.SortData("property", "plan", elem.get(0));//qui non credo sia i
                                                        if (property_g.size() > 1) {
                                                            myWriter.write("\n");
                                                            myWriter.write("        *   ### Properties\n");
                                                            myWriter.write("            *   #### Property: \n");
                                                            myWriter.write("\n");
                                                            myWriter.write("                | id | value |\n");
                                                            myWriter.write("                |---|---|\n");
                                                            for (int k = 0; k < property_g.size(); k++) {
                                                                myWriter.write("            | " + MoiseScanner_HashMap.property.get(property_g.get(k)).get(2)
                                                                        + " | " + MoiseScanner_HashMap.property.get(property_g.get(k)).get(3) + " | \n");
                                                            }
                                                        }
                                                        property.clear();
                                                        ArrayList<Integer> goal = new ArrayList<>();
                                                        goal = SortingData.SortData("goal", "plan", elem.get(j));
                                                        if(goal.size()>0){
                                                            myWriter.write("\n");
                                                            myWriter.write("        #### Goal referred to plan: " + index + "\n");
                                                            myWriter.write("\n");
                                                            myWriter.write("        | id | min | ds | type | ttf | location |\n");
                                                            myWriter.write("        |---|---|---|---|---|---|\n");
                                                        }
                                                        for (int p = 0; p < goal.size(); p++) {
                                                            if (!MoiseScanner_HashMap.fs_goal.get(goal.get(p)).get(3).equals("")) {
                                                                min = MoiseScanner_HashMap.fs_goal.get(goal.get(p)).get(3);
                                                            }
                                                            if (!MoiseScanner_HashMap.fs_goal.get(goal.get(p)).get(4).equals("")) {
                                                                ds = MoiseScanner_HashMap.fs_goal.get(goal.get(p)).get(4);
                                                            }
                                                            if (!MoiseScanner_HashMap.fs_goal.get(goal.get(p)).get(5).equals("")) {
                                                                type = MoiseScanner_HashMap.fs_goal.get(goal.get(p)).get(5);
                                                            }
                                                            if (!MoiseScanner_HashMap.fs_goal.get(goal.get(p)).get(6).equals("")) {
                                                                ttf = MoiseScanner_HashMap.fs_goal.get(goal.get(p)).get(6);
                                                            }
                                                            if (!MoiseScanner_HashMap.fs_goal.get(goal.get(p)).get(7).equals("")) {
                                                                location = MoiseScanner_HashMap.fs_goal.get(goal.get(p)).get(7);
                                                            }
                                                            if (MoiseScanner_HashMap.fs_goal.get(goal.get(p)).get(1).equals("yes")) {
                                                                MoiseScanner_variables.goal_list.add(goal.get(p));
                                                            }
                                                            myWriter.write("        | " + MoiseScanner_HashMap.fs_goal.get(goal.get(p)).get(2)
                                                                    + " | " + min + " | " + ds + " | " + type + " | " + ttf + " | " + location + " | \n");
                                                            min = "";
                                                            ds = "";
                                                            type = "";
                                                            ttf = "";
                                                            location = "";
                                                        }
                                                    }
                                                }
                                            }
                                            main_goal = false;
                                        }
                                        while(MoiseScanner_variables.goal_list.size()>0);
                                    }
                                }
                            }
                        }
                        if(elements.size()>0){
                            elements.clear();
                        }
                        elements = SortingData.SortData("mission","by_index",i);
                        for(int w=0;w<elements.size();w++){
                            myWriter.write("\n");
                            myWriter.write("## Mission referred to scheme " + i + "\n");
                            myWriter.write("* __Id__: " + MoiseScanner_HashMap.fs_mission.get(elements.get(w)).get(2) + "\n");
                            myWriter.write("* __Min__: " + MoiseScanner_HashMap.fs_mission.get(elements.get(w)).get(3) + "\n");
                            myWriter.write("* __max__: " + MoiseScanner_HashMap.fs_mission.get(elements.get(w)).get(4) + "\n");
                            ArrayList<Integer> property = new ArrayList<>();
                            property = SortingData.SortData("property", "mission", elements.get(w));
                            if(property.size()>0){
                                myWriter.write("\n");
                                myWriter.write("*   ### Properties\n");
                                myWriter.write("\n");
                                myWriter.write("    *   #### Property: \n");
                                myWriter.write("\n");
                                myWriter.write("        | id | value |\n");
                                myWriter.write("        |---|---|\n");
                                for (int y=0;y<property.size();y++){
                                    myWriter.write("        | " + MoiseScanner_HashMap.property.get(property.get(y)).get(2)
                                            + " | " + MoiseScanner_HashMap.property.get((property.get(y))).get(3) + " | \n");
                                }
                            }
                            if(property.size() > 0){
                                property.clear();
                            }
                            ArrayList<Integer> goal = new ArrayList<>();
                            goal = SortingData.SortData("goal", "mission", elements.get(w));
                            if(goal.size()>0){
                                myWriter.write("\n");
                                myWriter.write("\n");
                                myWriter.write("* ### Goal\n");
                                for(int n=0;n<goal.size();n++){
                                    myWriter.write("    * __id:__ " + MoiseScanner_HashMap.fs_mission_goal.get(goal.get(n)).get(2) + "\n");
                                }
                            }
                            ArrayList<Integer> preferred = new ArrayList<>();
                            preferred = SortingData.SortData("preferred", "mission", elements.get(w));
                            if(preferred.size()>0){
                                myWriter.write("\n");
                                myWriter.write("\n");
                                myWriter.write("* ### Preferred\n");
                                for(int n=0;n<preferred.size();n++){
                                    myWriter.write("    * __mission:__ " + MoiseScanner_HashMap.fs_preferred.get(preferred.get(n)).get(2) + "\n");
                                }
                            }
                        }
                    }
                }
            }
            myWriter.write("\n");
            if(Operations.getOutputFormat()==Format.PDF||Operations.getOutputFormat()==Format.HTML||Operations.getOutputFormat()==Format.TEX){
                myWriter.write("\n");
            }else{
                myWriter.write("---\n");
            }
            if(MoiseScanner_variables.NSType){
                if(Operations.getOutputFormat()==Format.PDF||Operations.getOutputFormat()==Format.HTML||Operations.getOutputFormat()==Format.TEX){
                    myWriter.write("## Normative-specification\n");
                }else{
                    myWriter.write(">## Normative-specification\n");
                }
                if(elements.size()>0){
                    elements.clear();
                }
                elements = SortingData.SortData("property", "normative-specification", null);
                if(elements.size()>1){
                    myWriter.write("### Properties\n");
                    myWriter.write("#### Property: \n");
                    myWriter.write("\n");
                    myWriter.write("| id | value |\n");
                    myWriter.write("|---|---|\n");
                    for (int j=0; j<elements.size();j++) {
                        myWriter.write("| " + MoiseScanner_HashMap.property.get(elements.get(j)).get(2)
                                + " | " + MoiseScanner_HashMap.property.get(elements.get(j)).get(3) + " | \n");
                    }
                }
                if(elements.size() > 0) {
                    elements.clear();
                }
                elements = SortingData.SortData("norm", "all", null);
                if(Operations.getOutputFormat()==Format.MARKDOWN||Operations.getOutputFormat()==Format.HTML){
                    if (elements.size() > 1) {
                        myWriter.write("### Norm\n");
                        myWriter.write("\n");
                        myWriter.write("| id | condition | role | type | mission | time-constraint |\n");
                        myWriter.write("|---|---|---|---|---|---|\n");
                        for (int j = 0; j < elements.size(); j++) {
                            myWriter.write("| " + MoiseScanner_HashMap.ns_norm.get(elements.get(j)).get(2) +
                                    " | " + MoiseScanner_HashMap.ns_norm.get(elements.get(j)).get(3) +
                                    " | " + MoiseScanner_HashMap.ns_norm.get(elements.get(j)).get(4) +
                                    " | " + MoiseScanner_HashMap.ns_norm.get(elements.get(j)).get(5) +
                                    " | " + MoiseScanner_HashMap.ns_norm.get(elements.get(j)).get(6) +
                                    " | " + MoiseScanner_HashMap.ns_norm.get(elements.get(j)).get(7) + " | \n");
                        }
                    }
                }else if(Operations.getOutputFormat()==Format.PDF||Operations.getOutputFormat()==Format.TEX){
                    if(elements.size() > 1){
                        myWriter.write("### Norm\n");
                        myWriter.write("\n");
                        myWriter.write("| id | condition | role |\n");
                        myWriter.write("|---|---|---|\n");
                        for (int j = 0; j < elements.size(); j++) {
                            myWriter.write("| " + MoiseScanner_HashMap.ns_norm.get(elements.get(j)).get(2) +
                                    " | " + MoiseScanner_HashMap.ns_norm.get(elements.get(j)).get(3) +
                                    " | " + MoiseScanner_HashMap.ns_norm.get(elements.get(j)).get(4) + " | \n");
                        }
                    }
                    if(elements.size() > 1) {
                        myWriter.write("\n");
                        myWriter.write("| id | type | mission | time-constraint |\n");
                        myWriter.write("|---|---|---|---|\n");
                        for (int j = 0; j < elements.size(); j++) {
                            myWriter.write("| " + MoiseScanner_HashMap.ns_norm.get(elements.get(j)).get(2) +
                                    " | " + MoiseScanner_HashMap.ns_norm.get(elements.get(j)).get(5) +
                                    " | " + MoiseScanner_HashMap.ns_norm.get(elements.get(j)).get(6) +
                                    " | " + MoiseScanner_HashMap.ns_norm.get(elements.get(j)).get(7) + " | \n");
                        }
                    }
                }
                if(elements.size()>0){
                    elements.clear();
                }
            }

            myWriter.close();

            if(myObj.createNewFile()){
                System.out.println("File created: " + myObj.getName());
            }else{
                System.out.println("File already exists.");
            }

        }catch(IOException e){
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }
}