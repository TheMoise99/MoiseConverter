package ScannerTools;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Scanner;

import Cores.FunctionalSpecificationCore;
import Cores.NormativeSpecificationCore;
import Cores.PropertiesCore;
import Markdown_manager.CreateMarkdown;
import Cores.StructuralSpecificationCore;

public class MoiseScanner{

    public Token lexical_scan(BufferedReader br){
        MoiseScanner_methods.goto_new_line(br);
        boolean hasProperties = MoiseScanner_tag.Tag_peek(br,"properties");
        boolean hasStructuralSpecification;
        boolean hasFunctionalSpecification;
        boolean hasNormativeSpecification;

        if(hasProperties){
            PropertiesCore.Properties(br,"start");
            hasStructuralSpecification = MoiseScanner_tag.ComposeTag_peek(br,"structural","specification");
        }else{
            hasStructuralSpecification = MoiseScanner_tag.ComposedTag_dash_peek(br, MoiseScanner_variables.temp_peek,"structural","specification");
        }
        if(hasStructuralSpecification){
            MoiseScanner_variables.SSType = true;
            StructuralSpecificationCore.StructuralSpecification(br);
            hasFunctionalSpecification = MoiseScanner_tag.ComposeTag_peek(br,"functional","specification");
        }else{
            hasFunctionalSpecification = MoiseScanner_tag.ComposedTag_dash_peek(br, MoiseScanner_variables.temp_peek,"functional","specification");
        }
        if(hasFunctionalSpecification){
            MoiseScanner_variables.FSType = true;
            FunctionalSpecificationCore.FunctionalSpecification(br);
            hasNormativeSpecification = MoiseScanner_tag.ComposeTag_peek(br,"normative","specification");
        }else{
            hasNormativeSpecification = MoiseScanner_tag.ComposedTag_dash_peek(br, MoiseScanner_variables.temp_peek,"normative","specification");
        }
        if(hasNormativeSpecification){
            MoiseScanner_variables.NSType = true;
            NormativeSpecificationCore.NormativeSpecification(br);
        }
        //MoiseScanner_methods.test();
        MoiseScanner_methods.test2();
        return new Token(Tag.EOF);
    }

    public static void removeComments(String input){
        String data;
        String output = "";
        String comment = "";
        String OS_Type = "";
        boolean type = false;
        boolean first_line = true;
        boolean comment_open = false;
        int index_open;
        int index_close;
        int first_case=4;

        try{
            File myObj = new File(input);
            Scanner myReader = new Scanner(myObj);
            while(myReader.hasNextLine()){
                index_open = 0;
                data = myReader.nextLine();
                if(!type){
                    if(data.contains("<structural-specification>")){
                        type = true;
                        first_case = 0;
                    }else if(data.contains("<properties>")){
                        type = true;
                        first_case = 1;
                    }else if(data.contains("<functional-specification>")){
                        type = true;
                        first_case = 2;
                    }else if(data.contains("<normative-specification>")){
                        type = true;
                        first_case = 3;
                    }
                    if(type){
                        if(first_case==0){
                            data = data.replaceAll("<structural-specification>", "");
                        }else if(first_case==1){
                            data = data.replaceAll("<properties>", "");
                        }else if(first_case==2){
                            data = data.replaceAll("<functional-specification>", "");
                        }else if(first_case==3){
                            data = data.replaceAll("<normative-specification>", "");
                        }
                    }
                    OS_Type = OS_Type + "\n" + data;
                    if(first_case==0){
                        data = "<structural-specification>" + data ;
                    }else if(first_case==1){
                        data = "<properties>" + data ;
                    }else if(first_case==2){
                        data = "<functional-specification>" + data ;
                    }else if(first_case==3){
                        data = "<normative-specification>" + data;
                    }
                }
                if(type){
                    if(data.contains("<!--")&&!comment_open){
                        comment_open = true;
                        index_open = data.indexOf("<!--");
                        if (data.contains("-->")) {
                            comment_open = false;
                            index_close = data.indexOf("-->");
                            comment = data.substring(index_open, index_close + 3);
                        }
                    }
                    if(comment_open){
                        if(data.contains("-->")){
                            comment_open = false;
                            index_close = data.indexOf("-->");
                            comment = data.substring(index_open, index_close + 3);
                        }else{
                            int index = data.length();
                            comment = data.substring(index_open,index);
                        }
                    }
                    data = data.replaceAll(comment, "");
                    if(!first_line){
                        output = output + "\n" + data;
                    }else{
                        output = output + data;
                    }
                    first_line = false;
                }
            }
            myReader.close();
        }catch(FileNotFoundException e){
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        try{
            FileWriter myWriter = new FileWriter("C:\\Markdown\\parser_input.xml");
            output = output.replaceAll("</organisational-specification>", "");
            myWriter.write(output);
            myWriter.close();
        }catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        System.out.println(OS_Type);
    }

    public static void MS(String input_ui){
        MoiseScanner ms = new MoiseScanner();
        String input = input_ui; //testing
        removeComments(input);
        String path = "C:\\Markdown\\parser_input.xml";
        try{
            BufferedReader br = new BufferedReader(new FileReader(path));
            Token tok;
            do{
                tok = ms.lexical_scan(br);
                System.out.println("Scan: " + tok);
            }while (tok.tag != Tag.EOF);
            br.close();
        }catch (IOException e){
            e.printStackTrace();
        }
        CreateMarkdown.creator();
    }

}