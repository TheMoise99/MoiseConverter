package ScannerTools;

import java.util.ArrayList;
import java.util.HashMap;

public class MoiseScanner_HashMap {
    public static HashMap<Integer,ArrayList<String>> property = new HashMap<>();
    public static HashMap<Integer,ArrayList<String>> role = new HashMap<>();
    public static HashMap<Integer,ArrayList<String>> role_extends = new HashMap<>();
    public static HashMap<Integer,ArrayList<String>> link_type = new HashMap<>();
    public static HashMap<Integer,ArrayList<String>> group_specification = new HashMap<>();
    public static HashMap<Integer,ArrayList<String>> roles_role = new HashMap<>();
    public static HashMap<Integer,ArrayList<String>> link = new HashMap<>();
    public static HashMap<Integer,ArrayList<String>> include_group_specification = new HashMap<>();
    public static HashMap<Integer,ArrayList<String>> cardinality = new HashMap<>();
    public static HashMap<Integer,ArrayList<String>> compatibility = new HashMap<>();
    public static HashMap<Integer,ArrayList<String>> fs_scheme = new HashMap<>();
    public static HashMap<Integer,ArrayList<String>> fs_goal = new HashMap<>();
    public static HashMap<Integer,ArrayList<String>> fs_argument = new HashMap<>();
    public static HashMap<Integer,ArrayList<String>> fs_depends_on = new HashMap<>();
    public static HashMap<Integer,ArrayList<String>> fs_plan = new HashMap<>();
    public static HashMap<Integer,ArrayList<String>> fs_accountability_agreement = new HashMap<>();
    public static HashMap<Integer,ArrayList<String>> fs_account_argument = new HashMap<>();
    public static HashMap<Integer,ArrayList<String>> fs_condition_argument = new HashMap<>();
    public static HashMap<Integer,ArrayList<String>> fs_notification_policy = new HashMap<>();
    public static HashMap<Integer,ArrayList<String>> fs_exception_specification = new HashMap<>();
    public static HashMap<Integer,ArrayList<String>> fs_target = new HashMap<>();
    public static HashMap<Integer,ArrayList<String>> fs_requesting_condition = new HashMap<>();
    public static HashMap<Integer,ArrayList<String>> fs_exception_argument = new HashMap<>();
    public static HashMap<Integer,ArrayList<String>> fs_raising_goal = new HashMap<>();
    public static HashMap<Integer,ArrayList<String>> fs_handling_goal = new HashMap<>();
    public static HashMap<Integer,ArrayList<String>> fs_mission = new HashMap<>();
    public static HashMap<Integer,ArrayList<String>> fs_mission_goal = new HashMap<>();
    public static HashMap<Integer,ArrayList<String>> fs_preferred = new HashMap<>();
    public static HashMap<Integer,ArrayList<String>> ns_norm = new HashMap<>();

}