package ScannerTools;

public class MoiseScanner_filler {

    public static void single_value(String identifier,String from){
        if(identifier.equals("id") && from.equals("properties_property")){
            MoiseScanner_variables.property_id = MoiseScanner_variables.property_id + (MoiseScanner_variables.peek);
        }else if(identifier.equals("value") && from.equals("properties_property")){
            MoiseScanner_variables.property_value = MoiseScanner_variables.property_value + (MoiseScanner_variables.peek);
        }else if(identifier.equals("id") && from.equals("role-definitions")){
            MoiseScanner_variables.role_definitions_role_id = MoiseScanner_variables.role_definitions_role_id + (MoiseScanner_variables.peek);
        }else if(identifier.equals("role") && from.equals("role-definitions_extends")){
            MoiseScanner_variables.role_definitions_extends_role = MoiseScanner_variables.role_definitions_extends_role + (MoiseScanner_variables.peek);
        }else if(identifier.equals("id") && from.equals("link-type")){
            MoiseScanner_variables.link_type_id = MoiseScanner_variables.link_type_id + (MoiseScanner_variables.peek);
        }else if(identifier.equals("id") && from.equals("group-specification")){
            MoiseScanner_variables.group_specification_id = MoiseScanner_variables.group_specification_id + (MoiseScanner_variables.peek);
        }else if(identifier.equals("min") && from.equals("group-specification")){
            MoiseScanner_variables.group_specification_min = MoiseScanner_variables.group_specification_min + (MoiseScanner_variables.peek);
        }else if(identifier.equals("max") && from.equals("group-specification")){
            MoiseScanner_variables.group_specification_max = MoiseScanner_variables.group_specification_max + (MoiseScanner_variables.peek);
        }else if(identifier.equals("id") && from.equals("group-specification_role")){
            MoiseScanner_variables.group_specification_role_id = MoiseScanner_variables.group_specification_role_id + (MoiseScanner_variables.peek);
        }else if(identifier.equals("min") && from.equals("group-specification_role")){
            MoiseScanner_variables.group_specification_role_min = MoiseScanner_variables.group_specification_role_min + (MoiseScanner_variables.peek);
        }else if(identifier.equals("max") && from.equals("group-specification_role")){
            MoiseScanner_variables.group_specification_role_max = MoiseScanner_variables.group_specification_role_max + (MoiseScanner_variables.peek);
        }else if(identifier.equals("from") && from.equals("link")){
            MoiseScanner_variables.links_link_from = MoiseScanner_variables.links_link_from + (MoiseScanner_variables.peek);
        }else if(identifier.equals("to") && from.equals("link")){
            MoiseScanner_variables.links_link_to = MoiseScanner_variables.links_link_to + (MoiseScanner_variables.peek);
        }else if(identifier.equals("type") && from.equals("link")){
            MoiseScanner_variables.links_link_type = MoiseScanner_variables.links_link_type + (MoiseScanner_variables.peek);
        }else if(identifier.equals("scope") && from.equals("link")){
            MoiseScanner_variables.links_link_scope = MoiseScanner_variables.links_link_scope + (MoiseScanner_variables.peek);
        }else if(identifier.equals("extends") && from.equals("link")){
            MoiseScanner_variables.links_link_extendsSubgroups = MoiseScanner_variables.links_link_extendsSubgroups + (MoiseScanner_variables.peek);
        }else if(identifier.equals("bi") && from.equals("link")){
            MoiseScanner_variables.links_link_biDir = MoiseScanner_variables.links_link_biDir + (MoiseScanner_variables.peek);
        }else if(identifier.equals("uri") && from.equals("include-group-specification")){
            MoiseScanner_variables.include_group_specification_uri = MoiseScanner_variables.include_group_specification_uri + (MoiseScanner_variables.peek);
        }else if(identifier.equals("min") && from.equals("cardinality")){
            MoiseScanner_variables.cardinality_min = MoiseScanner_variables.cardinality_min + (MoiseScanner_variables.peek);
        }else if(identifier.equals("max") && from.equals("cardinality")){
            MoiseScanner_variables.cardinality_max = MoiseScanner_variables.cardinality_max + (MoiseScanner_variables.peek);
        }else if(identifier.equals("object") && from.equals("cardinality")){
            MoiseScanner_variables.cardinality_object = MoiseScanner_variables.cardinality_object + (MoiseScanner_variables.peek);
        }else if(identifier.equals("id") && from.equals("cardinality")){
            MoiseScanner_variables.cardinality_id = MoiseScanner_variables.cardinality_id + (MoiseScanner_variables.peek);
        }else if(identifier.equals("from") && from.equals("compatibility")){
            MoiseScanner_variables.compatibility_from = MoiseScanner_variables.compatibility_from + (MoiseScanner_variables.peek);
        }else if(identifier.equals("to") && from.equals("compatibility")){
            MoiseScanner_variables.compatibility_to = MoiseScanner_variables.compatibility_to + (MoiseScanner_variables.peek);
        }else if(identifier.equals("scope") && from.equals("compatibility")){
            MoiseScanner_variables.compatibility_scope = MoiseScanner_variables.compatibility_scope + (MoiseScanner_variables.peek);
        }else if(identifier.equals("extends") && from.equals("compatibility")){
            MoiseScanner_variables.compatibility_extends_subgroups = MoiseScanner_variables.compatibility_extends_subgroups + (MoiseScanner_variables.peek);
        }else if(identifier.equals("bi") && from.equals("compatibility")){
            MoiseScanner_variables.compatibility_bi_dir = MoiseScanner_variables.compatibility_bi_dir + (MoiseScanner_variables.peek);
        }else if(identifier.equals("type") && from.equals("compatibility")){
            MoiseScanner_variables.compatibility_type = MoiseScanner_variables.compatibility_type + (MoiseScanner_variables.peek);
        }else if(identifier.equals("id") && from.equals("scheme")){
            MoiseScanner_variables.scheme_id = MoiseScanner_variables.scheme_id + (MoiseScanner_variables.peek);
        }else if(identifier.equals("id") && from.equals("goal")){
            MoiseScanner_variables.goal_id = MoiseScanner_variables.goal_id + (MoiseScanner_variables.peek);
        }else if(identifier.equals("min") && from.equals("goal")){
            MoiseScanner_variables.goal_min = MoiseScanner_variables.goal_min + (MoiseScanner_variables.peek);
        }else if(identifier.equals("ds") && from.equals("goal")){
            MoiseScanner_variables.goal_ds = MoiseScanner_variables.goal_ds + (MoiseScanner_variables.peek);
        }else if(identifier.equals("type") && from.equals("goal")){
            MoiseScanner_variables.goal_type = MoiseScanner_variables.goal_type + (MoiseScanner_variables.peek);
        }else if(identifier.equals("ttf") && from.equals("goal")){
            MoiseScanner_variables.goal_ttf = MoiseScanner_variables.goal_ttf + (MoiseScanner_variables.peek);
        }else if(identifier.equals("location") && from.equals("goal")){
            MoiseScanner_variables.goal_location = MoiseScanner_variables.goal_location + (MoiseScanner_variables.peek);
        }else if(identifier.equals("aType") && from.equals("goal")){
            MoiseScanner_variables.aType = MoiseScanner_variables.aType + (MoiseScanner_variables.peek);
        }else if(identifier.equals("id") && from.equals("argument")){
            MoiseScanner_variables.argument_id = MoiseScanner_variables.argument_id + (MoiseScanner_variables.peek);
        }else if(identifier.equals("value") && from.equals("argument")){
            MoiseScanner_variables.argument_value = MoiseScanner_variables.argument_value + (MoiseScanner_variables.peek);
        }else if(identifier.equals("goal") && from.equals("depends-on")){
            MoiseScanner_variables.depends_on_goal = MoiseScanner_variables.depends_on_goal + (MoiseScanner_variables.peek);
        }else if(identifier.equals("operator") && from.equals("plan")){
            MoiseScanner_variables.plan_operator = MoiseScanner_variables.plan_operator + (MoiseScanner_variables.peek);
        }else if(identifier.equals("success") && from.equals("plan")) {
            MoiseScanner_variables.plan_success_rate = MoiseScanner_variables.plan_success_rate + (MoiseScanner_variables.peek);
        }else if(identifier.equals("id") && from.equals("accountability-agreement")){
            MoiseScanner_variables.accountability_agreement_id = MoiseScanner_variables.accountability_agreement_id + (MoiseScanner_variables.peek);
        }else if(identifier.equals("id") && from.equals("target")){
            MoiseScanner_variables.target_id = MoiseScanner_variables.target_id + (MoiseScanner_variables.peek);
        }else if(identifier.equals("value") && from.equals("requesting-condition")){
            MoiseScanner_variables.requesting_condition_value = MoiseScanner_variables.requesting_condition_value + (MoiseScanner_variables.peek);
        }else if(identifier.equals("id") && from.equals("condition-argument")){
            MoiseScanner_variables.condition_argument_id = MoiseScanner_variables.condition_argument_id + (MoiseScanner_variables.peek);
        }else if(identifier.equals("value") && from.equals("condition-argument")){
            MoiseScanner_variables.condition_argument_value = MoiseScanner_variables.condition_argument_value + (MoiseScanner_variables.peek);
        }else if(identifier.equals("id") && from.equals("account-argument")){
            MoiseScanner_variables.account_argument_id = MoiseScanner_variables.account_argument_id + (MoiseScanner_variables.peek);
        }else if(identifier.equals("arity") && from.equals("account-argument")){
            MoiseScanner_variables.account_argument_arity = MoiseScanner_variables.account_argument_arity + (MoiseScanner_variables.peek);
        }else if(identifier.equals("atype") && from.equals("goal")){
            MoiseScanner_variables.aType = MoiseScanner_variables.aType + (MoiseScanner_variables.peek);
        }else if(identifier.equals("when") && from.equals("goal")){
            MoiseScanner_variables.goal_when = MoiseScanner_variables.goal_when + (MoiseScanner_variables.peek);
        }else if(identifier.equals("id") && from.equals("notification-policy")){
            MoiseScanner_variables.notification_policy_id = MoiseScanner_variables.notification_policy_id + (MoiseScanner_variables.peek);
        }else if(identifier.equals("target") && from.equals("notification-policy")){
            MoiseScanner_variables.notification_policy_target = MoiseScanner_variables.notification_policy_target + (MoiseScanner_variables.peek);
        }else if(identifier.equals("condition") && from.equals("notification-policy")){
            MoiseScanner_variables.notification_policy_condition = MoiseScanner_variables.notification_policy_condition + (MoiseScanner_variables.peek);
        }else if(identifier.equals("id") && from.equals("exception-specification")){
            MoiseScanner_variables.exception_spec_id = MoiseScanner_variables.exception_spec_id + (MoiseScanner_variables.peek);
        }else if(identifier.equals("id") && from.equals("exception-argument")){
            MoiseScanner_variables.exception_argument_id = MoiseScanner_variables.exception_argument_id + (MoiseScanner_variables.peek);
        }else if(identifier.equals("arity") && from.equals("exception-argument")){
            MoiseScanner_variables.exception_argument_arity = MoiseScanner_variables.exception_argument_arity + (MoiseScanner_variables.peek);
        }else if(identifier.equals("id") && from.equals("raising-goal")){
            MoiseScanner_variables.raising_goal_id = MoiseScanner_variables.raising_goal_id + (MoiseScanner_variables.peek);
        }else if(identifier.equals("min") && from.equals("raising-goal")){
            MoiseScanner_variables.raising_goal_min = MoiseScanner_variables.raising_goal_min + (MoiseScanner_variables.peek);
        }else if(identifier.equals("ds") && from.equals("raising-goal")){
            MoiseScanner_variables.raising_goal_ds = MoiseScanner_variables.raising_goal_ds + (MoiseScanner_variables.peek);
        }else if(identifier.equals("type") && from.equals("raising-goal")){
            MoiseScanner_variables.raising_goal_type = MoiseScanner_variables.raising_goal_type + (MoiseScanner_variables.peek);
        }else if(identifier.equals("ttf") && from.equals("raising-goal")){
            MoiseScanner_variables.raising_goal_ttf = MoiseScanner_variables.raising_goal_ttf + (MoiseScanner_variables.peek);
        }else if(identifier.equals("location") && from.equals("raising-goal")){
            MoiseScanner_variables.raising_goal_location = MoiseScanner_variables.raising_goal_location + (MoiseScanner_variables.peek);
        }else if(identifier.equals("when") && from.equals("raising-goal")){
            MoiseScanner_variables.raising_goal_when = MoiseScanner_variables.raising_goal_when + (MoiseScanner_variables.peek);
        }else if(identifier.equals("id") && from.equals("handling-goal")){
            MoiseScanner_variables.handling_goal_id = MoiseScanner_variables.handling_goal_id + (MoiseScanner_variables.peek);
        }else if(identifier.equals("min") && from.equals("handling-goal")){
            MoiseScanner_variables.handling_goal_min = MoiseScanner_variables.handling_goal_min + (MoiseScanner_variables.peek);
        }else if(identifier.equals("ds") && from.equals("handling-goal")){
            MoiseScanner_variables.handling_goal_ds = MoiseScanner_variables.handling_goal_ds + (MoiseScanner_variables.peek);
        }else if(identifier.equals("type") && from.equals("handling-goal")){
            MoiseScanner_variables.handling_goal_type = MoiseScanner_variables.handling_goal_type + (MoiseScanner_variables.peek);
        }else if(identifier.equals("ttf") && from.equals("handling-goal")){
            MoiseScanner_variables.handling_goal_ttf = MoiseScanner_variables.handling_goal_ttf + (MoiseScanner_variables.peek);
        }else if(identifier.equals("location") && from.equals("handling-goal")){
            MoiseScanner_variables.handling_goal_location = MoiseScanner_variables.handling_goal_location + (MoiseScanner_variables.peek);
        }else if(identifier.equals("when") && from.equals("handling-goal")){
            MoiseScanner_variables.handling_goal_when = MoiseScanner_variables.handling_goal_when + (MoiseScanner_variables.peek);
        }else if(identifier.equals("id") && from.equals("mission")){
            MoiseScanner_variables.mission_id = MoiseScanner_variables.mission_id + (MoiseScanner_variables.peek);
        }else if(identifier.equals("min") && from.equals("mission")){
            MoiseScanner_variables.mission_min = MoiseScanner_variables.mission_min + (MoiseScanner_variables.peek);
        }else if(identifier.equals("max") && from.equals("mission")){
            MoiseScanner_variables.mission_max = MoiseScanner_variables.mission_max + (MoiseScanner_variables.peek);
        }else if(identifier.equals("id") && from.equals("mission-goal")){
            MoiseScanner_variables.mission_goal_id = MoiseScanner_variables.mission_goal_id + (MoiseScanner_variables.peek);
        }else if(identifier.equals("mission") && from.equals("preferred_mission")){
            MoiseScanner_variables.preferred_mission = MoiseScanner_variables.preferred_mission + (MoiseScanner_variables.peek);
        }else if(identifier.equals("id") && from.equals("norm")){
            MoiseScanner_variables.norm_id = MoiseScanner_variables.norm_id + (MoiseScanner_variables.peek);
        }else if(identifier.equals("condition") && from.equals("norm")){
            MoiseScanner_variables.norm_condition = MoiseScanner_variables.norm_condition + (MoiseScanner_variables.peek);
        }else if(identifier.equals("role") && from.equals("norm")){
            MoiseScanner_variables.norm_role = MoiseScanner_variables.norm_role + (MoiseScanner_variables.peek);
        }else if(identifier.equals("type") && from.equals("norm")){
            MoiseScanner_variables.norm_type = MoiseScanner_variables.norm_type + (MoiseScanner_variables.peek);
        }else if(identifier.equals("mission") && from.equals("norm")){
            MoiseScanner_variables.norm_mission = MoiseScanner_variables.norm_mission + (MoiseScanner_variables.peek);
        }else if(identifier.equals("time") && from.equals("norm")){
            MoiseScanner_variables.norm_time_constraint = MoiseScanner_variables.norm_time_constraint + (MoiseScanner_variables.peek);
        }else{
            System.out.println("unknown identifier " + identifier);
        }
    }

    public static String return_value_filler(String identifier,String from){
        if(identifier.equals("id")&&from.equals("properties_property")){
            MoiseScanner_variables.property_id = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.property_id);
            return MoiseScanner_variables.property_id;
        }else if(identifier.equals("value")&&from.equals("properties_property")){
            MoiseScanner_variables.property_value = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.property_value);
            return MoiseScanner_variables.property_value;
        }else if(identifier.equals("id") && from.equals("role-definitions")){
            MoiseScanner_variables.role_definitions_role_id = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.role_definitions_role_id);
            return MoiseScanner_variables.role_definitions_role_id;
        }else if(identifier.equals("role") && from.equals("role-definitions_extends")){
            MoiseScanner_variables.role_definitions_extends_role = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.role_definitions_extends_role);
            return MoiseScanner_variables.role_definitions_extends_role;
        }else if(identifier.equals("id") && from.equals("link-type")){
            MoiseScanner_variables.link_type_id = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.link_type_id);
            return MoiseScanner_variables.link_type_id;
        }else if(identifier.equals("id") && from.equals("group-specification")){
            MoiseScanner_variables.group_specification_id = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.group_specification_id);
            return MoiseScanner_variables.group_specification_id;
        }else if(identifier.equals("min") && from.equals("group-specification")){
            MoiseScanner_variables.group_specification_min = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.group_specification_min);
            if(MoiseScanner_methods.isNumber(MoiseScanner_variables.group_specification_min)){
                return MoiseScanner_variables.group_specification_min;
            }else{
                MoiseScanner_methods.MoiseScanner_error("NOT A POSITIVE INTEGER",1);
            }
        }else if(identifier.equals("max") && from.equals("group-specification")){
            MoiseScanner_variables.group_specification_max = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.group_specification_max);
            if(MoiseScanner_methods.isNumber(MoiseScanner_variables.group_specification_max)){
                return MoiseScanner_variables.group_specification_max;
            }else{
                MoiseScanner_methods.MoiseScanner_error("NOT A POSITIVE INTEGER",1);
            }
        }else if(identifier.equals("id") && from.equals("group-specification_role")){
            MoiseScanner_variables.group_specification_role_id = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.group_specification_role_id);
            return MoiseScanner_variables.group_specification_role_id;
        }else if(identifier.equals("min") && from.equals("group-specification_role")){
            MoiseScanner_variables.group_specification_role_min = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.group_specification_role_min);
            if(MoiseScanner_methods.isNumber(MoiseScanner_variables.group_specification_role_min)){
                return MoiseScanner_variables.group_specification_role_min;
            }else{
                MoiseScanner_methods.MoiseScanner_error("NOT A POSITIVE INTEGER",1);
            }
        }else if(identifier.equals("max") && from.equals("group-specification_role")){
            MoiseScanner_variables.group_specification_role_max = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.group_specification_role_max);
            if(MoiseScanner_methods.isNumber(MoiseScanner_variables.group_specification_role_max)){
                return MoiseScanner_variables.group_specification_role_max;
            }else{
                MoiseScanner_methods.MoiseScanner_error("NOT A POSITIVE INTEGER",1);
            }
        }else if(identifier.equals("from") && from.equals("link")){
            MoiseScanner_variables.links_link_from = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.links_link_from);
            return MoiseScanner_variables.links_link_from;
        }else if(identifier.equals("to") && from.equals("link")){
            MoiseScanner_variables.links_link_to = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.links_link_to);
            return MoiseScanner_variables.links_link_to;
        }else if(identifier.equals("type") && from.equals("link")){
            MoiseScanner_variables.links_link_type = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.links_link_type);
            return MoiseScanner_variables.links_link_type;
        }else if(identifier.equals("scope") && from.equals("link")){
            MoiseScanner_variables.links_link_scope = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.links_link_scope);
            if (MoiseScanner_variables.links_link_scope.equals("intra-group") || MoiseScanner_variables.links_link_scope.equals("inter-group")){
                return MoiseScanner_variables.links_link_scope;
            }else{
                MoiseScanner_methods.MoiseScanner_error("ERROR: NOT INTRA-GROUP OR INTER-GROUP testing",1);
            }
        }else if(identifier.equals("extends") && from.equals("link")){
            MoiseScanner_variables.links_link_extendsSubgroups = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.links_link_extendsSubgroups);
            if(MoiseScanner_variables.links_link_extendsSubgroups.equals("true") || MoiseScanner_variables.links_link_extendsSubgroups.equals("false")){
                return MoiseScanner_variables.links_link_extendsSubgroups;
            }else{
                MoiseScanner_methods.MoiseScanner_error("NOT A BOOLEAN VALUE",1);
            }
        }else if(identifier.equals("bi") && from.equals("link")){
            MoiseScanner_variables.links_link_biDir = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.links_link_biDir);
            if(MoiseScanner_variables.links_link_biDir.equals("true") || MoiseScanner_variables.links_link_biDir.equals("false")){
                return MoiseScanner_variables.links_link_biDir;
            }else{
                MoiseScanner_methods.MoiseScanner_error("NOT A BOOLEAN VALUE",1);
            }
        }else if(identifier.equals("uri") && from.equals("include-group-specification")){
            MoiseScanner_variables.include_group_specification_uri = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.include_group_specification_uri);
            return MoiseScanner_variables.include_group_specification_uri;
        }else if(identifier.equals("min") && from.equals("cardinality")){
            MoiseScanner_variables.cardinality_min = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.cardinality_min);
            if(MoiseScanner_methods.isNumber(MoiseScanner_variables.cardinality_min)){
                return MoiseScanner_variables.cardinality_min;
            }else{
                MoiseScanner_methods.MoiseScanner_error("NOT A POSITIVE INTEGER",1);
            }
        }else if(identifier.equals("max") && from.equals("cardinality")){
            MoiseScanner_variables.cardinality_max = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.cardinality_max);
            if(MoiseScanner_methods.isNumber(MoiseScanner_variables.cardinality_max)){
                return MoiseScanner_variables.cardinality_max;
            }else{
                MoiseScanner_methods.MoiseScanner_error("NOT A POSITIVE INTEGER",1);
            }
        }else if(identifier.equals("object") && from.equals("cardinality")){
            MoiseScanner_variables.cardinality_object = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.cardinality_object);
            if (MoiseScanner_variables.cardinality_object.equals("role") || MoiseScanner_variables.cardinality_object.equals("group")){
                return MoiseScanner_variables.cardinality_object;
            }else{
                MoiseScanner_methods.MoiseScanner_error("ERROR: NOT ROLE OR GROUP ",1);
            }
        }else if(identifier.equals("id") && from.equals("cardinality")){
            MoiseScanner_variables.cardinality_id = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.cardinality_id);
            return MoiseScanner_variables.cardinality_id;
        }else if(identifier.equals("from") && from.equals("compatibility")){
            MoiseScanner_variables.compatibility_from = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.compatibility_from);
            return MoiseScanner_variables.compatibility_from;
        }else if(identifier.equals("to") && from.equals("compatibility")){
            MoiseScanner_variables.compatibility_to = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.compatibility_to);
            return MoiseScanner_variables.compatibility_to;
        }else if(identifier.equals("scope") && from.equals("compatibility")){
            MoiseScanner_variables.compatibility_scope = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.compatibility_scope);
            if (MoiseScanner_variables.compatibility_scope.equals("intra-group") || MoiseScanner_variables.compatibility_scope.equals("inter-group")){
                return MoiseScanner_variables.compatibility_scope;
            }else{
                MoiseScanner_methods.MoiseScanner_error("ERROR: NOT INTRA-GROUP OR INTER-GROUP ",1);
            }
        }else if(identifier.equals("extends") && from.equals("compatibility")){
            MoiseScanner_variables.compatibility_extends_subgroups = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.compatibility_extends_subgroups);
            if(MoiseScanner_variables.compatibility_extends_subgroups.equals("true") || MoiseScanner_variables.compatibility_extends_subgroups.equals("false")){
                return MoiseScanner_variables.compatibility_extends_subgroups;
            }else{
                MoiseScanner_methods.MoiseScanner_error("NOT A BOOLEAN VALUE",1);
            }
        }else if(identifier.equals("bi") && from.equals("compatibility")){
            MoiseScanner_variables.compatibility_bi_dir = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.compatibility_bi_dir);
            if(MoiseScanner_variables.compatibility_bi_dir.equals("true") || MoiseScanner_variables.compatibility_bi_dir.equals("false")){
                return MoiseScanner_variables.compatibility_bi_dir;
            }else{
                MoiseScanner_methods.MoiseScanner_error("NOT A BOOLEAN VALUE",1);
            }
        }else if(identifier.equals("type") && from.equals("compatibility")){
            MoiseScanner_variables.compatibility_type = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.compatibility_type);
            return MoiseScanner_variables.compatibility_type;
        }else if(identifier.equals("id") && from.equals("scheme")){
            MoiseScanner_variables.scheme_id = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.scheme_id);
            return MoiseScanner_variables.scheme_id;
        }else if(identifier.equals("id") && from.equals("goal")){
            MoiseScanner_variables.goal_id = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.goal_id);
            return MoiseScanner_variables.goal_id;
        }else if(identifier.equals("min") && from.equals("goal")){
            MoiseScanner_variables.goal_min = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.goal_min);
            if(MoiseScanner_methods.isNumber(MoiseScanner_variables.goal_min)){
                return MoiseScanner_variables.goal_min;
            }else{
                MoiseScanner_methods.MoiseScanner_error("NOT A POSITIVE INTEGER",1);
            }
        }else if(identifier.equals("ds") && from.equals("goal")){
            MoiseScanner_variables.goal_ds = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.goal_ds);
            return MoiseScanner_variables.goal_ds;
        }else if(identifier.equals("type") && from.equals("goal")){
            MoiseScanner_variables.goal_type = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.goal_type);
            if(MoiseScanner_variables.goal_type.equals("performance")||MoiseScanner_variables.goal_type.equals("achievement") || MoiseScanner_variables.goal_type.equals("maintenance")){
                return MoiseScanner_variables.goal_type;
            }else{
                MoiseScanner_methods.MoiseScanner_error("ERROR: NOT performance,achievement or maintenance",1);
            }
        }else if(identifier.equals("ttf") && from.equals("goal")){
            MoiseScanner_variables.goal_ttf = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.goal_ttf);
            return MoiseScanner_variables.goal_ttf;
        }else if(identifier.equals("location") && from.equals("goal")){
            MoiseScanner_variables.goal_location = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.goal_location);
            return MoiseScanner_variables.goal_location;
        }else if(identifier.equals("aType") && from.equals("goal")){
            MoiseScanner_variables.aType = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.aType);
            return MoiseScanner_variables.aType;
        }else if(identifier.equals("id") && from.equals("argument")){
            MoiseScanner_variables.argument_id = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.argument_id);
            return MoiseScanner_variables.argument_id;
        }else if(identifier.equals("value") && from.equals("argument")){
            MoiseScanner_variables.argument_value = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.argument_value);
            return MoiseScanner_variables.argument_value;
        }else if(identifier.equals("goal") && from.equals("depends-on")){
            MoiseScanner_variables.depends_on_goal = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.depends_on_goal);
            return MoiseScanner_variables.depends_on_goal;
        }else if(identifier.equals("operator") && from.equals("plan")){
            MoiseScanner_variables.plan_operator = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.plan_operator);
            if(MoiseScanner_variables.plan_operator.equals("sequence") || MoiseScanner_variables.plan_operator.equals("choice") || MoiseScanner_variables.plan_operator.equals("parallel")){
                return MoiseScanner_variables.plan_operator;
            }else{
                MoiseScanner_methods.MoiseScanner_error("ERROR: NOT sequence,choice or parallel",1);
            }
        }else if(identifier.equals("success") && from.equals("plan")){
            MoiseScanner_variables.plan_success_rate = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.plan_success_rate);
            if(MoiseScanner_methods.isDouble(MoiseScanner_variables.plan_success_rate)){
                return MoiseScanner_variables.plan_success_rate;
            }else{
                MoiseScanner_methods.MoiseScanner_error("NOT A DOUBLE",1);
            }
        }else if(identifier.equals("id") && from.equals("accountability-agreement")){
            MoiseScanner_variables.accountability_agreement_id = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.accountability_agreement_id);
            return MoiseScanner_variables.accountability_agreement_id;
        }else if(identifier.equals("id") && from.equals("target")){
            MoiseScanner_variables.target_id = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.target_id);
            return MoiseScanner_variables.target_id;
        }else if(identifier.equals("value") && from.equals("requesting-condition")){
            MoiseScanner_variables.requesting_condition_value = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.requesting_condition_value);
            return MoiseScanner_variables.requesting_condition_value;
        }else if(identifier.equals("id") && from.equals("condition-argument")){
            MoiseScanner_variables.condition_argument_id = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.condition_argument_id);
            return MoiseScanner_variables.condition_argument_id;
        }else if(identifier.equals("value") && from.equals("condition-argument")){
            MoiseScanner_variables.condition_argument_value = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.condition_argument_value);
            return MoiseScanner_variables.condition_argument_value;
        }else if(identifier.equals("id") && from.equals("account-argument")){
            MoiseScanner_variables.account_argument_id = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.account_argument_id);
            return MoiseScanner_variables.account_argument_id;
        }else if(identifier.equals("arity") && from.equals("account-argument")){
            MoiseScanner_variables.account_argument_arity = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.account_argument_arity);
            return MoiseScanner_variables.account_argument_arity;
        }else if(identifier.equals("atype") && from.equals("goal")){
            MoiseScanner_variables.aType = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.aType);
            return MoiseScanner_variables.aType;
        }else if(identifier.equals("when") && from.equals("goal")){
            MoiseScanner_variables.goal_when = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.goal_when);
            return MoiseScanner_variables.goal_when;
        }else if(identifier.equals("id") && from.equals("notification-policy")){
            MoiseScanner_variables.notification_policy_id = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.notification_policy_id);
            return MoiseScanner_variables.notification_policy_id;
        }else if(identifier.equals("target") && from.equals("notification-policy")){
            MoiseScanner_variables.notification_policy_target = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.notification_policy_target);
            return MoiseScanner_variables.notification_policy_target;
        }else if(identifier.equals("condition") && from.equals("notification-policy")){
            MoiseScanner_variables.notification_policy_condition = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.notification_policy_condition);
            return MoiseScanner_variables.notification_policy_condition;
        }else if(identifier.equals("id") && from.equals("exception-specification")){
            MoiseScanner_variables.exception_spec_id = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.exception_spec_id);
            return MoiseScanner_variables.exception_spec_id;
        }else if(identifier.equals("id") && from.equals("exception-argument")){
            MoiseScanner_variables.exception_argument_id = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.exception_argument_id);
            return MoiseScanner_variables.exception_argument_id;
        }else if(identifier.equals("arity") && from.equals("exception-argument")){
            MoiseScanner_variables.exception_argument_arity = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.exception_argument_arity);
            return MoiseScanner_variables.exception_argument_arity;
        }else if(identifier.equals("id") && from.equals("raising-goal")){
            MoiseScanner_variables.raising_goal_id = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.raising_goal_id);
            return MoiseScanner_variables.raising_goal_id;
        }else if(identifier.equals("min") && from.equals("raising-goal")){
            MoiseScanner_variables.raising_goal_min = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.raising_goal_min);
            if(MoiseScanner_methods.isNumber(MoiseScanner_variables.raising_goal_min)){
                return MoiseScanner_variables.raising_goal_min;
            }else{
                MoiseScanner_methods.MoiseScanner_error("NOT A POSITIVE INTEGER",1);
            }
        }else if(identifier.equals("ds") && from.equals("raising-goal")){
            MoiseScanner_variables.raising_goal_ds = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.raising_goal_ds);
            return MoiseScanner_variables.raising_goal_ds;
        }else if(identifier.equals("type") && from.equals("raising-goal")){
            MoiseScanner_variables.raising_goal_type = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.raising_goal_type);
            if(MoiseScanner_variables.raising_goal_type.equals("performance") || MoiseScanner_variables.raising_goal_type.equals("achievement") || MoiseScanner_variables.raising_goal_type.equals("maintenance")){
                return MoiseScanner_variables.raising_goal_type;
            }else{
                MoiseScanner_methods.MoiseScanner_error("ERROR: NOT performance,achievement or maintenance",1);
            }
        }else if(identifier.equals("ttf") && from.equals("raising-goal")){
            MoiseScanner_variables.raising_goal_ttf = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.raising_goal_ttf);
            return MoiseScanner_variables.raising_goal_ttf;
        }else if(identifier.equals("location") && from.equals("raising-goal")){
            MoiseScanner_variables.raising_goal_location = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.raising_goal_location);
            return MoiseScanner_variables.raising_goal_location;
        }else if(identifier.equals("when") && from.equals("raising-goal")){
            MoiseScanner_variables.raising_goal_when = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.raising_goal_when);
            return MoiseScanner_variables.raising_goal_when;
        }else if(identifier.equals("id") && from.equals("handling-goal")){
            MoiseScanner_variables.handling_goal_id = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.handling_goal_id);
            return MoiseScanner_variables.handling_goal_id;
        }else if(identifier.equals("min") && from.equals("handling-goal")){
            MoiseScanner_variables.handling_goal_min = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.handling_goal_min);
            if(MoiseScanner_methods.isNumber(MoiseScanner_variables.handling_goal_min)){
                return MoiseScanner_variables.handling_goal_min;
            }else{
                MoiseScanner_methods.MoiseScanner_error("NOT A POSITIVE INTEGER",1);
            }
        }else if(identifier.equals("ds") && from.equals("handling-goal")){
            MoiseScanner_variables.handling_goal_ds = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.handling_goal_ds);
            return MoiseScanner_variables.handling_goal_ds;
        }else if(identifier.equals("type") && from.equals("handling-goal")){
            MoiseScanner_variables.handling_goal_type = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.handling_goal_type);
            if(MoiseScanner_variables.handling_goal_type.equals("performance") || MoiseScanner_variables.handling_goal_type.equals("achievement") || MoiseScanner_variables.handling_goal_type.equals("maintenance")){
                return MoiseScanner_variables.handling_goal_type;
            }else{
                MoiseScanner_methods.MoiseScanner_error("ERROR: NOT performance,achievement or maintenance",1);
            }
        }else if(identifier.equals("ttf") && from.equals("handling-goal")){
            MoiseScanner_variables.handling_goal_ttf = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.handling_goal_ttf);
            return MoiseScanner_variables.handling_goal_ttf;
        }else if(identifier.equals("location") && from.equals("handling-goal")){
            MoiseScanner_variables.handling_goal_location = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.handling_goal_location);
            return MoiseScanner_variables.handling_goal_location;
        }else if(identifier.equals("when") && from.equals("handling-goal")){
            MoiseScanner_variables.handling_goal_when = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.handling_goal_when);
            return MoiseScanner_variables.handling_goal_when;
        }else if(identifier.equals("id") && from.equals("mission")){
            MoiseScanner_variables.mission_id = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.mission_id);
            return MoiseScanner_variables.mission_id;
        }else if(identifier.equals("min") && from.equals("mission")){
            MoiseScanner_variables.mission_min = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.mission_min);
            if(MoiseScanner_methods.isNumber(MoiseScanner_variables.mission_min)){
                return MoiseScanner_variables.mission_min;
            }else{
                MoiseScanner_methods.MoiseScanner_error("NOT A POSITIVE INTEGER",1);
            }
        }else if(identifier.equals("max") && from.equals("mission")){
            MoiseScanner_variables.mission_max = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.mission_max);
            if(MoiseScanner_methods.isNumber(MoiseScanner_variables.mission_max)){
                return MoiseScanner_variables.mission_max;
            }else{
                MoiseScanner_methods.MoiseScanner_error("NOT A POSITIVE INTEGER",1);
            }
        }else if(identifier.equals("id") && from.equals("mission-goal")){
            MoiseScanner_variables.mission_goal_id = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.mission_goal_id);
            return MoiseScanner_variables.mission_goal_id;
        }else if(identifier.equals("mission") && from.equals("preferred_mission")){
            MoiseScanner_variables.preferred_mission = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.preferred_mission);
            return MoiseScanner_variables.preferred_mission;
        }else if(identifier.equals("id") && from.equals("norm")){
            MoiseScanner_variables.norm_id = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.norm_id);
            return MoiseScanner_variables.norm_id;
        }else if(identifier.equals("condition") && from.equals("norm")){
            MoiseScanner_variables.norm_condition = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.norm_condition);
            return MoiseScanner_variables.norm_condition;
        }else if(identifier.equals("role") && from.equals("norm")){
            MoiseScanner_variables.norm_role = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.norm_role);
            return MoiseScanner_variables.norm_role;
        }else if(identifier.equals("type") && from.equals("norm")){
            MoiseScanner_variables.norm_type = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.norm_type);
            if(MoiseScanner_variables.norm_type.equals("obligation") || MoiseScanner_variables.norm_type.equals("permission")){
                return MoiseScanner_variables.norm_type;
            }else{
                MoiseScanner_methods.MoiseScanner_error("ERROR: NOT obligation or permission",1);
            }
        }else if(identifier.equals("mission") && from.equals("norm")){
            MoiseScanner_variables.norm_mission = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.norm_mission);
            return MoiseScanner_variables.norm_mission;
        }else if(identifier.equals("time") && from.equals("norm")){
            MoiseScanner_variables.norm_time_constraint = MoiseScanner_methods.removeLastChar(MoiseScanner_variables.norm_time_constraint);
            return MoiseScanner_variables.norm_time_constraint;
        }else{
            System.out.println("unknown identifier");
        }
        return "ERRORE";
    }
}
