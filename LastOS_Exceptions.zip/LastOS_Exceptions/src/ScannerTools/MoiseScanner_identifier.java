package ScannerTools;

import java.io.BufferedReader;

public class MoiseScanner_identifier {

    public static String return_identifier(BufferedReader br,String identifier,String from){
        MoiseScanner_methods.goto_new_line(br);
        if(!MoiseScanner_variables.stop){
            if(Character.isLetter(MoiseScanner_variables.peek)){
                String s6 = MoiseScanner_methods.attach_character(br);
                if(s6.equals(identifier)){
                    if(MoiseScanner_variables.peek == '='){
                        MoiseScanner_methods.readch(br);
                        if(MoiseScanner_variables.peek == '"'){
                            MoiseScanner_variables.property_id = "";
                            MoiseScanner_variables.property_value = "";
                            MoiseScanner_variables.role_definitions_role_id = "";
                            MoiseScanner_variables.role_definitions_extends_role = "";
                            MoiseScanner_variables.link_type_id = "";
                            MoiseScanner_variables.group_specification_id = "";
                            MoiseScanner_variables.links_link_from = "";
                            MoiseScanner_variables.links_link_scope = "";
                            MoiseScanner_variables.property_id = "";
                            MoiseScanner_variables.property_value = "";
                            MoiseScanner_variables.role_definitions_role_id = "";
                            MoiseScanner_variables.role_definitions_extends_role = "";
                            MoiseScanner_variables.link_type_id = "";
                            MoiseScanner_variables.group_specification_id = "";
                            MoiseScanner_variables.group_specification_min = "";
                            MoiseScanner_variables.group_specification_max = "";
                            MoiseScanner_variables.group_specification_role_id = "";
                            MoiseScanner_variables.group_specification_role_min = "";
                            MoiseScanner_variables.group_specification_role_max = "";
                            MoiseScanner_variables.links_link_from = "";
                            MoiseScanner_variables.links_link_scope = "";
                            MoiseScanner_variables.include_group_specification_uri = "";
                            MoiseScanner_variables.cardinality_min = "";
                            MoiseScanner_variables.cardinality_max = "";
                            MoiseScanner_variables.cardinality_object = "";
                            MoiseScanner_variables.cardinality_id = "";
                            MoiseScanner_variables.compatibility_from = "";
                            MoiseScanner_variables.compatibility_to = "";
                            MoiseScanner_variables.compatibility_scope = "";
                            MoiseScanner_variables.compatibility_type = "";
                            MoiseScanner_variables.scheme_id = "";
                            MoiseScanner_variables.goal_id = "";
                            MoiseScanner_variables.goal_min = "";
                            MoiseScanner_variables.goal_ds = "";
                            MoiseScanner_variables.goal_type = "";
                            MoiseScanner_variables.goal_ttf = "";
                            MoiseScanner_variables.goal_location = "";
                            MoiseScanner_variables.argument_id = "";
                            MoiseScanner_variables.argument_value = "";
                            MoiseScanner_variables.depends_on_goal = "";
                            MoiseScanner_variables.plan_operator = "";
                            MoiseScanner_variables.target_id = "";
                            MoiseScanner_variables.accountability_agreement_id = "";
                            MoiseScanner_variables.requesting_condition_value = "";
                            MoiseScanner_variables.condition_argument_id = "";
                            MoiseScanner_variables.condition_argument_value = "";
                            MoiseScanner_variables.account_argument_id = "";
                            MoiseScanner_variables.account_argument_arity = "";
                            MoiseScanner_variables.notification_policy_id = "";
                            MoiseScanner_variables.goal_when = "";
                            MoiseScanner_variables.notification_policy_target = "";
                            MoiseScanner_variables.notification_policy_condition = "";
                            MoiseScanner_variables.exception_spec_id = "";
                            MoiseScanner_variables.exception_argument_id = "";
                            MoiseScanner_variables.exception_argument_arity = "";
                            MoiseScanner_variables.raising_goal_id = "";
                            MoiseScanner_variables.raising_goal_min = "";
                            MoiseScanner_variables.raising_goal_ds = "";
                            MoiseScanner_variables.raising_goal_type = "";
                            MoiseScanner_variables.raising_goal_ttf = "";
                            MoiseScanner_variables.raising_goal_location = "";
                            MoiseScanner_variables.raising_goal_when = "";
                            MoiseScanner_variables.handling_goal_id = "";
                            MoiseScanner_variables.handling_goal_min = "";
                            MoiseScanner_variables.handling_goal_ds = "";
                            MoiseScanner_variables.handling_goal_type = "";
                            MoiseScanner_variables.handling_goal_ttf = "";
                            MoiseScanner_variables.handling_goal_location = "";
                            MoiseScanner_variables.handling_goal_when = "";
                            MoiseScanner_variables.mission_id = "";
                            MoiseScanner_variables.mission_min = "";
                            MoiseScanner_variables.mission_max = "";
                            MoiseScanner_variables.mission_goal_id = "";
                            MoiseScanner_variables.preferred_mission = "";
                            MoiseScanner_variables.norm_id = "";
                            MoiseScanner_variables.norm_condition = "";
                            MoiseScanner_variables.norm_role = "";
                            MoiseScanner_variables.norm_type = "";
                            MoiseScanner_variables.norm_mission = "";
                            MoiseScanner_variables.aType = "";
                            boolean status_id = true;
                            MoiseScanner_methods.readch(br);
                            while(status_id){
                                if (MoiseScanner_variables.peek == '"'){
                                    status_id = false;
                                }
                                MoiseScanner_filler.single_value(identifier,from);
                                MoiseScanner_methods.readch(br);
                            }
                            MoiseScanner_methods.goto_new_line(br);
                            return MoiseScanner_filler.return_value_filler(identifier,from);
                        }else{
                            MoiseScanner_methods.MoiseScanner_error(null,1);
                        }
                    }else{
                        MoiseScanner_methods.MoiseScanner_error(null,1);
                    }
                }else{
                    MoiseScanner_methods.MoiseScanner_error(s6,1);
                }
            }else{
                MoiseScanner_methods.MoiseScanner_error(null,1);
            }
        }
        return "ERROR";
    }

    public static String return_identifier2(BufferedReader br,String identifier,String from){
        MoiseScanner_methods.goto_new_line(br);
        if(!MoiseScanner_variables.stop){
            if(MoiseScanner_variables.peek == '='){
                MoiseScanner_methods.readch(br);
                if (MoiseScanner_variables.peek == '"') {
                    MoiseScanner_variables.group_specification_min = "";
                    MoiseScanner_variables.group_specification_max = "";
                    MoiseScanner_variables.group_specification_role_min = "";
                    MoiseScanner_variables.group_specification_role_max = "";
                    MoiseScanner_variables.property_id = "";
                    MoiseScanner_variables.property_value = "";
                    MoiseScanner_variables.role_definitions_role_id = "";
                    MoiseScanner_variables.role_definitions_extends_role = "";
                    MoiseScanner_variables.link_type_id = "";
                    MoiseScanner_variables.group_specification_id = "";
                    MoiseScanner_variables.group_specification_min = "";
                    MoiseScanner_variables.group_specification_max = "";
                    MoiseScanner_variables.group_specification_role_id = "";
                    MoiseScanner_variables.group_specification_role_min = "";
                    MoiseScanner_variables.group_specification_role_max = "";
                    MoiseScanner_variables.links_link_from = "";
                    MoiseScanner_variables.links_link_scope = "";
                    MoiseScanner_variables.include_group_specification_uri = "";
                    MoiseScanner_variables.cardinality_min = "";
                    MoiseScanner_variables.cardinality_max = "";
                    MoiseScanner_variables.cardinality_object = "";
                    MoiseScanner_variables.cardinality_id = "";
                    MoiseScanner_variables.compatibility_from = "";
                    MoiseScanner_variables.compatibility_to = "";
                    MoiseScanner_variables.compatibility_scope = "";
                    MoiseScanner_variables.compatibility_type = "";
                    MoiseScanner_variables.scheme_id = "";
                    MoiseScanner_variables.goal_id = "";
                    MoiseScanner_variables.goal_min = "";
                    MoiseScanner_variables.goal_ds = "";
                    MoiseScanner_variables.goal_type = "";
                    MoiseScanner_variables.goal_ttf = "";
                    MoiseScanner_variables.goal_location = "";
                    MoiseScanner_variables.argument_id = "";
                    MoiseScanner_variables.argument_value = "";
                    MoiseScanner_variables.depends_on_goal = "";
                    MoiseScanner_variables.plan_operator = "";
                    MoiseScanner_variables.notification_policy_id = "";
                    MoiseScanner_variables.notification_policy_target = "";
                    MoiseScanner_variables.notification_policy_condition = "";
                    MoiseScanner_variables.exception_spec_id = "";
                    MoiseScanner_variables.exception_argument_id = "";
                    MoiseScanner_variables.exception_argument_arity = "";
                    MoiseScanner_variables.raising_goal_id = "";
                    MoiseScanner_variables.raising_goal_min = "";
                    MoiseScanner_variables.raising_goal_ds = "";
                    MoiseScanner_variables.raising_goal_type = "";
                    MoiseScanner_variables.raising_goal_ttf = "";
                    MoiseScanner_variables.raising_goal_location = "";
                    MoiseScanner_variables.raising_goal_when = "";
                    MoiseScanner_variables.handling_goal_id = "";
                    MoiseScanner_variables.handling_goal_min = "";
                    MoiseScanner_variables.handling_goal_ds = "";
                    MoiseScanner_variables.handling_goal_type = "";
                    MoiseScanner_variables.handling_goal_ttf = "";
                    MoiseScanner_variables.handling_goal_location = "";
                    MoiseScanner_variables.handling_goal_when = "";
                    MoiseScanner_variables.mission_id = "";
                    MoiseScanner_variables.mission_min = "";
                    MoiseScanner_variables.mission_max = "";
                    MoiseScanner_variables.mission_goal_id = "";
                    MoiseScanner_variables.preferred_mission = "";
                    MoiseScanner_variables.norm_id = "";
                    MoiseScanner_variables.norm_condition = "";
                    MoiseScanner_variables.norm_role = "";
                    MoiseScanner_variables.norm_type = "";
                    MoiseScanner_variables.norm_mission = "";
                    MoiseScanner_variables.group_specification_min = "";
                    MoiseScanner_variables.group_specification_max = "";
                    MoiseScanner_variables.group_specification_role_id = "";
                    MoiseScanner_variables.group_specification_role_min = "";
                    MoiseScanner_variables.group_specification_role_max = "";
                    MoiseScanner_variables.links_link_to = "";
                    MoiseScanner_variables.links_link_type = "";
                    boolean status_id = true;
                    MoiseScanner_methods.readch(br);
                    while(status_id){
                        if(MoiseScanner_variables.peek == '"'){
                            status_id = false;
                        }
                        MoiseScanner_filler.single_value(identifier, from);
                        MoiseScanner_methods.readch(br);
                    }
                    MoiseScanner_methods.goto_new_line(br);
                    return MoiseScanner_filler.return_value_filler(identifier, from);
                }else{
                    MoiseScanner_methods.MoiseScanner_error(null, 1);
                }
            }else{
                MoiseScanner_methods.MoiseScanner_error(null, 1);
            }
        }
        return "ERROR";
    }

    public static String return_ComposeIdentifier(BufferedReader br,String identifier_part1,String identifier_part2,String from){
        MoiseScanner_methods.goto_new_line(br);
        if(!MoiseScanner_variables.stop){
            if(Character.isLetter(MoiseScanner_variables.peek)){
                String s1 = MoiseScanner_methods.attach_character(br);
                if(s1.equals(identifier_part1)){
                    if(MoiseScanner_variables.peek == '-'){
                        MoiseScanner_methods.readch(br);
                        if(Character.isLetter(MoiseScanner_variables.peek)){
                            String s2 = MoiseScanner_methods.attach_character(br);
                            if(s2.equals(identifier_part2)){
                                if (MoiseScanner_variables.peek == '=') {
                                    MoiseScanner_methods.readch(br);
                                    if(MoiseScanner_variables.peek == '"'){
                                        MoiseScanner_variables.links_link_extendsSubgroups = "";
                                        MoiseScanner_variables.links_link_biDir = "";
                                        MoiseScanner_variables.compatibility_extends_subgroups = "";
                                        MoiseScanner_variables.compatibility_bi_dir = "";
                                        MoiseScanner_variables.plan_success_rate = "";
                                        MoiseScanner_variables.norm_time_constraint = "";
                                        boolean status_id = true;
                                        MoiseScanner_methods.readch(br);
                                        while(status_id){
                                            if(MoiseScanner_variables.peek == '"'){
                                                status_id = false;
                                            }
                                            MoiseScanner_filler.single_value(identifier_part1,from);
                                            MoiseScanner_methods.readch(br);
                                        }
                                        MoiseScanner_methods.goto_new_line(br);
                                        return MoiseScanner_filler.return_value_filler(identifier_part1, from);
                                    }else{
                                        MoiseScanner_methods.MoiseScanner_error(null,1);
                                    }
                                }else{
                                    MoiseScanner_methods.MoiseScanner_error(null,1);
                                }
                            }else{
                                MoiseScanner_methods.MoiseScanner_error(s2,1);
                            }
                        }else{
                            MoiseScanner_methods.MoiseScanner_error(null,1);
                        }
                    }else{
                        MoiseScanner_methods.MoiseScanner_error(null,1);
                    }
                }else{
                    MoiseScanner_methods.MoiseScanner_error(s1,1);
                }
            }else{
                MoiseScanner_methods.MoiseScanner_error(null,1);
            }
        }
        return "ERROR";
    }

    public static String return_ComposeIdentifier2(BufferedReader br,String identifier_part1,String identifier_part2,String from){
        MoiseScanner_methods.goto_new_line(br);
        if(!MoiseScanner_variables.stop){
            if(MoiseScanner_variables.peek == '-'){
                MoiseScanner_methods.readch(br);
                if(Character.isLetter(MoiseScanner_variables.peek)){
                    String s2 = MoiseScanner_methods.attach_character(br);
                    if(s2.equals(identifier_part2)){
                        if(MoiseScanner_variables.peek == '='){
                            MoiseScanner_methods.readch(br);
                            if(MoiseScanner_variables.peek == '"'){
                                MoiseScanner_variables.norm_time_constraint = "";
                                boolean status_id = true;
                                MoiseScanner_methods.readch(br);
                                while(status_id){
                                    if (MoiseScanner_variables.peek == '"') {
                                        status_id = false;
                                    }
                                    MoiseScanner_filler.single_value(identifier_part1, from);
                                    MoiseScanner_methods.readch(br);
                                }
                                MoiseScanner_methods.goto_new_line(br);
                                return MoiseScanner_filler.return_value_filler(identifier_part1, from);
                            }else{
                                MoiseScanner_methods.MoiseScanner_error(null, 1);
                            }
                        }else{
                            MoiseScanner_methods.MoiseScanner_error(null, 1);
                        }
                    }
                }else{
                    MoiseScanner_methods.MoiseScanner_error(null, 1);
                }
            }
        }
        return "ERROR";
    }

}