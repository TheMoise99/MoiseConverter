package ScannerTools;

import java.util.ArrayList;

public class MoiseScanner_identifier_checker{
    public static void checker(ArrayList<Boolean> identifier){
        for(Boolean check:identifier){
            if(!check){
                MoiseScanner_methods.MoiseScanner_error("ERROR: obligatory attribute missing", 1);
            }
        }
        identifier.clear();
    }
}