package ScannerTools;

import java.io.BufferedReader;
import java.util.ArrayList;
import java.util.Arrays;

public class MoiseScanner_identifier_recognition{

    public static void identifier_recognition(BufferedReader br,String element,String from_where){
        ArrayList<Boolean> identifier = new ArrayList<>();
        boolean closed = false;
        switch (element){
            case "property" ->{
                boolean boolean_id  = false;
                boolean boolean_value = false;
                String id = "";
                String value = "";
                String index_father = "";
                switch (from_where) {
                    case "start" -> index_father = "none";
                    case "structural-specification" -> index_father = "structural-specification";
                    case "inside_role" -> index_father = MoiseScanner_methods.to_String(variables_for_HashMap.index_role - 1);
                    case "group-specification" -> index_father = MoiseScanner_methods.to_String(variables_for_HashMap.index_group_specification - 1);
                    case "functional-specification" -> index_father = "functional-specification";
                    case "scheme" -> index_father = MoiseScanner_methods.to_String(variables_for_HashMap.index_fs_scheme - 1);
                    case "plan" -> index_father = MoiseScanner_methods.to_String(variables_for_HashMap.index_fs_plan - 1);
                    case "notification-policy" -> index_father = MoiseScanner_methods.to_String(variables_for_HashMap.index_fs_notification_policy - 1);
                    case "mission" -> index_father = MoiseScanner_methods.to_String(variables_for_HashMap.index_fs_mission - 1);
                    case "accountability-agreement" -> index_father = MoiseScanner_methods.to_String(variables_for_HashMap.index_fs_accountability_agreement - 1);
                    case "normative-specification" -> index_father = "normative-specification";
                    default -> MoiseScanner_methods.MoiseScanner_error("ERROR: properties error", 1);
                }

                MoiseScanner_variables.cycle = true ;
                while(MoiseScanner_variables.cycle&&!closed){
                    MoiseScanner_methods.goto_new_line(br);
                    switch (MoiseScanner_variables.peek) {
                        case 'i' ->{
                            id = MoiseScanner_identifier.return_identifier(br, "id", "properties_property");
                            boolean_id = true;
                        }
                        case 'v' ->{
                            value = MoiseScanner_identifier.return_identifier(br, "value", "properties_property");
                            boolean_value = true;
                        }
                        case '/' ->{
                            identifier.add(boolean_id);
                            identifier.add(boolean_value);
                            boolean_id = false;
                            boolean_value = false;
                            MoiseScanner_tag.simpleCloseTag2(br);
                            MoiseScanner_identifier_checker.checker(identifier);
                            MoiseScanner_variables.cycle = MoiseScanner_tag.Tag_peek(br, "property");
                            MoiseScanner_HashMap.property.put(variables_for_HashMap.index_property, new ArrayList<>(Arrays.asList(from_where, "no",id,value,index_father)));
                            variables_for_HashMap.index_property++;
                            id = "";
                            value = "";
                        }
                        default ->{
                            closed = true;
                            MoiseScanner_methods.MoiseScanner_error("ERROR: properties identifier error", 1);
                        }
                    }
                }
            }
            case "group-specification" ->{
                boolean boolean_id  = false;
                String id = "";
                String min = "";
                String max = "";
                String index_father = "";
                String count_sub = MoiseScanner_methods.to_String(MoiseScanner_variables.counter_subgroups);
                if(from_where.equals("structural-specification")){
                    index_father = "none";
                }else if(from_where.equals("subgroups")){
                    index_father = MoiseScanner_methods.to_String(MoiseScanner_variables.iSubgroups.get(MoiseScanner_variables.iSubgroups.size()-1));
                }else{
                    MoiseScanner_methods.MoiseScanner_error("ERROR: group-specification error", 1);
                }

                while(!closed){
                    MoiseScanner_methods.goto_new_line(br);
                    switch (MoiseScanner_variables.peek) {
                        case 'i' ->{
                            id = MoiseScanner_identifier.return_identifier(br, "id", "group-specification");
                            boolean_id = true;
                        }
                        case 'm' ->{
                            if(Character.isLetter(MoiseScanner_variables.peek)) {
                                String s1 = MoiseScanner_methods.attach_character(br);
                                if(s1.equals("min")){
                                    min = MoiseScanner_identifier.return_identifier2(br, "min", "group-specification");
                                }else if(s1.equals("max")){
                                    max = MoiseScanner_identifier.return_identifier2(br, "max", "group-specification");
                                }else{
                                    MoiseScanner_methods.MoiseScanner_error("ERROR: unknown identifier", 1);
                                }
                            }
                        }
                        case '>' ->{
                            identifier.add(boolean_id);
                            boolean_id = false;
                            closed = true;
                            MoiseScanner_tag.simpleCloseTag(br);
                            MoiseScanner_identifier_checker.checker(identifier);
                            MoiseScanner_HashMap.group_specification.put(variables_for_HashMap.index_group_specification, new ArrayList<>(Arrays.asList(from_where, "yes", id,min,max,index_father,count_sub)));
                            MoiseScanner_variables.iGSType.add(variables_for_HashMap.index_group_specification);
                            variables_for_HashMap.index_group_specification++;
                            id = "";
                            min = "";
                            max = "";
                        }
                        default ->{
                            closed = true;
                            MoiseScanner_methods.MoiseScanner_error("ERROR: group-specification identifier error", 1);
                        }
                    }
                }
            }
            case "group-specification_role" ->{
                boolean boolean_id  = false;
                String id = "";
                String min = "";
                String max = "";
                String index_father =  MoiseScanner_methods.to_String(variables_for_HashMap.index_group_specification-1);
                MoiseScanner_variables.cycle = true ;
                while(MoiseScanner_variables.cycle&&!closed){
                    MoiseScanner_methods.goto_new_line(br);
                    switch (MoiseScanner_variables.peek) {
                        case 'i' ->{
                            id = MoiseScanner_identifier.return_identifier(br, "id", "group-specification_role");
                            boolean_id = true;
                        }
                        case 'm' ->{
                            if(Character.isLetter(MoiseScanner_variables.peek)){
                                String s1 = MoiseScanner_methods.attach_character(br);
                                if(s1.equals("min")){
                                    min = MoiseScanner_identifier.return_identifier2(br, "min", "group-specification_role");
                                }else if(s1.equals("max")){
                                    max = MoiseScanner_identifier.return_identifier2(br, "max", "group-specification_role");
                                }else{
                                    MoiseScanner_methods.MoiseScanner_error("ERROR: unknown identifier", 1);
                                }
                            }
                        }
                        case '/' ->{
                            identifier.add(boolean_id);
                            boolean_id = false;
                            MoiseScanner_tag.simpleCloseTag2(br);
                            MoiseScanner_identifier_checker.checker(identifier);
                            MoiseScanner_variables.cycle = MoiseScanner_tag.Tag_peek(br, "role");
                            MoiseScanner_HashMap.roles_role.put(variables_for_HashMap.index_roles_role, new ArrayList<>(Arrays.asList("roles", "no", id,min,max,index_father)));
                            variables_for_HashMap.index_roles_role++;
                            id = "";
                            min = "";
                            max = "";
                        }
                        default ->{
                            closed = true;
                            MoiseScanner_methods.MoiseScanner_error("ERROR: group-specification role error", 1);
                        }
                    }
                }
            }
            case "link" ->{
                String from = "";
                String to = "";
                String type = "";
                String scope = "";
                String extends_subgroups = "";
                String bi_dir = "";
                String index_father = MoiseScanner_methods.to_String(variables_for_HashMap.index_group_specification-1);
                MoiseScanner_variables.cycle = true ;
                while(MoiseScanner_variables.cycle&&!closed){
                    MoiseScanner_methods.goto_new_line(br);
                    switch (MoiseScanner_variables.peek) {
                        case 'f' -> from = MoiseScanner_identifier.return_identifier(br, "from", "link");
                        case 't' ->{
                            if(Character.isLetter(MoiseScanner_variables.peek)){
                                String s1 = MoiseScanner_methods.attach_character(br);
                                if(s1.equals("to")){
                                    to = MoiseScanner_identifier.return_identifier2(br, "to", "link");
                                }else if(s1.equals("type")){
                                    type = MoiseScanner_identifier.return_identifier2(br, "type", "link");
                                }else{
                                    MoiseScanner_methods.MoiseScanner_error("ERROR: unknown identifier", 1);
                                }
                            }
                        }
                        case 's' -> scope = MoiseScanner_identifier.return_identifier(br, "scope", "link");
                        case 'e' -> extends_subgroups = MoiseScanner_identifier.return_ComposeIdentifier(br, "extends","subgroups", "link");
                        case 'b' -> bi_dir = MoiseScanner_identifier.return_ComposeIdentifier(br, "bi" ,"dir", "link");
                        case '/' ->{
                            MoiseScanner_tag.simpleCloseTag2(br);
                            MoiseScanner_variables.cycle = MoiseScanner_tag.Tag_peek(br, "link");
                            MoiseScanner_HashMap.link.put(variables_for_HashMap.index_link, new ArrayList<>(Arrays.asList("links", "no",from,to,type,scope,extends_subgroups,bi_dir,index_father)));
                            variables_for_HashMap.index_link++;
                            from = "";
                            to = "";
                            type = "";
                            scope = "";
                            extends_subgroups = "";
                            bi_dir = "";
                        }
                        default ->{
                            closed = true;
                            MoiseScanner_methods.MoiseScanner_error("ERROR: link role identifier error", 1);
                        }
                    }
                }
            }
            case "cardinality" ->{
                boolean boolean_object = false;
                boolean boolean_id  = false;
                String min = "";
                String max = "";
                String object = "";
                String id = "";

                String index_father = MoiseScanner_methods.to_String(MoiseScanner_variables.iGSType.get(MoiseScanner_variables.iGSType.size()-1));

                MoiseScanner_variables.cycle = true ;
                while(MoiseScanner_variables.cycle&&!closed){
                    MoiseScanner_methods.goto_new_line(br);
                    switch (MoiseScanner_variables.peek) {
                        case 'o' ->{
                            object = MoiseScanner_identifier.return_identifier(br, "object", "cardinality");
                            boolean_object = true;
                        }
                        case 'm' ->{
                            if(Character.isLetter(MoiseScanner_variables.peek)){
                                String s1 = MoiseScanner_methods.attach_character(br);
                                if(s1.equals("min")){
                                    min = MoiseScanner_identifier.return_identifier2(br, "min", "cardinality");
                                }else if(s1.equals("max")){
                                    max = MoiseScanner_identifier.return_identifier2(br, "max", "cardinality");
                                }else{
                                    MoiseScanner_methods.MoiseScanner_error("ERROR: unknown identifier", 1);
                                }
                            }
                        }
                        case 'i' ->{
                            id = MoiseScanner_identifier.return_identifier(br, "id", "cardinality");
                            boolean_id = true;
                        }
                        case '/' ->{
                            identifier.add(boolean_id);
                            identifier.add(boolean_object);
                            boolean_id = false;
                            boolean_object = false;
                            MoiseScanner_tag.simpleCloseTag2(br);
                            MoiseScanner_identifier_checker.checker(identifier);
                            MoiseScanner_variables.cycle = MoiseScanner_tag.Tag_peek(br, "cardinality");
                            MoiseScanner_HashMap.cardinality.put(variables_for_HashMap.index_cardinality, new ArrayList<>(Arrays.asList("formation-constraints", "no",min,max,object,id,index_father)));
                            variables_for_HashMap.index_cardinality++;
                            min = "";
                            max = "";
                            object = "";
                            id = "";
                        }
                        default ->{
                            closed = true;
                            MoiseScanner_methods.MoiseScanner_error("ERROR: cardinality identifier error", 1);
                        }
                    }
                }
            }
            case "compatibility" ->{
                MoiseScanner_variables.cycle = true ;
                boolean boolean_from = false;
                boolean boolean_to  = false;
                String from = "";
                String to = "";
                String type = "";
                String scope = "";
                String extends_subgroups = "";
                String bi_dir = "";

                String index_father =  MoiseScanner_methods.to_String(MoiseScanner_variables.iGSType.get(MoiseScanner_variables.iGSType.size()-1));

                while(MoiseScanner_variables.cycle&&!closed){
                    MoiseScanner_methods.goto_new_line(br);
                    switch (MoiseScanner_variables.peek) {
                        case 'f' ->{
                            from = MoiseScanner_identifier.return_identifier(br, "from", "compatibility");
                            boolean_from = true;
                        }
                        case 't' ->{
                            if(Character.isLetter(MoiseScanner_variables.peek)){
                                String s1 = MoiseScanner_methods.attach_character(br);
                                if(s1.equals("to")){
                                    to = MoiseScanner_identifier.return_identifier2(br, "to", "compatibility");
                                    boolean_to = true;
                                }else if(s1.equals("type")){
                                    type = MoiseScanner_identifier.return_identifier2(br, "type", "compatibility");
                                }else{
                                    MoiseScanner_methods.MoiseScanner_error("ERROR: unknown identifier", 1);
                                }
                            }
                        }
                        case 's' -> scope = MoiseScanner_identifier.return_identifier(br, "scope", "compatibility");
                        case 'e' -> extends_subgroups = MoiseScanner_identifier.return_ComposeIdentifier(br, "extends","subgroups", "compatibility");
                        case 'b' -> bi_dir = MoiseScanner_identifier.return_ComposeIdentifier(br, "bi","dir", "compatibility");
                        case '/' ->{
                            identifier.add(boolean_from);
                            identifier.add(boolean_to);
                            boolean_from = false;
                            boolean_to = false;
                            MoiseScanner_tag.simpleCloseTag2(br);
                            MoiseScanner_identifier_checker.checker(identifier);
                            MoiseScanner_variables.cycle = MoiseScanner_tag.Tag_peek(br, "compatibility");
                            MoiseScanner_HashMap.compatibility.put(variables_for_HashMap.index_compatibility, new ArrayList<>(Arrays.asList("formation-constraints","no",from,to,type,scope,extends_subgroups,bi_dir,index_father)));
                            variables_for_HashMap.index_compatibility++;
                            from = "";
                            to = "";
                            type = "";
                            scope = "";
                            extends_subgroups = "";
                            bi_dir = "";
                        }
                        default ->{
                            closed = true;
                            MoiseScanner_methods.MoiseScanner_error("ERROR: compatibility identifier error", 1);
                        }
                    }
                }
            }
            case "goal" -> {
                MoiseScanner_variables.cycle = true;
                boolean boolean_id = false;
                String aType = "";
                String when = "";
                String id = "";
                String min = "";
                String ds = "";
                String type = "";
                String ttf = "";
                String location = "";
                String index_father;
                if (from_where.equals("scheme")) {
                    index_father = MoiseScanner_methods.to_String(variables_for_HashMap.index_fs_scheme - 1);
                }else if(from_where.equals("account-template")){
                    index_father = MoiseScanner_methods.to_String(variables_for_HashMap.index_fs_accountability_agreement - 1);
                }else{
                    index_father = MoiseScanner_methods.to_String(MoiseScanner_variables.iPlan.get(MoiseScanner_variables.iPlan.size()-1));
                }
                while(MoiseScanner_variables.cycle&&!closed){
                    MoiseScanner_methods.goto_new_line(br);
                    switch (MoiseScanner_variables.peek) {
                        case 'a' -> aType = MoiseScanner_identifier.return_identifier(br, "atype", "goal");
                        case 'i' ->{
                            id = MoiseScanner_identifier.return_identifier(br, "id", "goal");
                            boolean_id = true;
                        }
                        case 't' ->{
                            if(Character.isLetter(MoiseScanner_variables.peek)){
                                String s1 = MoiseScanner_methods.attach_character(br);
                                if(s1.equals("ttf")){
                                    ttf = MoiseScanner_identifier.return_identifier2(br, "ttf", "goal");
                                }else if(s1.equals("type")){
                                    type = MoiseScanner_identifier.return_identifier2(br, "type", "goal");
                                }else{
                                    MoiseScanner_methods.MoiseScanner_error("ERROR: unknown identifier", 1);
                                }
                            }
                        }
                        case 'm' -> min = MoiseScanner_identifier.return_identifier(br, "min", "goal");
                        case 'd' -> ds = MoiseScanner_identifier.return_identifier(br, "ds", "goal");
                        case 'l' -> location = MoiseScanner_identifier.return_identifier(br, "location", "goal");
                        case 'w' -> when = MoiseScanner_identifier.return_identifier(br, "when", "goal");
                        case '/' ->{
                            identifier.add(boolean_id);
                            boolean_id = false;
                            MoiseScanner_tag.simpleCloseTag2(br);
                            MoiseScanner_identifier_checker.checker(identifier);
                            if(!MoiseScanner_variables.from_scheme){//false
                                MoiseScanner_variables.cycle = MoiseScanner_tag.Tag_peek(br, "goal");
                            }else{
                                MoiseScanner_variables.cycle = false;
                            }
                            MoiseScanner_HashMap.fs_goal.put(variables_for_HashMap.index_fs_goal, new ArrayList<>(Arrays.asList(from_where,"no",id,min,ds,type,ttf,location,index_father,aType,when)));
                            variables_for_HashMap.index_fs_goal++;
                            id = "";
                            min = "";
                            ds = "";
                            type = "";
                            ttf = "";
                            location = "";
                            aType = "";
                            when = "";
                        }
                        case '>' ->{
                            identifier.add(boolean_id);
                            boolean_id = false;
                            MoiseScanner_variables.flag_noPlan = true;
                            MoiseScanner_tag.simpleCloseTag(br);
                            MoiseScanner_identifier_checker.checker(identifier);
                            if(!MoiseScanner_variables.from_scheme){//false
                                MoiseScanner_variables.cycle = MoiseScanner_tag.Tag_peek(br, "goal");
                            }else{
                                MoiseScanner_variables.cycle = false;
                            }
                            MoiseScanner_HashMap.fs_goal.put(variables_for_HashMap.index_fs_goal, new ArrayList<>(Arrays.asList(from_where,"yes",id,min,ds,type,ttf,location,index_father,aType,when)));
                            variables_for_HashMap.index_fs_goal++;
                            id = "";
                            min = "";
                            ds = "";
                            type = "";
                            ttf = "";
                            location = "";
                            aType = "";
                            when = "";
                        }
                        default ->{
                            closed = true;
                            MoiseScanner_methods.MoiseScanner_error("ERROR: identifier error", 1);
                        }
                    }
                }
            }
            case "argument" ->{
                MoiseScanner_variables.cycle = true ;
                boolean boolean_id = false;
                String id = "";
                String value = "";
                String index_father;
                if(from_where.equals("raising-goal")){
                    index_father =  MoiseScanner_methods.to_String(variables_for_HashMap.index_fs_raising_goal-1);
                }else if(from_where.equals("handling-goal")){
                    index_father =  MoiseScanner_methods.to_String(variables_for_HashMap.index_fs_handling_goal-1);
                }else{
                    index_father = MoiseScanner_methods.to_String(variables_for_HashMap.index_fs_goal-1);
                }
                while(MoiseScanner_variables.cycle&&!closed){
                    MoiseScanner_methods.goto_new_line(br);
                    switch (MoiseScanner_variables.peek) {
                        case 'i' ->{
                            id = MoiseScanner_identifier.return_identifier(br, "id", "argument");
                            boolean_id = true;
                        }
                        case 'v' -> value = MoiseScanner_identifier.return_identifier(br, "value", "argument");
                        case '/' ->{
                            identifier.add(boolean_id);
                            boolean_id = false;
                            MoiseScanner_tag.simpleCloseTag2(br);
                            MoiseScanner_identifier_checker.checker(identifier);
                            MoiseScanner_variables.cycle = MoiseScanner_tag.Tag_peek(br, "argument");
                            MoiseScanner_HashMap.fs_argument.put(variables_for_HashMap.index_fs_argument, new ArrayList<>(Arrays.asList(from_where,"no",id,value,index_father)));
                            variables_for_HashMap.index_fs_argument++;
                            id = "";
                            value = "";
                        }
                        default ->{
                            closed = true;
                            MoiseScanner_methods.MoiseScanner_error("ERROR: argument identifier error", 1);
                        }
                    }
                }
            }
            case "plan" ->{
                boolean boolean_operator = false;
                String operator = "";
                String success_rate = "";
                String index_father;
                if(from_where.equals("raising-goal")){
                    index_father =  MoiseScanner_methods.to_String(variables_for_HashMap.index_fs_raising_goal-1);
                }else if(from_where.equals("handling-goal")){
                    index_father =  MoiseScanner_methods.to_String(variables_for_HashMap.index_fs_handling_goal-1);
                }else{
                    index_father =  MoiseScanner_methods.to_String(variables_for_HashMap.index_fs_goal-1);
                }
                while(!closed){
                    MoiseScanner_methods.goto_new_line(br);
                    switch (MoiseScanner_variables.peek) {
                        case 'o' ->{
                            operator = MoiseScanner_identifier.return_identifier(br, "operator", "plan");
                            boolean_operator = true;
                        }
                        case 's' -> success_rate = MoiseScanner_identifier.return_ComposeIdentifier(br, "success", "rate", "plan");
                        case '>' ->{
                            identifier.add(boolean_operator);
                            boolean_operator = false;
                            closed = true;
                            MoiseScanner_tag.simpleCloseTag(br);
                            MoiseScanner_identifier_checker.checker(identifier);
                            MoiseScanner_HashMap.fs_plan.put(variables_for_HashMap.index_fs_plan, new ArrayList<>(Arrays.asList(from_where,"yes",operator,success_rate,index_father)));
                            MoiseScanner_variables.iPlan.add(variables_for_HashMap.index_fs_plan);
                            variables_for_HashMap.index_fs_plan++;
                            operator = "";
                            success_rate = "";
                        }
                        default ->{
                            closed = true;
                            MoiseScanner_methods.MoiseScanner_error("ERROR: plan identifier error", 1);
                        }
                    }
                }
            }
            case "notification-policy" ->{
                boolean boolean_id = false;
                boolean boolean_target = false;
                boolean boolean_condition = false;
                String id = "";
                String target = "";
                String condition = "";
                String index_father =  MoiseScanner_methods.to_String(variables_for_HashMap.index_fs_scheme-1);
                while(!closed){
                    MoiseScanner_methods.goto_new_line(br);
                    switch (MoiseScanner_variables.peek) {
                        case 'i' ->{
                            id = MoiseScanner_identifier.return_identifier(br, "id", "notification-policy");
                            boolean_id = true;
                        }
                        case 't' ->{
                            target = MoiseScanner_identifier.return_identifier(br, "target", "notification-policy");
                            boolean_target = true;
                        }
                        case 'c' ->{
                            condition = MoiseScanner_identifier.return_identifier(br, "condition", "notification-policy");
                            boolean_condition = true;
                        }
                        case '>' ->{
                            identifier.add(boolean_id);
                            identifier.add(boolean_target);
                            identifier.add(boolean_condition);
                            boolean_id = false;
                            boolean_target = false;
                            boolean_condition = false;
                            closed = true;
                            MoiseScanner_tag.simpleCloseTag(br);
                            MoiseScanner_identifier_checker.checker(identifier);
                            MoiseScanner_HashMap.fs_notification_policy.put(variables_for_HashMap.index_fs_notification_policy, new ArrayList<>(Arrays.asList(from_where,"yes",id,target,condition,index_father)));
                            variables_for_HashMap.index_fs_notification_policy++;
                            id = "";
                            target = "";
                            condition = "";
                        }
                        default ->{
                            closed = true;
                            MoiseScanner_methods.MoiseScanner_error("ERROR: notification-policy identifier error", 1);
                        }
                    }
                }
            }
            case "accountability-agreement" ->{
                boolean boolean_id = false;
                String id = "";
                String index_father =  MoiseScanner_methods.to_String(variables_for_HashMap.index_fs_scheme-1);
                while(!closed){
                    MoiseScanner_methods.goto_new_line(br);
                    switch (MoiseScanner_variables.peek) {
                        case 'i' ->{
                            id = MoiseScanner_identifier.return_identifier(br, "id", "accountability-agreement");
                            boolean_id = true;
                        }
                        case '>' ->{
                            identifier.add(boolean_id);
                            boolean_id = false;
                            closed = true;
                            MoiseScanner_tag.simpleCloseTag(br);
                            MoiseScanner_identifier_checker.checker(identifier);
                            MoiseScanner_HashMap.fs_accountability_agreement.put(variables_for_HashMap.index_fs_accountability_agreement, new ArrayList<>(Arrays.asList(from_where,"yes",id,index_father)));
                            variables_for_HashMap.index_fs_accountability_agreement++;
                            id = "";
                        }
                        default ->{
                            closed = true;
                            MoiseScanner_methods.MoiseScanner_error("ERROR: notification-policy identifier error", 1);
                        }
                    }
                }
            }
            case "exception-argument" ->{
                MoiseScanner_variables.cycle = true;
                boolean boolean_id = false;
                boolean boolean_arity = false;
                String id = "";
                String arity = "";
                String index_father = MoiseScanner_methods.to_String(variables_for_HashMap.index_fs_exception_specification-1);
                while(MoiseScanner_variables.cycle&&!closed){
                    MoiseScanner_methods.goto_new_line(br);
                    switch (MoiseScanner_variables.peek) {
                        case 'i' ->{
                            id = MoiseScanner_identifier.return_identifier(br, "id", "exception-argument");
                            boolean_id = true;
                        }
                        case 'a' ->{
                            arity = MoiseScanner_identifier.return_identifier(br, "arity", "exception-argument");
                            boolean_arity = true;
                        }
                        case '/' ->{
                            identifier.add(boolean_id);
                            identifier.add(boolean_arity);
                            boolean_id = false;
                            boolean_arity = false;
                            MoiseScanner_tag.simpleCloseTag2(br);
                            MoiseScanner_identifier_checker.checker(identifier);
                            MoiseScanner_variables.cycle = MoiseScanner_tag.ComposeTag_peek(br, "exception", "argument");
                            MoiseScanner_HashMap.fs_exception_argument.put(variables_for_HashMap.index_fs_exception_argument, new ArrayList<>(Arrays.asList(from_where,"no",id,arity,index_father)));
                            variables_for_HashMap.index_fs_exception_argument++;
                            id = "";
                            arity = "";
                        }
                        default ->{
                            closed = true;
                            MoiseScanner_methods.MoiseScanner_error("ERROR: exception-argument identifier error", 1);
                        }
                    }
                }
            }
            case "account-argument" ->{
                MoiseScanner_variables.cycle = true;
                boolean boolean_id = false;
                boolean boolean_arity = false;
                String id = "";
                String arity = "";
                String index_father = MoiseScanner_methods.to_String(variables_for_HashMap.index_fs_accountability_agreement-1);
                while(MoiseScanner_variables.cycle&&!closed){
                    MoiseScanner_methods.goto_new_line(br);
                    switch (MoiseScanner_variables.peek) {
                        case 'i' ->{
                            id = MoiseScanner_identifier.return_identifier(br, "id", "account-argument");
                            boolean_id = true;
                        }
                        case 'a' ->{
                            arity = MoiseScanner_identifier.return_identifier(br, "arity", "account-argument");
                            boolean_arity = true;
                        }
                        case '/' ->{
                            identifier.add(boolean_id);
                            identifier.add(boolean_arity);
                            boolean_id = false;
                            boolean_arity = false;
                            MoiseScanner_tag.simpleCloseTag2(br);
                            MoiseScanner_identifier_checker.checker(identifier);
                            MoiseScanner_variables.cycle = MoiseScanner_tag.ComposeTag_peek(br, "account", "argument");
                            MoiseScanner_HashMap.fs_account_argument.put(variables_for_HashMap.index_fs_account_argument, new ArrayList<>(Arrays.asList(from_where,"no",id,arity,index_father)));
                            variables_for_HashMap.index_fs_account_argument++;
                            id = "";
                            arity = "";
                        }
                        default ->{
                            closed = true;
                            MoiseScanner_methods.MoiseScanner_error("ERROR: exception-argument identifier error", 1);
                        }
                    }
                }
            }
            case "condition-argument" ->{
                MoiseScanner_variables.cycle = true;
                boolean boolean_id = false;
                boolean boolean_value = false;
                String id = "";
                String value = "";
                String index_father = MoiseScanner_methods.to_String(variables_for_HashMap.index_fs_accountability_agreement-1);
                while(MoiseScanner_variables.cycle&&!closed){
                    MoiseScanner_methods.goto_new_line(br);
                    switch (MoiseScanner_variables.peek) {
                        case 'i' ->{
                            id = MoiseScanner_identifier.return_identifier(br, "id", "condition-argument");
                            boolean_id = true;
                        }
                        case 'v' ->{
                            value = MoiseScanner_identifier.return_identifier(br, "value", "condition-argument");
                            boolean_value = true;
                        }
                        case '/' ->{
                            identifier.add(boolean_id);
                            identifier.add(boolean_value);
                            boolean_id = false;
                            boolean_value = false;
                            MoiseScanner_tag.simpleCloseTag2(br);
                            MoiseScanner_identifier_checker.checker(identifier);
                            MoiseScanner_variables.cycle = MoiseScanner_tag.ComposeTag_peek(br, "condition", "argument");
                            MoiseScanner_HashMap.fs_condition_argument.put(variables_for_HashMap.index_fs_condition_argument, new ArrayList<>(Arrays.asList(from_where,"no",id,value,index_father)));
                            variables_for_HashMap.index_fs_condition_argument++;
                            id = "";
                            value = "";
                        }
                        default ->{
                            closed = true;
                            MoiseScanner_methods.MoiseScanner_error("ERROR: condition-argument identifier error", 1);
                        }
                    }
                }
            }
            case "raising_goal" ->{
                MoiseScanner_variables.cycle = true;
                boolean boolean_id = false;
                String id = "";
                String min = "";
                String ds = "";
                String type = "";
                String ttf = "";
                String location = "";
                String when = "";
                String index_father = MoiseScanner_methods.to_String(variables_for_HashMap.index_fs_exception_specification-1);
                while(!closed){
                    MoiseScanner_methods.goto_new_line(br);
                    switch(MoiseScanner_variables.peek){
                        case 'i' ->{
                            id = MoiseScanner_identifier.return_identifier(br, "id", "raising-goal");
                            boolean_id = true;
                        }
                        case 't' ->{
                            if(Character.isLetter(MoiseScanner_variables.peek)){
                                String s1 = MoiseScanner_methods.attach_character(br);
                                if(s1.equals("ttf")){
                                    ttf = MoiseScanner_identifier.return_identifier2(br, "ttf", "raising-goal");
                                }else if(s1.equals("type")){
                                    type = MoiseScanner_identifier.return_identifier2(br, "type", "raising-goal");
                                }else{
                                    MoiseScanner_methods.MoiseScanner_error("ERROR: unknown identifier", 1);
                                }
                            }
                        }
                        case 'm' -> min = MoiseScanner_identifier.return_identifier(br, "min", "raising-goal");
                        case 'd' -> ds = MoiseScanner_identifier.return_identifier(br, "ds", "raising-goal");
                        case 'l' -> location = MoiseScanner_identifier.return_identifier(br, "location", "raising-goal");
                        case 'w' -> when = MoiseScanner_identifier.return_identifier(br, "when", "raising-goal");
                        case '/' ->{
                            identifier.add(boolean_id);
                            boolean_id = false;
                            MoiseScanner_tag.simpleCloseTag2(br);
                            MoiseScanner_identifier_checker.checker(identifier);
                            if(!MoiseScanner_variables.from_scheme){//false
                                MoiseScanner_variables.cycle = MoiseScanner_tag.Tag_peek(br, "goal");
                            }else{
                                MoiseScanner_variables.cycle = false;
                            }
                            MoiseScanner_HashMap.fs_raising_goal.put(variables_for_HashMap.index_fs_raising_goal, new ArrayList<>(Arrays.asList(from_where,"no",id,min,ds,type,ttf,location,when,index_father)));
                            variables_for_HashMap.index_fs_raising_goal++;
                            id = "";
                            min = "";
                            ds = "";
                            type = "";
                            ttf = "";
                            location = "";
                            when = "";
                            closed=true;
                        }
                        case '>' ->{
                            identifier.add(boolean_id);
                            boolean_id = false;
                            MoiseScanner_variables.flag_noPlan = true;
                            MoiseScanner_tag.simpleCloseTag(br);
                            MoiseScanner_identifier_checker.checker(identifier);
                            if(!MoiseScanner_variables.from_scheme){//false
                                MoiseScanner_variables.cycle = MoiseScanner_tag.Tag_peek(br, "goal");
                            }else{
                                MoiseScanner_variables.cycle = false;
                            }
                            MoiseScanner_HashMap.fs_raising_goal.put(variables_for_HashMap.index_fs_raising_goal, new ArrayList<>(Arrays.asList(from_where,"yes",id,min,ds,type,ttf,location,when,index_father)));
                            variables_for_HashMap.index_fs_raising_goal++;
                            id = "";
                            min = "";
                            ds = "";
                            type = "";
                            ttf = "";
                            location = "";
                            when = "";
                            closed=true;
                        }
                        default ->{
                            closed = true;
                            MoiseScanner_methods.MoiseScanner_error("ERROR: raising_goal identifier error", 1);
                        }
                    }
                }
            }
            case "handling-goal" ->{
                MoiseScanner_variables.cycle = true;
                boolean boolean_id = false;
                String id = "";
                String min = "";
                String ds = "";
                String type = "";
                String ttf = "";
                String location = "";
                String when = "";
                String index_father = MoiseScanner_methods.to_String(variables_for_HashMap.index_fs_exception_specification-1);
                while(!closed){
                    MoiseScanner_methods.goto_new_line(br);
                    switch(MoiseScanner_variables.peek){
                        case 'i' ->{
                            id = MoiseScanner_identifier.return_identifier(br, "id", "handling-goal");
                            boolean_id = true;
                        }
                        case 't' ->{
                            if(Character.isLetter(MoiseScanner_variables.peek)){
                                String s1 = MoiseScanner_methods.attach_character(br);
                                if(s1.equals("ttf")){
                                    ttf = MoiseScanner_identifier.return_identifier2(br, "ttf", "handling-goal");
                                }else if(s1.equals("type")){
                                    type = MoiseScanner_identifier.return_identifier2(br, "type", "handling-goal");
                                }else{
                                    MoiseScanner_methods.MoiseScanner_error("ERROR: unknown identifier", 1);
                                }
                            }
                        }
                        case 'm' -> min = MoiseScanner_identifier.return_identifier(br, "min", "handling-goal");
                        case 'd' -> ds = MoiseScanner_identifier.return_identifier(br, "ds", "handling-goal");
                        case 'l' -> location = MoiseScanner_identifier.return_identifier(br, "location", "handling-goal");
                        case 'w' -> when = MoiseScanner_identifier.return_identifier(br, "when", "handling-goal");
                        case '/' ->{
                            identifier.add(boolean_id);
                            boolean_id = false;
                            MoiseScanner_tag.simpleCloseTag2(br);
                            MoiseScanner_identifier_checker.checker(identifier);
                            if(!MoiseScanner_variables.from_scheme){
                                MoiseScanner_variables.cycle = MoiseScanner_tag.Tag_peek(br, "goal");
                            }else{
                                MoiseScanner_variables.cycle = false;
                            }
                            MoiseScanner_HashMap.fs_handling_goal.put(variables_for_HashMap.index_fs_handling_goal, new ArrayList<>(Arrays.asList(from_where,"no",id,min,ds,type,ttf,location,when,index_father)));
                            variables_for_HashMap.index_fs_handling_goal++;
                            id = "";
                            min = "";
                            ds = "";
                            type = "";
                            ttf = "";
                            location = "";
                            when = "";
                            closed=true;
                        }
                        case '>' ->{
                            identifier.add(boolean_id);
                            boolean_id = false;
                            MoiseScanner_variables.flag_noPlan = true;
                            MoiseScanner_tag.simpleCloseTag(br);
                            MoiseScanner_identifier_checker.checker(identifier);
                            if(!MoiseScanner_variables.from_scheme){//false
                                MoiseScanner_variables.cycle = MoiseScanner_tag.Tag_peek(br, "goal");
                            }else{
                                MoiseScanner_variables.cycle = false;
                            }
                            MoiseScanner_HashMap.fs_handling_goal.put(variables_for_HashMap.index_fs_handling_goal, new ArrayList<>(Arrays.asList(from_where,"yes",id,min,ds,type,ttf,location,when,index_father)));
                            variables_for_HashMap.index_fs_handling_goal++;
                            id = "";
                            min = "";
                            ds = "";
                            type = "";
                            ttf = "";
                            location = "";
                            when = "";
                            closed=true;
                        }
                        default ->{
                            closed = true;
                            MoiseScanner_methods.MoiseScanner_error("ERROR: raising_goal identifier error", 1);
                        }
                    }
                }
            }
            case "mission" ->{
                boolean boolean_id = false;
                String id = "";
                String min = "";
                String max = "";
                String index_father =  MoiseScanner_methods.to_String(variables_for_HashMap.index_fs_scheme-1);
                while(!closed){
                    MoiseScanner_methods.goto_new_line(br);
                    switch (MoiseScanner_variables.peek) {
                        case 'i' ->{
                            id = MoiseScanner_identifier.return_identifier(br, "id", "mission");
                            boolean_id = true;
                        }
                        case 'm' ->{
                            if(Character.isLetter(MoiseScanner_variables.peek)){
                                String s1 = MoiseScanner_methods.attach_character(br);
                                if(s1.equals("min")){
                                    min = MoiseScanner_identifier.return_identifier2(br, "min", "mission");
                                }else if(s1.equals("max")){
                                    max = MoiseScanner_identifier.return_identifier2(br, "max", "mission");
                                }else{
                                    MoiseScanner_methods.MoiseScanner_error("ERROR: unknown identifier", 1);
                                }
                            }
                        }
                        case '>' ->{
                            identifier.add(boolean_id);
                            boolean_id = false;
                            closed = true;
                            MoiseScanner_tag.simpleCloseTag(br);
                            MoiseScanner_identifier_checker.checker(identifier);
                            MoiseScanner_HashMap.fs_mission.put(variables_for_HashMap.index_fs_mission, new ArrayList<>(Arrays.asList(from_where,"yes",id,min,max,index_father)));
                            variables_for_HashMap.index_fs_mission++;
                            id = "";
                            min = "";
                            max = "";
                        }
                        default ->{
                            closed = true;
                            MoiseScanner_methods.MoiseScanner_error("ERROR: mission identifier error", 1);
                        }
                    }
                }
            }
            case "norm" ->{
                boolean boolean_id = false;
                boolean boolean_role = false;
                boolean boolean_type = false;
                boolean boolean_mission = false;
                String id = "";
                String condition = "";
                String role = "";
                String type = "";
                String mission = "";
                String time_constraint = "";
                MoiseScanner_variables.cycle = true;
                while(MoiseScanner_variables.cycle&&!closed){
                    MoiseScanner_methods.goto_new_line(br);
                    switch (MoiseScanner_variables.peek) {
                        case 'i' ->{
                            id = MoiseScanner_identifier.return_identifier(br, "id", "norm");
                            boolean_id = true;
                        }
                        case 'c' -> condition = MoiseScanner_identifier.return_identifier(br, "condition", "norm");
                        case 'r' ->{
                            role = MoiseScanner_identifier.return_identifier(br, "role", "norm");
                            boolean_role = true;
                        }
                        case 't' ->{
                            if(Character.isLetter(MoiseScanner_variables.peek)){
                                String s1 = MoiseScanner_methods.attach_character(br);
                                if(s1.equals("type")){
                                    type = MoiseScanner_identifier.return_identifier2(br, "type", "norm");
                                    boolean_type=true;
                                }else if(s1.equals("time")){
                                    time_constraint = MoiseScanner_identifier.return_ComposeIdentifier2(br, "time", "constraint","norm");
                                }else{
                                    MoiseScanner_methods.MoiseScanner_error("ERROR: unknown identifier", 1);
                                }
                            }
                        }
                        case 'm' ->{
                            mission = MoiseScanner_identifier.return_identifier(br, "mission", "norm");
                            boolean_mission = true;
                        }
                        case '/' ->{
                            identifier.add(boolean_id);
                            identifier.add(boolean_role);
                            identifier.add(boolean_type);
                            identifier.add(boolean_mission);
                            boolean_id = false;
                            boolean_role = false;
                            boolean_type = false;
                            boolean_mission = false;
                            MoiseScanner_tag.simpleCloseTag2(br);
                            MoiseScanner_identifier_checker.checker(identifier);
                            MoiseScanner_variables.cycle = MoiseScanner_tag.Tag_peek(br, "norm");
                            MoiseScanner_HashMap.ns_norm.put(variables_for_HashMap.index_ns_norm, new ArrayList<>(Arrays.asList("normative-specification","no",id,condition,role,type,mission,time_constraint)));
                            variables_for_HashMap.index_ns_norm++;
                            id = "";
                            condition = "";
                            role = "";
                            type = "";
                            mission = "";
                            time_constraint = "";
                        }
                        default ->{
                            closed = true;
                            MoiseScanner_methods.MoiseScanner_error("ERROR: norm identifier error", 1);
                        }
                    }
                }
            }
            default -> MoiseScanner_methods.MoiseScanner_error("ERROR: unknown identifier case", 1);
        }
    }

}
