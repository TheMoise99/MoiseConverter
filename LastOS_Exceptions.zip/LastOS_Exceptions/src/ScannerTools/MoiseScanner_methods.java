package ScannerTools;

import javax.imageio.stream.ImageOutputStreamImpl;
import java.io.BufferedReader;
import java.io.IOException;

public class MoiseScanner_methods {

    public static final String RESET = "\u001B[0m";
    public static final String BLUE = "\u001B[34m";

    public static void readch(BufferedReader br){
        try{
            MoiseScanner_variables.peek = (char) br.read();
        }catch(IOException exc){
            MoiseScanner_variables.peek = (char) -1;
        }
    }

    public static String attach_character(BufferedReader br){
        StringBuilder s = new StringBuilder();
        do{
            s.append(MoiseScanner_variables.peek);
            readch(br);
        }
        while(Character.isLetter(MoiseScanner_variables.peek));
        return s.toString();
    }

    public static void goto_new_line(BufferedReader br){
        while(MoiseScanner_variables.peek == ' ' || MoiseScanner_variables.peek == '\t' || MoiseScanner_variables.peek == '\n'  || MoiseScanner_variables.peek == '\r'){
            if(MoiseScanner_variables.peek == '\n') MoiseScanner_variables.line++;
            readch(br);
        }
    }

    public static String removeLastChar(String s){
        return s.substring(0, s.length()-1);
    }

    public static String to_String(int to_convert){
        return String.valueOf(to_convert);
    }

    public static void MoiseScanner_error(String s,int error_case){
        MoiseScanner_variables.stop = true;
        if(error_case==1) {
            System.out.println("ERROR STRUCTURAL-SPECIFICATION");
            if(s!=null){
                System.err.println("UNKNOWN STRING: " + s);
            }
            if(s==null){
                System.err.println("ERRONEOUS CHARACTER: " + MoiseScanner_variables.peek);
            }
        }
    }

    public static boolean isNumber(String s) {
        try{
            if(s.startsWith("-")){
                return false;
            }
            Integer.parseInt(s);
        }catch(NumberFormatException | NullPointerException e){
            return false;
        }
        return true;
    }

    public static boolean isDouble(String s) {
        try{
            Double.parseDouble(s);
        }
        catch(NumberFormatException | NullPointerException e){
            return false;
        }
        return true;
    }

    public static void test2(){
        System.out.println("-----------------------------------------HASHMAP TEST-----------------------------------------\n");
        System.out.println("-------------------PROPERTY-------------------");
        for(int i=0;i<variables_for_HashMap.index_property;i++){
            System.out.println(BLUE + "PROPERTY with index: " + RESET + i + BLUE + " contained: " + RESET + MoiseScanner_HashMap.property.get(i).get(0) +
                    BLUE + " Has_son: " + RESET + MoiseScanner_HashMap.property.get(i).get(1) + BLUE + " id: " + RESET + MoiseScanner_HashMap.property.get(i).get(2) +
                    BLUE +" value: " + RESET + MoiseScanner_HashMap.property.get(i).get(3) + BLUE + " father_index: " + RESET + MoiseScanner_HashMap.property.get(i).get(4));
        }
        System.out.println("-------------------PROPERTY-------------------\n");
        System.out.println("-------------------ROLE-DEFINITIONS ROLE-------------------");
        for(int i=0;i<variables_for_HashMap.index_role;i++){
            System.out.println(BLUE + "ROLE with index: " + RESET + i + BLUE + " Son_of: "+ RESET + MoiseScanner_HashMap.role.get(i).get(0) +
                    BLUE + " Has_son: " + RESET + MoiseScanner_HashMap.role.get(i).get(1) + BLUE + " id: " + RESET + MoiseScanner_HashMap.role.get(i).get(2));
        }
        System.out.println("-------------------ROLE-DEFINITIONS ROLE-------------------\n");
        System.out.println("-------------------EXTENDS-------------------");
        for(int i=0;i<variables_for_HashMap.index_role_extends;i++){
            System.out.println(BLUE + "EXTENDS with index: " + RESET + i + BLUE + " Son_of: " + RESET + MoiseScanner_HashMap.role_extends.get(i).get(0) +
                    BLUE + " Has_son: " + RESET + MoiseScanner_HashMap.role_extends.get(i).get(1) + BLUE + " extends: "+ RESET + MoiseScanner_HashMap.role_extends.get(i).get(2)
                    + BLUE + " father_index: " + RESET + MoiseScanner_HashMap.role_extends.get(i).get(3));
        }
        System.out.println("-------------------EXTENDS-------------------\n");
        System.out.println("-------------------LINK-TYPE-------------------");
        for(int i=0;i<variables_for_HashMap.index_link_type;i++){
            System.out.println(BLUE + "LINK-TYPE with index: " + RESET + i + BLUE + " Son_of: " + RESET + MoiseScanner_HashMap.link_type.get(i).get(0) +
                    BLUE + " Has_son: " + RESET + MoiseScanner_HashMap.link_type.get(i).get(1) + BLUE + " id: " + RESET + MoiseScanner_HashMap.link_type.get(i).get(2));
        }
        System.out.println("-------------------LINK-TYPE-------------------\n");
        System.out.println("-------------------GROUP-SPECIFICATION-------------------");
        for(int i=0;i<variables_for_HashMap.index_group_specification;i++){
            System.out.println(BLUE  + "GROUP-SPECIFICATION with index: " + RESET + i + BLUE + " Son_of: " + RESET + MoiseScanner_HashMap.group_specification.get(i).get(0) +
                    BLUE + " Has_son: " + RESET + MoiseScanner_HashMap.group_specification.get(i).get(1) + BLUE + " id: " + RESET + MoiseScanner_HashMap.group_specification.get(i).get(2)
                    + BLUE + " min: " + RESET + MoiseScanner_HashMap.group_specification.get(i).get(3) + BLUE + " max: " + RESET + MoiseScanner_HashMap.group_specification.get(i).get(4)
                    + BLUE + " father_index: " + RESET + MoiseScanner_HashMap.group_specification.get(i).get(5) + BLUE + " part_of subgroups: " + RESET + MoiseScanner_HashMap.group_specification.get(i).get(6));
        }
        System.out.println("-------------------GROUP-SPECIFICATION-------------------\n");
        System.out.println("-------------------ROLES-ROLE-------------------");
        for(int i=0;i<variables_for_HashMap.index_roles_role;i++){
            System.out.println(BLUE + "ROLES-ROLE with index: "+ RESET + i + BLUE + " Son_of: " + RESET + MoiseScanner_HashMap.roles_role.get(i).get(0) +
                    BLUE + " Has_son: " + RESET + MoiseScanner_HashMap.roles_role.get(i).get(1) + BLUE + " id: " + RESET + MoiseScanner_HashMap.roles_role.get(i).get(2) +
                    BLUE + " min: " + RESET + MoiseScanner_HashMap.roles_role.get(i).get(3) + BLUE + " max: " + RESET + MoiseScanner_HashMap.roles_role.get(i).get(4)
                    + BLUE + " father_index: " + RESET + MoiseScanner_HashMap.roles_role.get(i).get(5));
        }
        System.out.println("-------------------ROLES-ROLE-------------------\n");
        System.out.println("-------------------LINK-------------------");
        for(int i=0;i<variables_for_HashMap.index_link;i++){
            System.out.println(BLUE + "LINK with index: " + RESET + i + BLUE + " Son_of: " + RESET + MoiseScanner_HashMap.link.get(i).get(0) +
                    BLUE + " Has_son: " + RESET + MoiseScanner_HashMap.link.get(i).get(1) + BLUE + " from: " + RESET + MoiseScanner_HashMap.link.get(i).get(2)
                    + BLUE + " to: " + RESET + MoiseScanner_HashMap.link.get(i).get(3) + BLUE + " type: " + RESET + MoiseScanner_HashMap.link.get(i).get(4)
                    + BLUE +  " scope: " + RESET + MoiseScanner_HashMap.link.get(i).get(5) + BLUE +  " extends-subgroups: " + RESET + MoiseScanner_HashMap.link.get(i).get(6)
                    + BLUE + " bi-dir: " + RESET + MoiseScanner_HashMap.link.get(i).get(7) + BLUE + " father_index: " + RESET + MoiseScanner_HashMap.link.get(i).get(8));
        }
        System.out.println("-------------------LINK-------------------\n");
        System.out.println("-------------------URI-------------------");
        for(int i=0;i<variables_for_HashMap.index_include_group_specification;i++){
            System.out.println(BLUE + "URI with index: " + RESET + i + BLUE + " Son_of: " + RESET + MoiseScanner_HashMap.include_group_specification.get(i).get(0) +
                    BLUE + " Has_son: " + RESET + MoiseScanner_HashMap.include_group_specification.get(i).get(1) + BLUE + " uri: " + RESET + MoiseScanner_HashMap.include_group_specification.get(i).get(2)
                    + BLUE + " father_index: " + RESET + MoiseScanner_HashMap.include_group_specification.get(i).get(3) + BLUE + " part_of subgroups: " + RESET + MoiseScanner_HashMap.include_group_specification.get(i).get(4));
        }
        System.out.println("-------------------URI-------------------\n");
        System.out.println("-------------------CARDINALITY-------------------");
        for(int i=0;i<variables_for_HashMap.index_cardinality;i++){
            System.out.println(BLUE + "CARDINALITY with index: " + RESET + i + BLUE +" Son_of: " + RESET + MoiseScanner_HashMap.cardinality.get(i).get(0) +
                    BLUE + " Has_son: " + RESET + MoiseScanner_HashMap.cardinality.get(i).get(1) + BLUE + " min: " + RESET + MoiseScanner_HashMap.cardinality.get(i).get(2)
                    + BLUE + " max: " + RESET + MoiseScanner_HashMap.cardinality.get(i).get(3) + BLUE + " object: " + RESET + MoiseScanner_HashMap.cardinality.get(i).get(4)
                    + BLUE + " id: " + RESET + MoiseScanner_HashMap.cardinality.get(i).get(5) + BLUE + " father_index: " + RESET + MoiseScanner_HashMap.cardinality.get(i).get(6));
        }
        System.out.println("-------------------CARDINALITY-------------------\n");
        System.out.println("-------------------COMPATIBILITY-------------------");
        for(int i=0;i<variables_for_HashMap.index_compatibility;i++){
            System.out.println(BLUE + "COMPATIBILITY with index: " + RESET + i + BLUE + " Son_of: " + RESET + MoiseScanner_HashMap.compatibility.get(i).get(0) +
                    BLUE +" Has_son: " + RESET + MoiseScanner_HashMap.compatibility.get(i).get(1) + BLUE + " from: " + RESET + MoiseScanner_HashMap.compatibility.get(i).get(2)
                    + BLUE + " to: " + RESET + MoiseScanner_HashMap.compatibility.get(i).get(3) + BLUE + " type: " + RESET + MoiseScanner_HashMap.compatibility.get(i).get(4)
                    + BLUE + " scope: " + RESET + MoiseScanner_HashMap.compatibility.get(i).get(5) + BLUE + " extends-subgroups: " + RESET + MoiseScanner_HashMap.compatibility.get(i).get(6)
                    + BLUE + " bi_dir: " + RESET + MoiseScanner_HashMap.compatibility.get(i).get(7) + BLUE + " father_index: " + RESET + MoiseScanner_HashMap.compatibility.get(i).get(8));
        }
        System.out.println("-------------------COMPATIBILITY-------------------\n");
        System.out.println("-------------------SCHEME-------------------");
        for(int i=0;i<variables_for_HashMap.index_fs_scheme;i++){
            System.out.println(BLUE + "SCHEME with index: " + RESET + i + BLUE + " Son_of: " + RESET + MoiseScanner_HashMap.fs_scheme.get(i).get(0) +
                    BLUE + " Has_son: " + RESET + MoiseScanner_HashMap.fs_scheme.get(i).get(1) + BLUE + " id: " + RESET + MoiseScanner_HashMap.fs_scheme.get(i).get(2));
        }
        System.out.println("-------------------SCHEME-------------------\n");
        System.out.println("-------------------GOAL-------------------");
        for(int i=0;i<variables_for_HashMap.index_fs_goal;i++){
            System.out.println(BLUE + "GOAL with index: " + RESET + i + BLUE + " Son_of: " + RESET + MoiseScanner_HashMap.fs_goal.get(i).get(0) +
                    BLUE + " Has_son: " + RESET + MoiseScanner_HashMap.fs_goal.get(i).get(1) +  BLUE + " id: " + RESET + MoiseScanner_HashMap.fs_goal.get(i).get(2)
                    + BLUE + " min: " + RESET + MoiseScanner_HashMap.fs_goal.get(i).get(3) + BLUE + " ds: " + RESET + MoiseScanner_HashMap.fs_goal.get(i).get(4)
                    + BLUE + " type: " + RESET + MoiseScanner_HashMap.fs_goal.get(i).get(5) + BLUE + " ttf: " + RESET + MoiseScanner_HashMap.fs_goal.get(i).get(6)
                    + BLUE + " location: " + RESET + MoiseScanner_HashMap.fs_goal.get(i).get(7) + BLUE + " father_index: " + RESET + MoiseScanner_HashMap.fs_goal.get(i).get(8)
                    + BLUE + " atype: " + RESET + MoiseScanner_HashMap.fs_goal.get(i).get(9) + BLUE + " when: " + RESET + MoiseScanner_HashMap.fs_goal.get(i).get(10));
        }
        System.out.println("-------------------GOAL-------------------\n");
        System.out.println("-------------------ARGUMENT-------------------");
        for(int i=0;i<variables_for_HashMap.index_fs_argument;i++){
            System.out.println(BLUE + "ARGUMENT with index: " + RESET + i + BLUE + " Son_of: " + RESET + MoiseScanner_HashMap.fs_argument.get(i).get(0) +
                    BLUE + " Has_son: " + RESET + MoiseScanner_HashMap.fs_argument.get(i).get(1) + BLUE + " id: " + RESET + MoiseScanner_HashMap.fs_argument.get(i).get(2)
                    + BLUE + " value: " + RESET + MoiseScanner_HashMap.fs_argument.get(i).get(3) + BLUE + " father_index: " + RESET + MoiseScanner_HashMap.fs_argument.get(i).get(4));
        }
        System.out.println("-------------------ARGUMENT-------------------\n");
        System.out.println("-------------------DEPENDS-ON-------------------");
        for(int i=0;i<variables_for_HashMap.index_fs_depends_on;i++){
            System.out.println(BLUE + "DEPENDS-ON with index: " + RESET + i + BLUE +  " Son_of: " + RESET + MoiseScanner_HashMap.fs_depends_on.get(i).get(0) +
                    BLUE + " Has_son: " + RESET + MoiseScanner_HashMap.fs_depends_on.get(i).get(1) + BLUE + " goal: " + RESET + MoiseScanner_HashMap.fs_depends_on.get(i).get(2)
                    + BLUE + " father_index: " + RESET + MoiseScanner_HashMap.fs_depends_on.get(i).get(3));
        }
        System.out.println("-------------------DEPENDS-ON-------------------\n");
        System.out.println("-------------------PLAN-------------------");
        for(int i=0;i<variables_for_HashMap.index_fs_plan;i++){
            System.out.println(BLUE + "PLAN with index: " + RESET + i + BLUE + " Son_of: " + RESET + MoiseScanner_HashMap.fs_plan.get(i).get(0) +
                    BLUE + " Has_son: " +  RESET + MoiseScanner_HashMap.fs_plan.get(i).get(1) + BLUE +" operator: " + RESET + MoiseScanner_HashMap.fs_plan.get(i).get(2)
                    + BLUE + " success-rate: " + RESET + MoiseScanner_HashMap.fs_plan.get(i).get(3) + BLUE + " father_index: " + RESET + MoiseScanner_HashMap.fs_plan.get(i).get(4));
        }
        System.out.println("-------------------PLAN-------------------\n");
        //acc type
        System.out.println("-------------------ACCOUNTABILITY-AGREEMENT-------------------");
        for(int i=0;i<variables_for_HashMap.index_fs_accountability_agreement;i++){
            System.out.println(BLUE + "ACCOUNTABILITY-AGREEMENT with index: " + RESET + i + BLUE + " Son_of: " + RESET + MoiseScanner_HashMap.fs_accountability_agreement.get(i).get(0) +
                    BLUE + " Has_son: " + RESET + MoiseScanner_HashMap.fs_accountability_agreement.get(i).get(1) + BLUE + " id: " + RESET + MoiseScanner_HashMap.fs_accountability_agreement.get(i).get(2) +
                    BLUE + " father_index: " + RESET + MoiseScanner_HashMap.fs_accountability_agreement.get(i).get(3));
        }
        System.out.println("-------------------ACCOUNTABILITY-AGREEMENT-------------------\n");
        System.out.println("-------------------TARGET-------------------");
        for(int i=0;i<variables_for_HashMap.index_fs_target;i++){
            System.out.println(BLUE + "TARGET with index: " + RESET + i + BLUE + " Son_of: " + RESET + MoiseScanner_HashMap.fs_target.get(i).get(0) +
                    BLUE + " Has_son: " + RESET + MoiseScanner_HashMap.fs_target.get(i).get(1) + BLUE + " id: " + RESET + MoiseScanner_HashMap.fs_target.get(i).get(2) +
                    BLUE + " father_index: " + RESET + MoiseScanner_HashMap.fs_target.get(i).get(3));
        }
        System.out.println("-------------------TARGET-------------------\n");
        System.out.println("-------------------REQUESTING-CONDITION-------------------");
        for(int i=0;i<variables_for_HashMap.index_fs_requesting_condition;i++){
            System.out.println(BLUE + "REQUESTING-CONDITION with index: " + RESET + i + BLUE + " Son_of: " + RESET + MoiseScanner_HashMap.fs_requesting_condition.get(i).get(0) +
                    BLUE + " Has_son: " + RESET + MoiseScanner_HashMap.fs_requesting_condition.get(i).get(1) + BLUE + " value: " + RESET + MoiseScanner_HashMap.fs_requesting_condition.get(i).get(2) +
                    BLUE + " father_index: " + RESET + MoiseScanner_HashMap.fs_requesting_condition.get(i).get(3));
        }
        System.out.println("-------------------REQUESTING-CONDITION-------------------\n");
        System.out.println("-------------------CONDITION-ARGUMENT-------------------");
        for(int i=0;i<variables_for_HashMap.index_fs_condition_argument;i++){
            System.out.println(BLUE + "CONDITION-ARGUMENT with index: " + RESET + i + BLUE + " Son_of: " + RESET + MoiseScanner_HashMap.fs_condition_argument.get(i).get(0) +
                    BLUE + " Has_son: " + RESET + MoiseScanner_HashMap.fs_condition_argument.get(i).get(1) + BLUE + " id: " + RESET + MoiseScanner_HashMap.fs_condition_argument.get(i).get(2)
                    + BLUE + " value: " + RESET + MoiseScanner_HashMap.fs_condition_argument.get(i).get(3) + BLUE + " father_index: " + RESET + MoiseScanner_HashMap.fs_condition_argument.get(i).get(4));
        }
        System.out.println("-------------------CONDITION-ARGUMENT-------------------\n");
        System.out.println("-------------------ACCOUNT-ARGUMENT-------------------");
        for(int i=0;i<variables_for_HashMap.index_fs_account_argument;i++){
            System.out.println(BLUE + "ACCOUNT-ARGUMENT with index: " + RESET + i + BLUE + " Son_of: " + RESET + MoiseScanner_HashMap.fs_account_argument.get(i).get(0) +
                    BLUE + " Has_son: " + RESET + MoiseScanner_HashMap.fs_account_argument.get(i).get(1) + BLUE + " id: " + RESET + MoiseScanner_HashMap.fs_account_argument.get(i).get(2)
                    + BLUE + " arity: " + RESET + MoiseScanner_HashMap.fs_account_argument.get(i).get(3) + BLUE + " father_index: " + RESET + MoiseScanner_HashMap.fs_account_argument.get(i).get(4));
        }
        System.out.println("-------------------ACCOUNT-ARGUMENT-------------------\n");
        //acc type
        System.out.println("-------------------NOTIFICATION-POLICY-------------------");
        for(int i=0;i<variables_for_HashMap.index_fs_notification_policy;i++){
            System.out.println(BLUE + "NOTIFICATION-POLICY with index: " + RESET + i + BLUE + " Son_of: " + RESET + MoiseScanner_HashMap.fs_notification_policy.get(i).get(0) +
                    BLUE + " Has_son: " + RESET + MoiseScanner_HashMap.fs_notification_policy.get(i).get(1) + BLUE + " id: " + RESET + MoiseScanner_HashMap.fs_notification_policy.get(i).get(2) +
                    BLUE + " target: " + RESET + MoiseScanner_HashMap.fs_notification_policy.get(i).get(3) + BLUE + " condition: " + RESET + MoiseScanner_HashMap.fs_notification_policy.get(i).get(4)
                    + BLUE + " father_index: " + RESET + MoiseScanner_HashMap.fs_notification_policy.get(i).get(5));
        }
        System.out.println("-------------------NOTIFICATION-POLICY-------------------\n");
        System.out.println("-------------------EXCEPTION-SPECIFICATION-------------------");
        for(int i=0;i<variables_for_HashMap.index_fs_exception_specification;i++){
            System.out.println(BLUE + "EXCEPTION-SPECIFICATION with index: " + RESET + i + BLUE + " Son_of: " + RESET + MoiseScanner_HashMap.fs_exception_specification.get(i).get(0) +
                    BLUE + " Has_son: " + RESET + MoiseScanner_HashMap.fs_exception_specification.get(i).get(1) + BLUE +" id: " + RESET + MoiseScanner_HashMap.fs_exception_specification.get(i).get(2)
                    + BLUE + " father_index: " + RESET + MoiseScanner_HashMap.fs_exception_specification.get(i).get(3));
        }
        System.out.println("-------------------EXCEPTION-SPECIFICATION-------------------\n");
        System.out.println("-------------------EXCEPTION-ARGUMENT-------------------");
        for(int i=0;i<variables_for_HashMap.index_fs_exception_argument;i++){
            System.out.println(BLUE + "EXCEPTION-ARGUMENT with index: " + RESET + i + BLUE +" Son_of: " + RESET + MoiseScanner_HashMap.fs_exception_argument.get(i).get(0) +
                    BLUE + " Has_son: " + RESET + MoiseScanner_HashMap.fs_exception_argument.get(i).get(1) + BLUE + " id: " + RESET + MoiseScanner_HashMap.fs_exception_argument.get(i).get(2)
                    + BLUE + " arity: " + RESET + MoiseScanner_HashMap.fs_exception_argument.get(i).get(3) + BLUE + " father_index: " + RESET + MoiseScanner_HashMap.fs_exception_argument.get(i).get(4));
        }
        System.out.println("-------------------EXCEPTION-ARGUMENT-------------------\n");
        System.out.println("-------------------RAISING-GOAL-------------------");
        for(int i=0;i<variables_for_HashMap.index_fs_raising_goal;i++){
            System.out.println(BLUE + "RAISING-GOAL with index: " + RESET + i + BLUE + " Son_of: " + RESET + MoiseScanner_HashMap.fs_raising_goal.get(i).get(0) +
                    BLUE + " Has_son: " + RESET + MoiseScanner_HashMap.fs_raising_goal.get(i).get(1) + BLUE + " id: " + RESET + MoiseScanner_HashMap.fs_raising_goal.get(i).get(2)
                    + BLUE + " min: " + RESET + MoiseScanner_HashMap.fs_raising_goal.get(i).get(3) + BLUE + " ds: " + RESET + MoiseScanner_HashMap.fs_raising_goal.get(i).get(4)
                    + BLUE + " type: " + RESET + MoiseScanner_HashMap.fs_raising_goal.get(i).get(5) + BLUE + " ttf: " + RESET + MoiseScanner_HashMap.fs_raising_goal.get(i).get(6)
                    + BLUE + " location: " + RESET + MoiseScanner_HashMap.fs_raising_goal.get(i).get(7) + BLUE + " when: " + RESET + MoiseScanner_HashMap.fs_raising_goal.get(i).get(8)
                    + BLUE + " father_index: " + RESET + MoiseScanner_HashMap.fs_raising_goal.get(i).get(9));
        }
        System.out.println("-------------------RAISING-GOAL-------------------\n");
        System.out.println("-------------------HANDLING-GOAL-------------------");
        for(int i=0;i<variables_for_HashMap.index_fs_handling_goal;i++){
            System.out.println(BLUE + "HANDLING-GOAL with index: " + RESET + i + BLUE + " Son_of: " + RESET + MoiseScanner_HashMap.fs_handling_goal.get(i).get(0) +
                    BLUE + " Has_son: " + RESET + MoiseScanner_HashMap.fs_handling_goal.get(i).get(1) + BLUE +" id: " + RESET + MoiseScanner_HashMap.fs_handling_goal.get(i).get(2) +
                    BLUE + " min: " + RESET + MoiseScanner_HashMap.fs_handling_goal.get(i).get(3) + BLUE + " ds: " + RESET + MoiseScanner_HashMap.fs_handling_goal.get(i).get(4) +
                    BLUE + " type: " + RESET + MoiseScanner_HashMap.fs_handling_goal.get(i).get(5) + BLUE + " ttf: " + RESET + MoiseScanner_HashMap.fs_handling_goal.get(i).get(6) +
                    BLUE + " location: " + RESET + MoiseScanner_HashMap.fs_handling_goal.get(i).get(7) + BLUE +" when: " + RESET + MoiseScanner_HashMap.fs_handling_goal.get(i).get(8)
                    + BLUE + " father_index: " + RESET + MoiseScanner_HashMap.fs_handling_goal.get(i).get(9));
        }
        System.out.println("-------------------HANDLING-GOAL-------------------\n");
        System.out.println("-------------------MISSION-------------------");
        for(int i=0;i<variables_for_HashMap.index_fs_mission;i++){
            System.out.println(BLUE + "MISSION with index: " + RESET + i + BLUE + " Son_of: " + RESET + MoiseScanner_HashMap.fs_mission.get(i).get(0) +
                    BLUE + " Has_son: " + RESET + MoiseScanner_HashMap.fs_mission.get(i).get(1) + BLUE + " id: " + RESET + MoiseScanner_HashMap.fs_mission.get(i).get(2)
                    + BLUE + " min: " + RESET + MoiseScanner_HashMap.fs_mission.get(i).get(3) + BLUE + " max: " + RESET + MoiseScanner_HashMap.fs_mission.get(i).get(4)
                    + BLUE + " father_index: " + RESET + MoiseScanner_HashMap.fs_mission.get(i).get(5));
        }
        System.out.println("-------------------MISSION-------------------\n");
        System.out.println("-------------------MISSION GOAL-------------------");
        for(int i=0;i<variables_for_HashMap.index_fs_mission_goal;i++){
            System.out.println(BLUE + "MISSION GOAL with index: " + RESET + i + BLUE + " Son_of: "+ RESET + MoiseScanner_HashMap.fs_mission_goal.get(i).get(0) +
                    BLUE + " Has_son: " + RESET + MoiseScanner_HashMap.fs_mission_goal.get(i).get(1) + BLUE + " id: " + RESET
                    + MoiseScanner_HashMap.fs_mission_goal.get(i).get(2) + BLUE + " father_index: " + RESET + MoiseScanner_HashMap.fs_mission_goal.get(i).get(3));
        }
        System.out.println("-------------------MISSION GOAL-------------------\n");
        System.out.println("-------------------PREFERRED-------------------");
        for(int i=0;i<variables_for_HashMap.index_fs_preferred;i++){
            System.out.println(BLUE+"PREFERRED with index: " + RESET + i + BLUE + " Son_of: " + RESET + MoiseScanner_HashMap.fs_preferred.get(i).get(0) + BLUE +
                    " Has_son: " + RESET + MoiseScanner_HashMap.fs_preferred.get(i).get(1) + BLUE + " mission: " + RESET + MoiseScanner_HashMap.fs_preferred.get(i).get(2)
                    + BLUE + " father_index: " + RESET + MoiseScanner_HashMap.fs_preferred.get(i).get(3));
        }
        System.out.println("-------------------PREFERRED-------------------\n");
        System.out.println("-------------------NORM-------------------");
        for(int i=0;i<variables_for_HashMap.index_ns_norm;i++){
            System.out.println(BLUE + "NORM with index: " + RESET + i + BLUE + " Son_of: " + RESET + MoiseScanner_HashMap.ns_norm.get(i).get(0) +
                    BLUE + " Has_son: " + RESET + MoiseScanner_HashMap.ns_norm.get(i).get(1) + BLUE + " id: " + RESET + MoiseScanner_HashMap.ns_norm.get(i).get(2) +
                    BLUE + " condition: " + RESET + MoiseScanner_HashMap.ns_norm.get(i).get(3) + BLUE + " role: " + RESET + MoiseScanner_HashMap.ns_norm.get(i).get(4)
                    + BLUE + " type: " + RESET + MoiseScanner_HashMap.ns_norm.get(i).get(5) + BLUE + " mission: " + RESET + MoiseScanner_HashMap.ns_norm.get(i).get(6)
                    + BLUE + " time-constraint: " + RESET + MoiseScanner_HashMap.ns_norm.get(i).get(7));
        }
        System.out.println("-------------------NORM-------------------\n");

        System.out.println("peaky blunders: " + MoiseScanner_variables.peek);
    }

}
