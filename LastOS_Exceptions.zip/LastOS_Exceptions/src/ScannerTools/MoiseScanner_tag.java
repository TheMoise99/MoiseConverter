package ScannerTools;

import java.io.BufferedReader;

public class MoiseScanner_tag{

    public static void closeComposedTag(BufferedReader br, String s1, String s2){
        if(!MoiseScanner_variables.stop){
            if(MoiseScanner_variables.peek == '<'){
                MoiseScanner_methods.readch(br);
                if(MoiseScanner_variables.peek == '/'){
                    MoiseScanner_methods.readch(br);
                    if(Character.isLetter(MoiseScanner_variables.peek)){
                        String s3 = MoiseScanner_methods.attach_character(br);
                        if(s1.equals(s3)){
                            if(MoiseScanner_variables.peek == '-'){
                                MoiseScanner_methods.readch(br);
                                if(Character.isLetter(MoiseScanner_variables.peek)){
                                    String s4 = MoiseScanner_methods.attach_character(br);
                                    if(s2.equals(s4)){
                                        if(MoiseScanner_variables.peek == '>'){
                                            MoiseScanner_methods.readch(br);
                                            MoiseScanner_methods.goto_new_line(br);
                                        }else{
                                            MoiseScanner_methods.MoiseScanner_error(null,1);
                                        }
                                    }else{
                                        MoiseScanner_methods.MoiseScanner_error(s4,1);
                                    }
                                }else{
                                    MoiseScanner_methods.MoiseScanner_error(null,1);
                                }
                            }else{
                                MoiseScanner_methods.MoiseScanner_error(null,1);
                            }
                        }else{
                            MoiseScanner_methods.MoiseScanner_error(s3,1);
                        }
                    }else{
                        MoiseScanner_methods.MoiseScanner_error(null,1);
                    }
                }else{
                    MoiseScanner_methods.MoiseScanner_error(null,1);
                }
            }else{
                MoiseScanner_methods.MoiseScanner_error(null,1);
            }
        }
    }

    public static void composedTagNC(BufferedReader br, String s1, String s2){
        if(!MoiseScanner_variables.stop){
            if(MoiseScanner_variables.peek == '<'){
                MoiseScanner_methods.readch(br);
                if(Character.isLetter(MoiseScanner_variables.peek)){
                    String s3 = MoiseScanner_methods.attach_character(br);
                    if(s1.equals(s3)){
                        if(MoiseScanner_variables.peek == '-'){
                            MoiseScanner_methods.readch(br);
                            if(Character.isLetter(MoiseScanner_variables.peek)){
                                String s4 = MoiseScanner_methods.attach_character(br);
                                if(s2.equals(s4)){
                                    MoiseScanner_methods.readch(br);
                                    MoiseScanner_methods.goto_new_line(br);
                                }else{
                                    MoiseScanner_methods.MoiseScanner_error(s4, 1);
                                }
                            }else{
                                MoiseScanner_methods.MoiseScanner_error(null, 1);
                            }
                        }else{
                            MoiseScanner_methods.MoiseScanner_error(null, 1);
                        }
                    }else{
                        MoiseScanner_methods.MoiseScanner_error(s3, 1);
                    }
                }else{
                    MoiseScanner_methods.MoiseScanner_error(null, 1);
                }
            }else{
                MoiseScanner_methods.MoiseScanner_error(null, 1);
            }
        }
    }

    public static boolean composedTagNC2(BufferedReader br, String s1, String s2,String s3){
        if(!MoiseScanner_variables.stop){
            if(MoiseScanner_variables.peek == '<'){
                MoiseScanner_methods.readch(br);
                if(Character.isLetter(MoiseScanner_variables.peek)){
                    String s4 = MoiseScanner_methods.attach_character(br);
                    if(s1.equals(s4)){
                        if(MoiseScanner_variables.peek == '-'){
                            MoiseScanner_methods.readch(br);
                            if(Character.isLetter(MoiseScanner_variables.peek)){
                                String s5 = MoiseScanner_methods.attach_character(br);
                                if(s2.equals(s5)){
                                    if(MoiseScanner_variables.peek == '-'){
                                        MoiseScanner_methods.readch(br);
                                        if(Character.isLetter(MoiseScanner_variables.peek)) {
                                            String s6 = MoiseScanner_methods.attach_character(br);
                                            if(s3.equals(s6)){
                                                MoiseScanner_methods.readch(br);
                                                MoiseScanner_methods.goto_new_line(br);
                                                return true;
                                            }else{
                                                MoiseScanner_methods.MoiseScanner_error(s6, 1);
                                            }
                                        }else{
                                            MoiseScanner_methods.MoiseScanner_error(null, 1);
                                        }
                                    }else{
                                        MoiseScanner_methods.MoiseScanner_error(null, 1);
                                    }
                                }else{
                                    MoiseScanner_methods.MoiseScanner_error(s5, 1);
                                }
                            }else{
                                MoiseScanner_methods.MoiseScanner_error(null, 1);
                            }
                        }else{
                            MoiseScanner_methods.MoiseScanner_error(null, 1);
                        }
                    }else{
                        MoiseScanner_variables.temp_peek = s4;
                    }
                }
            }
        }
        return false;
    }

    public static void TagNC(BufferedReader br,String s1){
        if (!MoiseScanner_variables.stop){
            if (MoiseScanner_variables.peek == '<'){
                MoiseScanner_methods.readch(br);
                if (Character.isLetter(MoiseScanner_variables.peek)){
                    String s2 = MoiseScanner_methods.attach_character(br);
                    if(s2.equals(s1)){
                        MoiseScanner_methods.readch(br);
                    }else{
                        MoiseScanner_methods.MoiseScanner_error(s2, 1);
                    }
                }else{
                    MoiseScanner_methods.MoiseScanner_error(null, 1);
                }
            }else{
                MoiseScanner_methods.MoiseScanner_error(null, 1);
            }
        }
    }

    public static void TagFC(BufferedReader br,String s1){
        if(!MoiseScanner_variables.stop){
            if(MoiseScanner_variables.peek == '/'){
                MoiseScanner_methods.readch(br);
                if(Character.isLetter(MoiseScanner_variables.peek)){
                    String s2 = MoiseScanner_methods.attach_character(br);
                    if(s1.equals(s2)){
                        if(MoiseScanner_variables.peek == '>'){
                            MoiseScanner_methods.readch(br);
                            MoiseScanner_methods.goto_new_line(br);
                        }else{
                            MoiseScanner_methods.MoiseScanner_error(null, 1);
                        }
                    }else{
                        MoiseScanner_methods.MoiseScanner_error(s2, 1);
                    }
                }else{
                    MoiseScanner_methods.MoiseScanner_error(null, 1);
                }
            }else{
                MoiseScanner_methods.MoiseScanner_error(null, 1);
            }
        }
    }

    public static void ComposeTagFC(BufferedReader br,String s1,String s2){
        if(!MoiseScanner_variables.stop){
            if(MoiseScanner_variables.peek == '/'){
                MoiseScanner_methods.readch(br);
                if (Character.isLetter(MoiseScanner_variables.peek)){
                    String s3 = MoiseScanner_methods.attach_character(br);
                    if(s1.equals(s3)){
                        if(MoiseScanner_variables.peek == '-'){
                            MoiseScanner_methods.readch(br);
                            if(Character.isLetter(MoiseScanner_variables.peek)){
                                String s4 = MoiseScanner_methods.attach_character(br);
                                if(s2.equals(s4)){
                                    if(MoiseScanner_variables.peek == '>'){
                                        MoiseScanner_methods.readch(br);
                                        MoiseScanner_methods.goto_new_line(br);
                                    }else{
                                        MoiseScanner_methods.MoiseScanner_error(null, 1);
                                    }
                                }else{
                                    MoiseScanner_methods.MoiseScanner_error(s4, 1);
                                }
                            }else{
                                MoiseScanner_methods.MoiseScanner_error(null, 1);
                            }
                        }else{
                            MoiseScanner_methods.MoiseScanner_error(null, 1);
                        }
                    }else{
                        MoiseScanner_methods.MoiseScanner_error(s3, 1);
                    }
                }else{
                    MoiseScanner_methods.MoiseScanner_error(null, 1);
                }
            }else{
                MoiseScanner_methods.MoiseScanner_error(null, 1);
            }
        }
    }

    public static boolean ComposeTag_peek(BufferedReader br, String s1, String s2){
        if(!MoiseScanner_variables.stop){
            if(MoiseScanner_variables.peek == '<'){
                MoiseScanner_methods.readch(br);
                if(Character.isLetter(MoiseScanner_variables.peek)){
                    String s3 = MoiseScanner_methods.attach_character(br);
                    if(s3.equals(s1)){
                        if(MoiseScanner_variables.peek == '-'){
                            MoiseScanner_methods.readch(br);
                            if(Character.isLetter(MoiseScanner_variables.peek)){
                                String s4 = MoiseScanner_methods.attach_character(br);
                                if(s4.equals(s2)){
                                    return true;
                                }else{
                                    MoiseScanner_variables.temp_peek = s4;
                                }
                            }
                        }
                    }else{
                        MoiseScanner_variables.temp_peek = s3;
                    }
                }
            }
        }
        return false;
    }

    public static boolean Tag_peek(BufferedReader br, String s1){
        if(!MoiseScanner_variables.stop){
            if(MoiseScanner_variables.peek == '<'){
                MoiseScanner_methods.readch(br);
                if(Character.isLetter(MoiseScanner_variables.peek)){
                    String s2 = MoiseScanner_methods.attach_character(br);
                    if(s2.equals(s1)){
                        MoiseScanner_methods.goto_new_line(br);
                        return true;
                    }else{
                        MoiseScanner_variables.temp_peek = s2;
                    }
                }
            }
        }
        return false;
    }

    public static boolean ComposedTag_dash_peek(BufferedReader br,String read, String s1, String s2){
        if(!MoiseScanner_variables.stop){
            if(read.equals(s1)){
                if(MoiseScanner_variables.peek == '-'){
                    MoiseScanner_methods.readch(br);
                    if(Character.isLetter(MoiseScanner_variables.peek)){
                        String s3 = MoiseScanner_methods.attach_character(br);
                        return s3.equals(s2);
                    }
                }
            }
        }
        return false;
    }

    public static boolean Tag_check(String read, String s1){
        if(!MoiseScanner_variables.stop){
            return read.equals(s1);
        }
        return false;
    }

    public static void simpleCloseTag(BufferedReader br){
        if(MoiseScanner_variables.peek == '>'){
            MoiseScanner_methods.readch(br);
            MoiseScanner_methods.goto_new_line(br);
        }else{
            MoiseScanner_methods.MoiseScanner_error(null, 1);
        }
    }

    public static void simpleCloseTag2(BufferedReader br){
        if(!MoiseScanner_variables.stop) {
            if(MoiseScanner_variables.peek == '/'){
                MoiseScanner_methods.readch(br);
                if(MoiseScanner_variables.peek == '>'){
                    MoiseScanner_methods.readch(br);
                    MoiseScanner_methods.goto_new_line(br);
                }else{
                    MoiseScanner_methods.MoiseScanner_error(null, 1);
                }
            }else{
                MoiseScanner_methods.MoiseScanner_error(null, 1);
            }
        }
    }

}