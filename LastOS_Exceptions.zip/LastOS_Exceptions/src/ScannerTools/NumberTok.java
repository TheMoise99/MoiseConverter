package ScannerTools;

public class NumberTok extends Token {
	public String lexeme = "";
	int n = 0;
	public NumberTok(int tag, String s){ super(tag); lexeme=s; n=tag; }
	public String toString() { return "<" + tag + ", " + lexeme + ">"; }
}