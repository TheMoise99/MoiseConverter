package ScannerTools;

public class variables_for_HashMap{

    public static int index_property = 0;
    public static int index_role = 0;
    public static int index_role_extends = 0;
    public static int index_link_type = 0;
    public static int index_group_specification = 0;
    public static int index_roles_role = 0;
    public static int index_link = 0;
    public static int index_include_group_specification = 0;
    public static int index_cardinality = 0;
    public static int index_compatibility = 0;
    public static int index_fs_scheme = 0;
    public static int index_fs_goal = 0;
    public static int index_fs_argument = 0;
    public static int index_fs_depends_on = 0;
    public static int index_fs_plan = 0;
    public static int index_fs_notification_policy = 0;
    public static int index_fs_exception_specification = 0;
    public static int index_fs_target = 0;
    public static int index_fs_accountability_agreement = 0;
    public static int index_fs_requesting_condition = 0;
    public static int index_fs_condition_argument = 0;
    public static int index_fs_account_argument = 0;
    public static int index_fs_exception_argument = 0;
    public static int index_fs_raising_goal = 0;
    public static int index_fs_handling_goal = 0;
    public static int index_fs_mission = 0;
    public static int index_fs_mission_goal = 0;
    public static int index_fs_preferred = 0;
    public static int index_ns_norm = 0;

}
