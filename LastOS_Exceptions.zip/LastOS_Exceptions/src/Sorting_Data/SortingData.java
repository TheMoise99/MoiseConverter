package Sorting_Data;

import ScannerTools.MoiseScanner_HashMap;
import ScannerTools.MoiseScanner_methods;
import java.util.ArrayList;

public class SortingData{
    public static ArrayList<Integer> SortData(String request,String type_of_sort,Integer index){
        ArrayList<Integer> to_return = new ArrayList<>();
        switch(request){
            case "property":
                switch(type_of_sort){
                    case "none":
                        for(int i=0;i<MoiseScanner_HashMap.property.size();i++){
                            if(MoiseScanner_HashMap.property.get(i).get(4).equals("none")){
                                to_return.add(i);
                            }
                        }
                        break;
                    case "structural-specification":
                        for(int i=0;i<MoiseScanner_HashMap.property.size();i++){
                            if(MoiseScanner_HashMap.property.get(i).get(4).equals("structural-specification")){
                                to_return.add(i);
                            }
                        }
                        break;
                    case "group-specification":
                        String index_3 = MoiseScanner_methods.to_String(index);
                        for(int i=0;i<MoiseScanner_HashMap.property.size();i++){
                            if(MoiseScanner_HashMap.property.get(i).get(0).equals("group-specification")){
                                if(MoiseScanner_HashMap.property.get(i).get(4).equals(index_3)){
                                    to_return.add(i);
                                }
                            }
                        }
                        break;
                    case "functional-specification":
                        for(int i=0;i<MoiseScanner_HashMap.property.size();i++){
                            if(MoiseScanner_HashMap.property.get(i).get(4).equals("functional-specification")){
                                to_return.add(i);
                            }
                        }
                        break;
                    case "scheme":
                        String index_4 = MoiseScanner_methods.to_String(index);
                        for(int i=0;i<MoiseScanner_HashMap.property.size();i++){
                            if(MoiseScanner_HashMap.property.get(i).get(0).equals("scheme")){
                                if(MoiseScanner_HashMap.property.get(i).get(4).equals(index_4)){
                                    to_return.add(i);
                                }
                            }
                        }
                        break;
                    case "plan":
                        String index_5 = MoiseScanner_methods.to_String(index);
                        for(int i=0;i<MoiseScanner_HashMap.property.size();i++){
                            if(MoiseScanner_HashMap.property.get(i).get(0).equals("plan")){
                                if(MoiseScanner_HashMap.property.get(i).get(4).equals(index_5)){
                                    to_return.add(i);
                                }
                            }
                        }
                        break;
                    case "notification-policy":
                        String index_6 = MoiseScanner_methods.to_String(index);
                        for(int i=0;i<MoiseScanner_HashMap.property.size();i++){
                            if(MoiseScanner_HashMap.property.get(i).get(0).equals("notification-policy")){
                                if(MoiseScanner_HashMap.property.get(i).get(4).equals(index_6)){
                                    to_return.add(i);
                                }
                            }
                        }
                        break;
                    case "mission":
                        String index_7 = MoiseScanner_methods.to_String(index);
                        for(int i=0;i<MoiseScanner_HashMap.property.size();i++){
                            if(MoiseScanner_HashMap.property.get(i).get(0).equals("mission")){
                                if(MoiseScanner_HashMap.property.get(i).get(4).equals(index_7)){
                                    to_return.add(i);
                                }
                            }
                        }
                        break;
                    case "normative-specification":
                        for(int i=0;i<MoiseScanner_HashMap.property.size();i++){
                            if(MoiseScanner_HashMap.property.get(i).get(0).equals("normative-specification")){
                                to_return.add(i);
                            }
                        }
                        break;
                    case "accountability-agreement":
                        String index_8 = MoiseScanner_methods.to_String(index);
                        for(int i=0;i<MoiseScanner_HashMap.property.size();i++){
                            if(MoiseScanner_HashMap.property.get(i).get(0).equals("accountability-agreement")){
                                if(MoiseScanner_HashMap.property.get(i).get(4).equals(index_8)){
                                    to_return.add(i);
                                }
                            }
                        }
                        break;
                    default:
                        break;
                }
                break;
            case "role":
                switch(type_of_sort){
                    case "all":
                        for(int i=0;i<MoiseScanner_HashMap.role.size();i++){
                            to_return.add(i);
                        }
                        break;
                    case "extends":
                        String index_2 = MoiseScanner_methods.to_String(index);
                        for(int i=0;i<MoiseScanner_HashMap.role_extends.size();i++){
                            if(MoiseScanner_HashMap.role_extends.get(i).get(3).equals(index_2)){
                                to_return.add(i);
                            }
                        }
                        break;
                    case "inside_role":
                        String index_3 = MoiseScanner_methods.to_String(index);
                        for(int i=0;i<MoiseScanner_HashMap.property.size();i++){
                            if(MoiseScanner_HashMap.property.get(i).get(0).equals("inside_role")){
                                if(MoiseScanner_HashMap.property.get(i).get(4).equals(index_3)){
                                    to_return.add(i);
                                }
                            }
                        }
                        break;
                    default:
                        break;
                }
                break;
            case "link-type":
                switch(type_of_sort){
                    case "all":
                        for(int i=0;i<MoiseScanner_HashMap.link_type.size();i++){
                            to_return.add(i);
                        }
                        break;
                    default:
                        break;
                }
                break;
            case "roles_role":
                switch(type_of_sort){
                    case "by_index":
                        String index_3 = MoiseScanner_methods.to_String(index);
                        for(int i=0;i<MoiseScanner_HashMap.roles_role.size();i++){
                            if(MoiseScanner_HashMap.roles_role.get(i).get(5).equals(index_3)){
                                to_return.add(i);
                            }
                        }
                        break;
                    default:
                        break;
                }
                break;
            case "link":
                switch(type_of_sort){
                    case "by_index":
                        String index_3 = MoiseScanner_methods.to_String(index);
                        for(int i=0;i<MoiseScanner_HashMap.link.size();i++){
                            if(MoiseScanner_HashMap.link.get(i).get(8).equals(index_3)){
                                to_return.add(i);
                            }
                        }
                        break;
                    default:
                        break;
                }
                break;
            case "subgroups":
                switch(type_of_sort){
                    case "include_group_specification":
                        String index_3 = MoiseScanner_methods.to_String(index);
                        for(int i=0;i<MoiseScanner_HashMap.include_group_specification.size();i++){
                            if(MoiseScanner_HashMap.include_group_specification.get(i).get(3).equals(index_3)){
                                to_return.add(i);
                            }
                        }
                        break;
                    default:
                        break;
                }
                break;
            case "cardinality":
                switch(type_of_sort){
                    case "by_index":
                        String index_3 = MoiseScanner_methods.to_String(index);
                        for(int i=0;i<MoiseScanner_HashMap.cardinality.size();i++){
                            if(MoiseScanner_HashMap.cardinality.get(i).get(6).equals(index_3)){
                                to_return.add(i);
                            }
                        }
                        break;
                    default:
                        break;
                }
                break;
            case "compatibility":
                switch(type_of_sort){
                    case "by_index":
                        String index_3 = MoiseScanner_methods.to_String(index);
                        for(int i=0;i<MoiseScanner_HashMap.compatibility.size();i++){
                            if(MoiseScanner_HashMap.compatibility.get(i).get(8).equals(index_3)){
                                to_return.add(i);
                            }
                        }
                        break;
                    default:
                        break;
                }
                break;
            case "goal":
                switch(type_of_sort){
                    case "scheme":
                        String index_3 = MoiseScanner_methods.to_String(index);
                        for(int i=0;i<MoiseScanner_HashMap.fs_goal.size();i++){
                            if(MoiseScanner_HashMap.fs_goal.get(i).get(0).equals("scheme")){
                                if(MoiseScanner_HashMap.fs_goal.get(i).get(8).equals(index_3)){
                                    to_return.add(i);
                                }
                            }
                        }
                        break;
                    case "plan":
                        String index_4 = MoiseScanner_methods.to_String(index);
                        for(int i=0;i<MoiseScanner_HashMap.fs_goal.size();i++){
                            if(MoiseScanner_HashMap.fs_goal.get(i).get(0).equals("plan")){
                                if(MoiseScanner_HashMap.fs_goal.get(i).get(8).equals(index_4)){
                                    to_return.add(i);
                                }
                            }
                        }
                        break;
                    case "account-template":
                        String index_6 = MoiseScanner_methods.to_String(index);
                        for(int i=0;i<MoiseScanner_HashMap.fs_goal.size();i++){
                            if(MoiseScanner_HashMap.fs_goal.get(i).get(0).equals("account-template")){
                                if(MoiseScanner_HashMap.fs_goal.get(i).get(8).equals(index_6)){
                                    to_return.add(i);
                                }
                            }
                        }
                        break;
                    case "mission":
                        String index_5 = MoiseScanner_methods.to_String(index);
                        for(int i=0;i<MoiseScanner_HashMap.fs_mission_goal.size();i++){
                            if(MoiseScanner_HashMap.fs_mission_goal.get(i).get(3).equals(index_5)){
                                to_return.add(i);
                            }
                        }
                        break;
                    default:
                        break;
                }
                break;
            case "argument":
                switch(type_of_sort){
                    case "goal":
                        String index_3 = MoiseScanner_methods.to_String(index);
                        for(int i=0;i<MoiseScanner_HashMap.fs_argument.size();i++){
                            if(MoiseScanner_HashMap.fs_argument.get(i).get(0).equals("goal")){
                                if(MoiseScanner_HashMap.fs_argument.get(i).get(4).equals(index_3)){
                                    to_return.add(i);
                                }
                            }
                        }
                        break;
                    case "raising-goal":
                        String index_4 = MoiseScanner_methods.to_String(index);
                        for(int i=0;i<MoiseScanner_HashMap.fs_argument.size();i++){
                            if(MoiseScanner_HashMap.fs_argument.get(i).get(0).equals("raising-goal")){
                                if(MoiseScanner_HashMap.fs_argument.get(i).get(4).equals(index_4)){
                                    to_return.add(i);
                                }
                            }
                        }
                        break;
                    case "handling-goal":
                        String index_5 = MoiseScanner_methods.to_String(index);
                        for(int i=0;i<MoiseScanner_HashMap.fs_argument.size();i++){
                            if(MoiseScanner_HashMap.fs_argument.get(i).get(0).equals("handling-goal")){
                                if(MoiseScanner_HashMap.fs_argument.get(i).get(4).equals(index_5)){
                                    to_return.add(i);
                                }
                            }
                        }
                        break;
                    default:
                        break;
                }
                break;
            case "depends-on":
                switch(type_of_sort){
                    case "goal":
                        String index_3 = MoiseScanner_methods.to_String(index);
                        for(int i=0;i<MoiseScanner_HashMap.fs_depends_on.size();i++){
                            if(MoiseScanner_HashMap.fs_depends_on.get(i).get(0).equals("goal")){
                                if(MoiseScanner_HashMap.fs_depends_on.get(i).get(3).equals(index_3)){
                                    to_return.add(i);
                                }
                            }
                        }
                        break;
                    case "raising-goal":
                        String index_4 = MoiseScanner_methods.to_String(index);
                        for(int i=0;i<MoiseScanner_HashMap.fs_depends_on.size();i++){
                            if(MoiseScanner_HashMap.fs_depends_on.get(i).get(0).equals("raising-goal")){
                                if(MoiseScanner_HashMap.fs_depends_on.get(i).get(3).equals(index_4)){
                                    to_return.add(i);
                                }
                            }
                        }
                        break;
                    case "handling-goal":
                        String index_5 = MoiseScanner_methods.to_String(index);
                        for(int i=0;i<MoiseScanner_HashMap.fs_depends_on.size();i++){
                            if(MoiseScanner_HashMap.fs_depends_on.get(i).get(0).equals("handling-goal")){
                                if(MoiseScanner_HashMap.fs_depends_on.get(i).get(3).equals(index_5)){
                                    to_return.add(i);
                                }
                            }
                        }
                        break;
                    default:
                        break;
                }
                break;
            case "plan":
                switch(type_of_sort){
                    case "goal":
                        String index_3 = MoiseScanner_methods.to_String(index);
                        for(int i=0;i<MoiseScanner_HashMap.fs_plan.size();i++){
                            if(MoiseScanner_HashMap.fs_plan.get(i).get(0).equals("goal")){
                                if(MoiseScanner_HashMap.fs_plan.get(i).get(4).equals(index_3)){
                                    to_return.add(i);
                                }
                            }
                        }
                        break;
                    case "raising-goal":
                        String index_4 = MoiseScanner_methods.to_String(index);
                        for(int i=0;i<MoiseScanner_HashMap.fs_plan.size();i++){
                            if(MoiseScanner_HashMap.fs_plan.get(i).get(0).equals("raising-goal")){
                                if(MoiseScanner_HashMap.fs_plan.get(i).get(4).equals(index_4)){
                                    to_return.add(i);
                                }
                            }
                        }
                        break;
                    case "handling-goal":
                        String index_5 = MoiseScanner_methods.to_String(index);
                        for(int i=0;i<MoiseScanner_HashMap.fs_plan.size();i++){
                            if(MoiseScanner_HashMap.fs_plan.get(i).get(0).equals("handling-goal")){
                                if(MoiseScanner_HashMap.fs_plan.get(i).get(4).equals(index_5)){
                                    to_return.add(i);
                                }
                            }
                        }
                        break;
                    default:
                        break;
                }
                break;
            case "notification-policy":
                switch(type_of_sort){
                    case "by_index":
                        String index_3 = MoiseScanner_methods.to_String(index);
                        for(int i=0;i<MoiseScanner_HashMap.fs_notification_policy.size();i++){
                            if(MoiseScanner_HashMap.fs_notification_policy.get(i).get(0).equals("scheme")){
                                if(MoiseScanner_HashMap.fs_notification_policy.get(i).get(5).equals(index_3)){
                                    to_return.add(i);
                                }
                            }
                        }
                        break;
                    default:
                        break;
                }
                break;
            case "exception-argument":
                switch(type_of_sort){
                    case "by_index":
                        String index_3 = MoiseScanner_methods.to_String(index);
                        for(int i=0;i<MoiseScanner_HashMap.fs_exception_argument.size();i++){
                            if(MoiseScanner_HashMap.fs_exception_argument.get(i).get(4).equals(index_3)){
                                to_return.add(i);
                            }
                        }
                        break;
                    default:
                        break;
                }
                break;
            case "raising-goal":
                switch(type_of_sort){
                    case "by_index":
                        String index_3 = MoiseScanner_methods.to_String(index);
                        for(int i=0;i<MoiseScanner_HashMap.fs_raising_goal.size();i++){
                            if(MoiseScanner_HashMap.fs_raising_goal.get(i).get(9).equals(index_3)){
                                to_return.add(i);
                            }
                        }
                        break;
                    default:
                        break;
                }
                break;
            case "handling-goal":
                switch(type_of_sort){
                    case "by_index":
                        String index_3 = MoiseScanner_methods.to_String(index);
                        for(int i=0;i<MoiseScanner_HashMap.fs_handling_goal.size();i++){
                            if(MoiseScanner_HashMap.fs_handling_goal.get(i).get(9).equals(index_3)){
                                to_return.add(i);
                            }
                        }
                        break;
                    default:
                        break;
                }
                break;
            case "mission":
                switch(type_of_sort){
                    case "by_index":
                        String index_3 = MoiseScanner_methods.to_String(index);
                        for(int i=0;i<MoiseScanner_HashMap.fs_mission.size();i++){
                            if(MoiseScanner_HashMap.fs_mission.get(i).get(5).equals(index_3)){
                                to_return.add(i);
                            }
                        }
                        break;
                    default:
                        break;
                }
                break;
            case "preferred":
                switch(type_of_sort) {
                    case "mission":
                        String index_5 = MoiseScanner_methods.to_String(index);
                        for (int i = 0; i < MoiseScanner_HashMap.fs_preferred.size(); i++){
                            if (MoiseScanner_HashMap.fs_preferred.get(i).get(3).equals(index_5)){
                                to_return.add(i);
                            }
                        }
                        break;
                    default:
                        break;
                }
                break;
            case "norm":
                switch(type_of_sort) {
                    case "all":
                        for(int i=0;i<MoiseScanner_HashMap.ns_norm.size();i++){
                            to_return.add(i);
                        }
                        break;
                    default:
                        break;
                }
                break;
            case "accountability-agreement":
                switch(type_of_sort){
                    case "by_index":
                        String index_3 = MoiseScanner_methods.to_String(index);
                        for(int i=0;i<MoiseScanner_HashMap.fs_accountability_agreement.size();i++){
                            if(MoiseScanner_HashMap.fs_accountability_agreement.get(i).get(0).equals("scheme")){
                                if(MoiseScanner_HashMap.fs_accountability_agreement.get(i).get(3).equals(index_3)){
                                    to_return.add(i);
                                }
                            }
                        }
                        break;
                    default:
                        break;
                }
                break;
            case "target":
                switch(type_of_sort){
                    case "by_index":
                        String index_3 = MoiseScanner_methods.to_String(index);
                        for(int i=0;i<MoiseScanner_HashMap.fs_target.size();i++){
                            if(MoiseScanner_HashMap.fs_target.get(i).get(3).equals(index_3)){
                                to_return.add(i);
                            }
                        }
                        break;
                    default:
                        break;
                }
                break;
            case "requesting-condition":
                switch(type_of_sort){
                    case "by_index":
                        String index_3 = MoiseScanner_methods.to_String(index);
                        for(int i=0;i<MoiseScanner_HashMap.fs_requesting_condition.size();i++){
                            if(MoiseScanner_HashMap.fs_requesting_condition.get(i).get(3).equals(index_3)){
                                to_return.add(i);
                            }
                        }
                        break;
                    default:
                        break;
                }
                break;
            case "condition-argument":
                switch(type_of_sort){
                    case "by_index":
                        String index_3 = MoiseScanner_methods.to_String(index);
                        for(int i=0;i<MoiseScanner_HashMap.fs_condition_argument.size();i++){
                            if(MoiseScanner_HashMap.fs_condition_argument.get(i).get(4).equals(index_3)){
                                to_return.add(i);
                            }
                        }
                        break;
                    default:
                        break;
                }
                break;
            case "account-argument":
                switch(type_of_sort){
                    case "by_index":
                        String index_3 = MoiseScanner_methods.to_String(index);
                        for(int i=0;i<MoiseScanner_HashMap.fs_account_argument.size();i++){
                            if(MoiseScanner_HashMap.fs_account_argument.get(i).get(4).equals(index_3)){
                                to_return.add(i);
                            }
                        }
                        break;
                    default:
                        break;
                }
                break;
            default:
                break;
        }
        return to_return;
    }
}

