package main.java.Pandoc.Native;

import ScannerTools.MoiseScanner;
import main.java.Pandoc.Types.Format;
import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.lang.Process;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;

public class Operations {
    private static String inputPath;
    private static String outputPath;
    private static String args;
    private static Format inputFormat;
    private static Format outputFormat;

    static File source;
    static File dest;

    public static void setInputFormat(Format format) {
        inputFormat = format;
    }

    public static void setOutputFormat(Format format){
        outputFormat = format;
    }

    public static Format getOutputFormat(){
        return outputFormat;
    }

    public static boolean checkForPandoc(){
        try{
            String line;// line
            Process pandoc = new ProcessBuilder("pandoc", "-v").start();
            BufferedReader input = new BufferedReader(new InputStreamReader(pandoc.getInputStream()));
            while((line=input.readLine())!=null){
                System.out.println(line);
            }
            input.close();
            return true;
        }catch(IOException e){
            e.printStackTrace();
        }
        return false;
    }

    public static void setFileLocations(String input, String output){
        inputPath = input;
        outputPath = output;
    }

    public static void executeCommand() throws IOException {
        if(outputFormat == Format.MARKDOWN){
            source = new File("C:\\Markdown\\markdown.md");
            dest = new File(outputPath);
            copyFileUsingJava7Files(source, dest);
        }else{
            try{
                ArrayList<String> process = createCommand();
                Process pandoc = new ProcessBuilder(process).start();
                String line;//linea
                BufferedReader output = new BufferedReader(new InputStreamReader(pandoc.getErrorStream()));
                while((line = output.readLine())!=null){
                    System.out.println(line);
                }
                output.close();
            }catch(IOException e){

            }
        }
    }

    private static void copyFileUsingJava7Files(File source, File dest) throws IOException {
        Files.copy(source.toPath(), dest.toPath());
    }

    private static ArrayList<String> createCommand(){
        ArrayList<String> command = new ArrayList<String>();
        if(outputFormat==Format.PDF){
            command.add("pandoc");
            command.add("-s");
            command.add("-o");
            command.add(outputPath);
            command.add("C:\\Markdown\\markdown.md");
        }else if(outputFormat==Format.HTML){
            command.add("pandoc");
            command.add("--standalone");
            command.add("--template");
            command.add("C:\\Markdown\\template.html");
            command.add("C:\\Markdown\\markdown.md");
            command.add("-o");
            command.add(outputPath);
        }else if(outputFormat==Format.TEX){
            command.add("pandoc");
            command.add("-s");
            command.add("-o");
            command.add(outputPath);
            command.add("C:\\Markdown\\markdown.md");
        }
        return command;
    }
}
