package main.java.Pandoc.Types;

public enum Format{
    PDF,
    TEX,
    MARKDOWN,
    HTML
}
