package main.java.Pandoc.UI;

import ScannerTools.*;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import main.java.Pandoc.Native.Operations;


public class Main extends Application{

    static protected Stage stage;
    private static boolean isPandocFound;

    public static String[] arguments;

    @Override
    public void start(Stage primaryStage) throws Exception{
        stage = primaryStage;
        if(isPandocFound){
            Parent root = FXMLLoader.load(getClass().getResource("/main/resources/MainWindow_new.fxml"));
            primaryStage.setTitle("Pandoc Converter for Moise OS");
            primaryStage.setScene(new Scene(root, 880, 550));
        }else{
            Parent root = FXMLLoader.load(getClass().getResource("/main/resources/Error.fxml"));
            primaryStage.setTitle("Error");
            primaryStage.setScene(new Scene(root, 500, 500));
        }
        primaryStage.show();
    }


    public static void main(String[] args){
        arguments = args;
        if(Operations.checkForPandoc()){
            isPandocFound = true;
        }else{
            isPandocFound = false;
        }
        launch(args);
    }
}
